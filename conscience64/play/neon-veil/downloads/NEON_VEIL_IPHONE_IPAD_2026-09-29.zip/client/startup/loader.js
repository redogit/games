/* Shared browser loader. UA is a hint, never game authority.
 * No fetch, network scan, storage, auto-redirect, install or shell execution. */
'use strict';
(function(root){
  const registry=root.NeonLoaderRegistry;
  if(!registry||registry.schema!=='neon-veil/startup-routes/v1')throw Error('Startup registry missing; extract the complete package.');
  function detect(n={}){
    const ua=String(n.userAgent||''),platform=String(n.platform||'');
    if(/iPhone|iPad|iPod/i.test(ua)||(/Mac/i.test(platform)&&Number(n.maxTouchPoints)>1))return 'ios';
    if(/Android/i.test(ua))return 'android';
    if(/Windows|Win32|Win64/i.test(ua+' '+platform))return 'windows';
    if(/Macintosh|MacIntel|Mac OS X/i.test(ua+' '+platform))return 'macos';
    if(/Linux|X11/i.test(ua+' '+platform))return 'linux';
    return 'unknown';
  }
  function select(n,override='auto'){
    return registry.routes[Object.prototype.hasOwnProperty.call(registry.routes,override)?override:detect(n)];
  }
  function normalizeAddress(value,options={}){
    if(typeof value!=='string'||value.length>256)throw Error('Enter the host address and port.');
    const input=value.trim();
    if(!input||/[\s\\?#@%]/.test(input))throw Error('Use only a host address and port; no credentials, paths, query or fragment.');
    const address=input.startsWith('http://')?input.slice(7):input;
    const match=/^(localhost|(?:[0-9]{1,3}\.){3}[0-9]{1,3}):([0-9]{1,5})\/?$/.exec(address);
    if(!match)throw Error('Use HTTP and a private IPv4 address with an explicit port, such as 192.168.1.50:8080.');
    const host=match[1],port=Number(match[2]);
    if(port<1024||port>65535||String(port)!==match[2])throw Error('Use the host’s explicit port, from 1024 to 65535.');
    let local=host==='localhost';
    if(!local){
      const p=host.split('.');const b=p.map(Number);
      if(b.some((n,i)=>n>255||String(n)!==p[i]))throw Error('Use ordinary four-part decimal IPv4 notation.');
      local=host==='127.0.0.1';
      if(!local&&!(b[0]===10||(b[0]===172&&b[1]>=16&&b[1]<=31)||(b[0]===192&&b[1]===168)))
        throw Error('Only private local-network hosts are supported by this prototype loader.');
    }
    if(local&&options.ios)throw Error('On iPhone use the host computer’s private IPv4, not your phone’s localhost.');
    return 'http://'+host+':'+port+'/';
  }
  function currentHost(href,options={}){
    try{const u=new URL(href);if(u.protocol!=='http:'||u.username||u.password)return null;
      return normalizeAddress(u.origin,options);
    }catch(_){return null;}
  }
  function boot(doc,n,loc){
    const $=id=>doc.getElementById(id),choice=$('platformChoice');
    const detected=detect(n),hint=doc.body.dataset.preference||'auto';
    if(hint!=='auto'&&registry.routes[hint])choice.value=hint;
    // A UI override never makes iPhone localhost into a usable remote host.
    const ios=detected==='ios'||hint==='ios';
    const resetDestination=()=>{$('enterChosen').hidden=true;$('enterChosen').removeAttribute('href');$('serverAddress').removeAttribute('aria-invalid');};
    const refresh=()=>{
      const route=select(n,choice.value);
      $('detection').textContent='Detected: '+registry.routes[detected].label+'. Selected route: '+route.label+'.';
      $('routeHeading').textContent=route.label;
      $('routeDetail').textContent=route.description;
      $('hostSteps').hidden=!route.command;$('hostCommand').textContent=route.command;
      $('iphoneSteps').hidden=route.id!=='ios';
      const here=currentHost(loc.href,{ios});
      $('currentHostPanel').hidden=!here;
      if(here){$('enterCurrent').href=here;$('currentHostName').textContent=here;}
      else $('enterCurrent').removeAttribute('href');
      $('fileNotice').textContent=loc.protocol==='file:'
        ?'This is a local launch guide, not a running server. Start the host first. On iPhone open its START_IPHONE.html address in Safari; a Files preview may not execute this page.'
        :'Use the host computer’s private IPv4 address and port. Changing address or port can select a different world or account.';
      resetDestination();$('joinStatus').textContent='No new connection selected. Device selection does not install or start a server.';
    };
    choice.addEventListener('change',refresh);
    $('serverAddress').addEventListener('input',()=>{resetDestination();$('joinStatus').textContent='Address changed. Check it again before entering.';});
    $('joinForm').addEventListener('submit',event=>{
      event.preventDefault();resetDestination();
      try{
        const url=normalizeAddress($('serverAddress').value,{ios});
        $('enterChosen').href=url;$('enterChosen').hidden=false;
        $('joinStatus').textContent='Address format accepted: '+url+' The server has not been contacted. Enter only a host you trust.';
        $('enterChosen').focus();
      }catch(e){$('serverAddress').setAttribute('aria-invalid','true');$('joinStatus').textContent=e.message;$('serverAddress').focus();}
    });
    refresh();
  }
  root.NeonLoader=Object.freeze({detect,select,normalizeAddress,currentHost,boot});
})(globalThis);
