/* Small browser entry adapter. All decisions/UI behavior live in loader.js. */
'use strict';
NeonLoader.boot(document,navigator,location);
