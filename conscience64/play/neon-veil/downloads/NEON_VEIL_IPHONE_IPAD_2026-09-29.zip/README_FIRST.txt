NEON//VEIL — Public Preview — 2026-09-29

This is a local-first preview. The Python server owns the world state. GitHub Pages
only distributes the packages and provides a launcher hub; it is not the game server.

Safety boundary: trusted local network only. Do not port-forward this development server.
Back up the entire data directory before moving an existing save between versions.

IPHONE / IPAD

An iPhone/iPad does not run the included Python world server. Use another supported device as the host.

1. On Windows/Linux/macOS/Android, start NEON//VEIL with LAN enabled.
2. On iPhone/iPad, open the central Play page:
   https://redogit.github.io/conscience64/play/neon-veil/
3. Enter the host address shown by the server, for example 192.168.1.50:8080.
4. Tap Open world. Keep the host running.

The included START_IPHONE.html is an offline connection helper; Safari may work more reliably with the central hosted page.
