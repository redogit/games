@echo off
setlocal
echo This explicitly opens a TRUSTED LOCAL NETWORK test server, not a public service.
echo Do not port-forward. Other devices use this host's private LAN address.
choice /C YN /N /M "Continue with local network testing? [Y/N] "
if errorlevel 2 exit /b 0
call "%~dp0START_NEON_VEIL.bat" --lan %*
exit /b %ERRORLEVEL%
