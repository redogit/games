NEON//VEIL — Public Preview — 2026-09-29

This is a local-first preview. The Python server owns the world state. GitHub Pages
only distributes the packages and provides a launcher hub; it is not the game server.

Safety boundary: trusted local network only. Do not port-forward this development server.
Back up the entire data directory before moving an existing save between versions.

WINDOWS SOLO
1. Install Python 3.10 or newer from python.org if needed.
2. Extract this ZIP completely.
3. Double-click START_NEON_VEIL.bat.
4. Keep the terminal window open while playing.

WINDOWS HOST FOR ANOTHER DEVICE
Double-click START_NEON_VEIL_LAN.bat on a trusted local network.
Then use the printed LAN address on the other device or the central Play page.
