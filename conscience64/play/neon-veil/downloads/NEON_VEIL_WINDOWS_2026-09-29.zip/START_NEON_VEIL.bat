@echo off
setlocal
set "ROOT=%~dp0"
if defined NEON_PYTHON goto explicit
where py >nul 2>nul
if errorlevel 1 goto python3
py -3 -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto python3
py -3 -B -u "%ROOT%START_NEON_VEIL.py" %*
goto done
:python3
where python3 >nul 2>nul
if errorlevel 1 goto python
python3 -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto python
python3 -B -u "%ROOT%START_NEON_VEIL.py" %*
goto done
:python
where python >nul 2>nul
if errorlevel 1 goto missing
python -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto missing
python -B -u "%ROOT%START_NEON_VEIL.py" %*
goto done
:explicit
"%NEON_PYTHON%" -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>nul
if errorlevel 1 goto missing
"%NEON_PYTHON%" -B -u "%ROOT%START_NEON_VEIL.py" %*
goto done
:missing
echo Python 3.10+ is required. NEON_PYTHON may name one installed executable.
echo No packages were installed and no server was started.
exit /b 2
:done
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" if "%~1"=="" pause
exit /b %RESULT%
