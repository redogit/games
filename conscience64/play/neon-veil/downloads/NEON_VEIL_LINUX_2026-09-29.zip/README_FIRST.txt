NEON//VEIL — Public Preview — 2026-09-29

This is a local-first preview. The Python server owns the world state. GitHub Pages
only distributes the packages and provides a launcher hub; it is not the game server.

Safety boundary: trusted local network only. Do not port-forward this development server.
Back up the entire data directory before moving an existing save between versions.

LINUX SOLO
1. Install Python 3.10 or newer.
2. Extract this ZIP completely.
3. Open a terminal in this folder.
4. Run: sh START_LINUX.sh
5. Keep the terminal open while playing.

LINUX HOST FOR ANOTHER DEVICE
Run: sh START_LINUX.sh --lan
Then use the printed LAN address on the other device or the central Play page.
