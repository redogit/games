NEON//VEIL — Public Preview — 2026-09-29

This is a local-first preview. The Python server owns the world state. GitHub Pages
only distributes the packages and provides a launcher hub; it is not the game server.

Safety boundary: trusted local network only. Do not port-forward this development server.
Back up the entire data directory before moving an existing save between versions.

ANDROID SOLO (TERMUX)
1. Install Termux, then inside Termux run: pkg install python
2. Put and extract this ZIP inside Termux private storage (for example $HOME/neon-veil), not shared /sdcard storage.
3. Enter the extracted folder in Termux.
4. Run: sh START_ANDROID.sh
5. Open the printed local address in your browser if it does not open automatically.

ANDROID HOST FOR ANOTHER DEVICE
Run: sh START_ANDROID.sh --lan
Then use the printed LAN address on the other device or the central Play page.
