"""Atomic authority over the local district. Client requests are never facts.

Runtime uses only Python's standard library. The injected clock and apply_damage
entry are internal test/simulation seams and are NOT HTTP endpoints.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from . import rules
from .events import CausalEngine
from .blackout import GridServices
from .senses import PerceptionSystem
from .expansion import Expansion, OPS, CLASSES, obj
from .world import make_world, in_town, passable, line_of_sight, atmosphere, SPAWN

def uid(prefix): return prefix+'_'+uuid.uuid4().hex

def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

class GameService(Expansion):
    def __init__(self, path: Path | str, clock=time.time):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.clock=clock;self.lock=threading.RLock()
        self.db=sqlite3.connect(str(self.path),check_same_thread=False,isolation_level=None,timeout=10)
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
        PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=10000;
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY,token_hash TEXT UNIQUE NOT NULL,csrf TEXT NOT NULL,created REAL NOT NULL,active_character TEXT,active_seconds REAL NOT NULL DEFAULT 0,last_credit REAL NOT NULL,last_seen REAL NOT NULL,last_input REAL NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS characters(id TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id),created_at REAL NOT NULL,name TEXT NOT NULL,appearance TEXT NOT NULL,specialty TEXT NOT NULL,template_id TEXT,alive INTEGER NOT NULL DEFAULT 1,hp REAL NOT NULL DEFAULT 24,max_hp REAL NOT NULL DEFAULT 24,focus REAL NOT NULL DEFAULT 4,level INTEGER NOT NULL DEFAULT 1,xp INTEGER NOT NULL DEFAULT 0,cred INTEGER NOT NULL DEFAULT 0,heat INTEGER NOT NULL DEFAULT 0,x REAL NOT NULL,y REAL NOT NULL,yaw REAL NOT NULL DEFAULT 0,version INTEGER NOT NULL DEFAULT 0,last_move REAL NOT NULL,last_attack REAL NOT NULL DEFAULT 0,last_hurt REAL NOT NULL DEFAULT 0,last_pvp REAL NOT NULL DEFAULT 0,last_action REAL NOT NULL,offline INTEGER NOT NULL DEFAULT 0,job TEXT NOT NULL DEFAULT 'available',dead_at REAL);
        CREATE TABLE IF NOT EXISTS corpses(id TEXT PRIMARY KEY,character_id TEXT NOT NULL REFERENCES characters(id),account_id TEXT NOT NULL REFERENCES accounts(id),died_at REAL NOT NULL,expires_at REAL NOT NULL,eligible_ids TEXT NOT NULL,cause TEXT NOT NULL,x REAL NOT NULL,y REAL NOT NULL,reclaimed INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,kind TEXT NOT NULL,name TEXT NOT NULL,authority TEXT NOT NULL DEFAULT 'WORLD' CHECK(authority='WORLD'),holder_type TEXT NOT NULL CHECK(holder_type IN('world','character','corpse','reclaimed')),holder_id TEXT,x REAL,y REAL,version INTEGER NOT NULL DEFAULT 0,power REAL NOT NULL DEFAULT 0);
        CREATE INDEX IF NOT EXISTS idx_custody ON items(holder_type,holder_id);
        CREATE INDEX IF NOT EXISTS idx_deadline ON corpses(reclaimed,expires_at);
        CREATE TABLE IF NOT EXISTS receipts(account_id TEXT NOT NULL,invocation TEXT NOT NULL,digest TEXT NOT NULL,response TEXT NOT NULL,PRIMARY KEY(account_id,invocation));
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,at REAL NOT NULL,kind TEXT NOT NULL,actor TEXT,payload TEXT NOT NULL,previous_hash TEXT NOT NULL,event_hash TEXT NOT NULL);
        ''')
        self.causal=CausalEngine(self)
        self.blackout=GridServices(self)
        self.perception=PerceptionSystem(self)
        now=float(clock())
        with self.tx():
            if self.meta('schema') is None:
                world=make_world()
                for k,v in [('schema','0.29.0'),('world',canonical(world)),('epoch',str(now)),('now',str(now)),('revision','0'),('npc_at',str(now)),('phase','0')]: self.setmeta(k,v)
                self._new_item('relay_shard','Unclaimed relay shard','world',None,8.5,10.5)
                self._new_item('salvage','Copper sigil','world',None,16.5,9.5)
                self._event(now,'WORLD_FOUNDED',None,{'district':'rainmarket'})
            self._migrate_expansion(now)
            self.causal.install(now)
            self.blackout.install(now)
            self.perception.install(now)
            self._process_locked(now)

    @contextmanager
    def tx(self):
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try: yield; self.db.execute('COMMIT')
            except BaseException:
                self.db.execute('ROLLBACK'); raise

    def close(self):
        with self.lock: self.db.close()

    def meta(self,key):
        r=self.db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
        return r[0] if r else None
    def setmeta(self,key,value): self.db.execute('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value)))
    def now(self): return max(float(self.clock()),float(self.meta('now') or 0))
    def _revision(self):
        v=int(self.meta('revision') or 0)+1; self.setmeta('revision',v);return v
    def _event(self,now,kind,actor,payload):
        old=self.db.execute('SELECT event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
        prev=old[0] if old else 'GENESIS';body=canonical({'at':now,'kind':kind,'actor':actor,'payload':payload,'previous':prev})
        digest=hashlib.sha256(body.encode()).hexdigest()
        self.db.execute('INSERT INTO events(at,kind,actor,payload,previous_hash,event_hash) VALUES(?,?,?,?,?,?)',(now,kind,actor,canonical(payload),prev,digest))
        self._revision()
        return self.db.execute('SELECT last_insert_rowid()').fetchone()[0]

    def new_account(self):
        token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);a=uid('account');now=self.now()
        with self.tx():
            self.db.execute('INSERT INTO accounts(id,token_hash,csrf,created,last_credit,last_seen) VALUES(?,?,?,?,?,?)',(a,hashlib.sha256(token.encode()).hexdigest(),csrf,now,now,now))
            self._event(now,'ACCOUNT_CREATED',None,{'account':a})
        return {'id':a,'token':token,'csrf':csrf}

    def resolve_session(self, token):
        if not isinstance(token,str) or len(token)>128: return None
        with self.lock:
            r=self.db.execute('SELECT id,csrf FROM accounts WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
            return dict(r) if r else None

    def _account(self,a):
        r=self.db.execute('SELECT * FROM accounts WHERE id=?',(a,)).fetchone()
        if not r: raise rules.Denied('UNKNOWN_ACCOUNT')
        return r

    def _actor(self,a,requested=None):
        ac=self._account(a);cid=requested or ac['active_character']
        c=self.db.execute('SELECT * FROM characters WHERE id=?',(cid,)).fetchone()
        if not c or c['account_id']!=a: raise rules.Denied('NOT_YOUR_CHARACTER')
        if cid!=ac['active_character']: raise rules.Denied('INACTIVE_CHARACTER')
        if not c['alive']: raise rules.Denied('CHARACTER_DEAD','This person has died. Create a new person or choose a living alternate.')
        return c

    def _new_item(self,kind,name,holder,cid=None,x=None,y=None,power=0):
        ident=uid('item')
        self.db.execute('INSERT INTO items(id,kind,name,holder_type,holder_id,x,y,power) VALUES(?,?,?,?,?,?,?,?)',(ident,kind,name,holder,cid,x,y,power))
        return ident

    def _credit(self,a,now,focused=True):
        ac=self._account(a);delta=max(0, min(now-ac['last_credit'],15))
        living=self.db.execute('SELECT alive FROM characters WHERE id=?',(ac['active_character'],)).fetchone()
        # One anchor per account, not per tab. Never accept client-reported duration.
        eligible=bool(focused and living and living['alive'] and now-ac['last_seen']<=20 and now-ac['last_input']<=60)
        self.db.execute('UPDATE accounts SET active_seconds=active_seconds+?,last_credit=?,last_seen=? WHERE id=?',(delta if eligible else 0,now,now if focused else ac['last_seen'],a))
        return delta if eligible else 0

    def heartbeat(self,a,focused=True):
        with self.tx():
            now=self.now();self._process_locked(now);return self._credit(a,now,focused is True)

    def process(self):
        with self.tx(): self._process_locked(self.now())

    def _process_locked(self,now):
        now=max(float(now),float(self.meta('now') or 0));self.setmeta('now',now)
        # Deadline check and transfer run under the SAME writer transaction.
        for corpse in self.db.execute('SELECT * FROM corpses WHERE reclaimed=0 AND expires_at<=? ORDER BY expires_at,id',(now,)).fetchall():
            count=self.db.execute("UPDATE items SET holder_type='reclaimed',holder_id=NULL,version=version+1 WHERE holder_type='corpse' AND holder_id=?",(corpse['id'],)).rowcount
            self.db.execute('UPDATE corpses SET reclaimed=1 WHERE id=?',(corpse['id'],))
            self._event(corpse['expires_at'],'ITEMS_RECLAIMED',corpse['character_id'],{'corpse_id':corpse['id'],'count':count})
        # Custody deadlines above are never starved by optional world catch-up.
        causal_batch=self.causal.run_due_locked(now)
        fault=causal_batch.get('blocked')
        if fault and fault.get('code','').startswith(('OBSERVATION_','PERCEPTION_','MISSING_SOURCE_OBSERVATION')):
            self.setmeta('perception_fault',canonical({'code':fault['code'],'at':now,'event_id':fault['event_id']}))
        if causal_batch['has_due']:
            return  # Keep accepted backlog; do not run tactics against stale state.
        self._market_tick(now)
        if self.meta('perception_fault') is not None:return
        # Perception integrity must not roll back already processed custody deadlines.
        self.db.execute('SAVEPOINT perception_frame')
        try:
            self._perception_frame(now)
            self.db.execute('RELEASE perception_frame')
        except rules.Denied as error:
            self.db.execute('ROLLBACK TO perception_frame');self.db.execute('RELEASE perception_frame')
            self.setmeta('perception_fault',canonical({'code':error.code,'at':now}))
            self._event(now,'PERCEPTION_FRAME_QUARANTINED',None,{'code':error.code})

    def _perception_frame(self,now):
        self.perception.archive.maybe_compact(now)
        # Bounded tactical stepping; do not run days of combat against absent people.
        previous=float(self.meta('npc_at') or now)
        if now-previous<.4: return
        world=self.perception.tactical_world()
        self.setmeta('npc_at',now);dt=min(1.0,max(0,now-previous));changed=False
        chars=self.db.execute('SELECT c.*,a.last_seen,a.active_character FROM characters c JOIN accounts a ON a.id=c.account_id WHERE c.alive=1').fetchall()
        for c in chars:
            offline=(now-c['last_seen']>30 or c['active_character']!=c['id'])
            if offline:
                if not c['offline'] and now-c['last_action']>30:
                    self.db.execute('UPDATE characters SET offline=1,x=?,y=?,hp=min(max_hp,hp+2),last_pvp=CASE WHEN hp+2>=max_hp THEN 0 ELSE last_pvp END,last_move=? WHERE id=?',(*SPAWN,now,c['id']))
                    self._event(now,'OFFLINE_ROUTINE',c['id'],{'routine':'shelter and recovery','no_missions_completed':True});changed=True
                continue
            if c['offline']:
                self.db.execute('UPDATE characters SET offline=0,last_move=? WHERE id=?',(now,c['id']));changed=True
            # A visibly marked live conduit is a world hazard, not a kill button.
            if self.blackout.hazard_live() and math.hypot(c['x']-22.5,c['y']-18.5)<1.0 and now-c['last_hurt']>=1:
                self._damage_locked(c['id'],5,now,'world');changed=True
        targets=[c for c in chars if c['active_character']==c['id'] and now-c['last_seen']<=30 and not in_town(c['x'],c['y'])]
        for n in world['npcs']:
            if n['hp']<=0: continue
            # LOS + limited sensory range; no reading remote inventory or hidden players.
            seen=self.perception.sight_targets(n,targets,world,now)
            if not seen: continue
            c=min(seen,key=lambda c:math.hypot(c['x']-n['x'],c['y']-n['y']))
            dx=c['x']-n['x'];dy=c['y']-n['y'];d=math.hypot(dx,dy)
            if d<1.5 and now-n.get('attack_at',0)>1.8:
                n['attack_at']=now;self._damage_locked(c['id'],9 if n['role']=='boss' else 3,now,'pve');changed=True
            elif n['role']!='boss' and d>1.1:
                speed=.58*dt;nx=n['x']+dx/max(d,.01)*speed;ny=n['y']+dy/max(d,.01)*speed
                if passable(world,nx,ny) and not in_town(nx,ny): n['x']=nx;n['y']=ny;changed=True
        if changed: self.setmeta('world',canonical(world));self._revision()

    def intent(self, account_id, request):
        try:
            if not isinstance(request,dict) or set(request)-{'v','id','op','actor','args'}: raise rules.Denied('INVALID_INTENT')
            if type(request.get('v')) is not int or request['v']!=1: raise rules.Denied('VERSION_UNSUPPORTED')
            if request.get('actor') is not None and not isinstance(request['actor'],str): raise rules.Denied('INVALID_REFERENCE')
            inv=request.get('id');op=request.get('op')
            if not isinstance(inv,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{8,80}',inv): raise rules.Denied('INVALID_INVOCATION')
            if not isinstance(op,str) or not isinstance(request.get('args',{}),dict): raise rules.Denied('INVALID_INTENT')
            body=canonical(request);digest=hashlib.sha256(body.encode()).hexdigest()
        except (ValueError,TypeError,rules.Denied) as e:
            return {'ok':False,'code':getattr(e,'code','INVALID_PARAMETER'),'message':str(e)}
        with self.tx():
            now=self.now();self._process_locked(now);self._account(account_id)
            old=self.db.execute('SELECT * FROM receipts WHERE account_id=? AND invocation=?',(account_id,inv)).fetchone()
            if old:
                if old['digest']!=digest: return {'ok':False,'code':'ID_REUSED','message':'That invocation ID already describes a different request.'}
                return json.loads(old['response'])
            if self.meta('perception_fault') is not None:
                return {'ok':False,'code':'PERCEPTION_UNAVAILABLE','message':'Perception integrity needs recovery; world actions are paused.'}
            if self.causal.has_due(now):
                # A temporary barrier is not a permanent idempotency receipt.
                # The identical request may be retried once catch-up completes.
                return {'ok':False,'code':'WORLD_CATCHUP_PENDING',
                        'message':'The world is catching up after time away. No action was applied.',
                        'receipt_id':inv,'operation':op,'server_time':now,
                        'revision':int(self.meta('revision'))}
            self.db.execute('SAVEPOINT action')
            try:
                result=self._dispatch(account_id,op,request.get('actor'),request.get('args',{}),now)
                self.db.execute('RELEASE action')
                out={'ok':True,'code':'ADMITTED','result':result}
            except rules.Denied as e:
                self.db.execute('ROLLBACK TO action');self.db.execute('RELEASE action')
                out={'ok':False,'code':e.code,'message':e.message}
            out.update({'receipt_id':inv,'operation':op,'server_time':now,'revision':int(self.meta('revision'))})
            self.db.execute('INSERT INTO receipts VALUES(?,?,?,?)',(account_id,inv,digest,canonical(out)))
            return out

    def _fields(self,args,allowed):
        if set(args)-set(allowed): raise rules.Denied('UNKNOWN_ARGUMENT','The server does not accept those fields.')
        for key in ('item_id','target_id','character_id','template_id'):
            if key in args and args[key] is not None and (not isinstance(args[key],str) or len(args[key])>128):
                raise rules.Denied('INVALID_REFERENCE','Object references must be bounded strings.')

    def _dispatch(self,a,op,requested,args,now):
        if op=='create':
            self._fields(args,{'name','specialty','appearance','template_id','species','base_class','job_role','start_path'})
            choice=self._build_choice(args)
            ac=self._account(a);count=self.db.execute('SELECT count(*) FROM characters WHERE account_id=? AND alive=1',(a,)).fetchone()[0]
            if count>=rules.slots(ac['active_seconds']): raise rules.Denied('SLOT_LOCKED','A second living character unlocks after more than 24 active hours.')
            name=rules.player_name(args.get('name'));spec=CLASSES[choice['base_class']]['specialty']
            if spec not in rules.SPECIALTIES: raise rules.Denied('UNKNOWN_SPECIALTY')
            tid=args.get('template_id');base={}
            if tid:
                old=self.db.execute('SELECT * FROM characters WHERE id=? AND account_id=?',(tid,a)).fetchone()
                if not old: raise rules.Denied('UNKNOWN_TEMPLATE')
                base=json.loads(old['appearance'])
            ap=rules.appearance(args.get('appearance',base));cid=uid('person')
            self.db.execute('INSERT INTO characters(id,account_id,created_at,name,appearance,specialty,template_id,x,y,last_move,last_action,focus) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(cid,a,now,name,canonical(ap),spec,tid,*SPAWN,now,now,6 if spec=='hexer' else 4))
            self.db.execute('UPDATE accounts SET active_character=?,last_seen=?,last_credit=?,last_input=? WHERE id=?',(cid,now,now,now,a))
            self._new_item('blade','Civic utility blade','character',cid,power=2)
            self._new_item('medkit','Sealed field dressing','character',cid)
            self._initialize_build(cid,choice,now)
            self._event(now,'CHARACTER_CREATED',cid,{'template_id':tid,'new_identity':True})
            return {'character_id':cid}
        if op=='select':
            self._fields(args,{'character_id'});cid=args.get('character_id')
            c=self.db.execute('SELECT * FROM characters WHERE id=? AND account_id=? AND alive=1',(cid,a)).fetchone()
            if not c: raise rules.Denied('NO_LIVING_CHARACTER')
            self.db.execute('UPDATE accounts SET active_character=?,last_seen=?,last_credit=?,last_input=? WHERE id=?',(cid,now,now,now,a))
            self.db.execute('UPDATE characters SET last_move=?,last_action=?,offline=0 WHERE id=?',(now,now,cid))
            self._event(now,'CHARACTER_SELECTED',cid,{})
            return {'character_id':cid}
        if op not in OPS and op not in ('move','turn','interact','loot','attack','cast','scan','rest','use_medkit'): raise rules.Denied('UNKNOWN_OPERATION')
        c=self._actor(a,requested);world=json.loads(self.meta('world'))
        self.db.execute('UPDATE accounts SET last_input=?,last_seen=? WHERE id=?',(now,now,a))
        self.db.execute('UPDATE characters SET last_action=?,offline=0 WHERE id=?',(now,c['id']))
        if op in OPS:return self._exp_dispatch(c,op,args,now,world)
        if op=='move':
            self._fields(args,{'forward','strafe','yaw'})
            fw=rules.number(args.get('forward',0),-1,1,'forward');st=rules.number(args.get('strafe',0),-1,1,'strafe');yaw=rules.number(args.get('yaw',c['yaw']),-1e6,1e6,'yaw')%(2*math.pi)
            length=max(1,math.hypot(fw,st));fw/=length;st/=length
            dt=min(.22,max(0,now-c['last_move']));speed=2.6*dt*(1+self._effects(c)['speed']+(.1 if obj(c,'buffs',{}).get('stride',0)>now else 0))
            dx=(math.cos(yaw)*fw-math.sin(yaw)*st)*speed;dy=(math.sin(yaw)*fw+math.cos(yaw)*st)*speed
            nx=c['x'];ny=c['y']
            # Axis-separated collision with small substeps; request cannot teleport.
            steps=max(1,math.ceil(math.hypot(dx,dy)/.08))
            for _ in range(steps):
                if passable(world,nx+dx/steps,ny): nx+=dx/steps
                if passable(world,nx,ny+dy/steps): ny+=dy/steps
            self.db.execute('UPDATE characters SET x=?,y=?,yaw=?,last_move=?,version=version+1 WHERE id=?',(nx,ny,yaw,now,c['id']))
            if math.hypot(nx-c['x'],ny-c['y'])>.02:self._goal_signal(c['id'],'move',1,now)
            self._revision();return {'x':nx,'y':ny,'yaw':yaw}
        if op=='turn':
            self._fields(args,{'yaw'});yaw=rules.number(args.get('yaw'),-1e6,1e6,'yaw')%(2*math.pi)
            self.db.execute('UPDATE characters SET yaw=?,version=version+1 WHERE id=?',(yaw,c['id']));return {'yaw':yaw}
        if op=='loot':
            self._fields(args,{'item_id','version'});return self._loot(c,args.get('item_id'),args.get('version'),now,world)
        if op in ('attack','cast'):
            if op=='cast' and not any(x in self._abilities(c) for x in ('ward','pulse')):raise rules.Denied('ABILITY_LOCKED','Learn wardcraft or choose a focus practice.')
            r=self._attack(c,args,now,world,op)
            self._goal_signal(c['id'],'practice',1,now);return r
        if op=='interact':
            self._fields(args,{'target_id'})
            tid=args.get('target_id');features=[x for x in world['features'] if x['id']==tid] if tid else sorted(world['features'],key=lambda x:math.hypot(x['x']-c['x'],x['y']-c['y']))
            f=features[0] if features else None
            if not f or math.hypot(f['x']-c['x'],f['y']-c['y'])>2.3 or not line_of_sight(world,c['x'],c['y'],f['x'],f['y']): raise rules.Denied('OUT_OF_REACH')
            local_reports=self.perception.tell(f['id'],c,world,now)
            visit=self._place_visit(c,f,now)
            if visit:
                if local_reports:
                    visit['reports']=local_reports
                    visit['message']+=' '+local_reports[0]['text']
                return visit
            if f['id']=='moth':
                data=self.db.execute("SELECT id FROM items WHERE holder_type='character' AND holder_id=? AND kind='relay_data'",(c['id'],)).fetchone()
                if data:
                    self.db.execute("UPDATE items SET holder_type='reclaimed',holder_id=NULL,version=version+1 WHERE id=?",(data['id'],))
                    self.db.execute("UPDATE characters SET cred=cred+90,job='complete' WHERE id=?",(c['id'],))
                    self._award_xp(c['id'],6,now,'relay delivery')
                    self._goal_signal(c['id'],'deliver',1,now)
                    self._event(now,'JOB_COMPLETED',c['id'],{'reward':90,'data_item':data['id']})
                    return {'message':'Moth: You brought the relay back. Ninety cred. The city will remember.'}
                return {'message':local_reports[0]['text'] if local_reports else 'Moth: The city is yours to explore. My relay request is optional; open Goals when a job suits you.', 'reports':local_reports,'open_goals':not bool(local_reports)}
            if f['id']=='relay':
                if c['job']=='complete':return {'message':'This delivery has already been paid. Explore other opportunities.'}
                old=self.db.execute("SELECT id FROM items WHERE holder_type='character' AND holder_id=? AND kind='relay_data'",(c['id'],)).fetchone()
                if old: return {'message':'You already carry this relay copy.'}
                ident=self._new_item('relay_data','Rain relay data','character',c['id'])
                self.db.execute("UPDATE characters SET job='return',heat=heat+1 WHERE id=?",(c['id'],))
                self._event(now,'RELAY_COPIED',c['id'],{'item_id':ident})
                return {'message':'Relay copied. Return to Moth in town.','item_id':ident}
            if f['kind']=='shelter': return self._rest(c,now)
            description=self.blackout.describe(f['id'])
            return {'message':description or f['name']}
        if op=='scan':
            self._fields(args,set());self._goal_signal(c['id'],'scan',1,now);near=[self.blackout.describe(f['id']) or f['name'] for f in world['features'] if math.hypot(c['x']-f['x'],c['y']-f['y'])<6+self._effects(c)['scan']]
            return {'message':'Nearby: '+(', '.join(near) if near else 'quiet streets'),'signals':near}
        if op=='rest': self._fields(args,set());return self._rest(c,now)
        if op=='use_medkit':
            self._fields(args,set());it=self.db.execute("SELECT * FROM items WHERE holder_type='character' AND holder_id=? AND kind='medkit' LIMIT 1",(c['id'],)).fetchone()
            if not it: raise rules.Denied('NO_DRESSING')
            if c['hp']>=c['max_hp']: raise rules.Denied('ALREADY_HEALTHY')
            self.db.execute("UPDATE items SET holder_type='reclaimed',holder_id=NULL,version=version+1 WHERE id=?",(it['id'],))
            self.db.execute('UPDATE characters SET hp=min(max_hp,hp+10),last_pvp=CASE WHEN hp+10>=max_hp THEN 0 ELSE last_pvp END WHERE id=?',(c['id'],))
            self._event(now,'DRESSING_USED',c['id'],{'item_id':it['id']});return {'message':'Field dressing applied.'}

    def _rest(self,c,now):
        if not in_town(c['x'],c['y']): raise rules.Denied('NOT_SAFE','Rest inside town.')
        self.db.execute('UPDATE characters SET hp=max_hp,focus=?,heat=max(0,heat-1),last_pvp=0 WHERE id=?',(self._focus_max(c),c['id']))
        self._event(now,'RESTED',c['id'],{});return {'message':'Recovered in the town shelter.'}

    def _loot(self,c,item_id,version,now,world):
        it=self.db.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        if not it: raise rules.Denied('UNKNOWN_ITEM')
        if isinstance(version,bool) or not isinstance(version,int) or version!=it['version']: raise rules.Denied('STALE_VERSION','This item changed custody. Refresh and try again.')
        if it['holder_type'] not in ('world','corpse'): raise rules.Denied('NOT_AVAILABLE')
        x,y=it['x'],it['y']
        if it['holder_type']=='corpse':
            b=self.db.execute('SELECT * FROM corpses WHERE id=?',(it['holder_id'],)).fetchone()
            if not b or b['reclaimed'] or now>=b['expires_at']: raise rules.Denied('RECOVERY_EXPIRED')
            eligible=json.loads(b['eligible_ids']);own=c['account_id']==b['account_id']
            if b['cause']=='pvp' and (not own or c['id'] not in eligible): raise rules.Denied('PVP_LOOT_PROTECTED','PvP cannot transfer the victim’s belongings to another account.')
            if own and c['id'] not in eligible: raise rules.Denied('NOT_PREEXISTING_ALTERNATE')
            if not own and in_town(b['x'],b['y']): raise rules.Denied('TOWN_PROPERTY_PROTECTED')
            x,y=b['x'],b['y']
        if x is None or math.hypot(c['x']-x,c['y']-y)>2.3 or not line_of_sight(world,c['x'],c['y'],x,y): raise rules.Denied('OUT_OF_REACH')
        n=self.db.execute("UPDATE items SET holder_type='character',holder_id=?,x=NULL,y=NULL,equipped=0,version=version+1 WHERE id=? AND version=?",(c['id'],item_id,version)).rowcount
        if n!=1: raise rules.Denied('STALE_VERSION')
        self._event(now,'CUSTODY_TRANSFERRED',c['id'],{'item_id':item_id,'from':it['holder_type'],'from_holder':it['holder_id'],'to_holder':c['id'],'version':version+1})
        return {'item_id':item_id,'version':version+1,'message':it['name']+' recovered.'}

    def _power(self,c):
        gear=self.db.execute("SELECT coalesce(sum(power),0) FROM items WHERE holder_type='character' AND holder_id=? AND equipped=1",(c['id'],)).fetchone()[0]
        return {**dict(c),'power':10+min(c['level'],100)*.15+gear+self._effects(c)['damage']*2+self._effects(c)['armor']*12}

    def _attack(self,c,args,now,world,op):
        self._fields(args,{'target_id'});tid=args.get('target_id');target=None;is_player=False
        if tid:
            target=self.db.execute('SELECT * FROM characters WHERE id=? AND alive=1',(tid,)).fetchone()
            is_player=bool(target)
            if is_player: rules.pvp_permission(self._power(c),self._power(target),in_town)
            else: target=next((n for n in world['npcs'] if n['id']==tid and n['hp']>0),None)
        if not target:
            candidates=[n for n in world['npcs'] if n['hp']>0]
            # Attack only a cone in front. No auto-target through walls.
            candidates=[n for n in candidates if abs(math.atan2(math.sin(math.atan2(n['y']-c['y'],n['x']-c['x'])-c['yaw']), math.cos(math.atan2(n['y']-c['y'],n['x']-c['x'])-c['yaw'])))<.65]
            if candidates: target=min(candidates,key=lambda n:math.hypot(c['x']-n['x'],c['y']-n['y']))
        reach=4 if op=='cast' else 2.6 if op=='lunge' else 1.9
        if not target or math.hypot(c['x']-target['x'],c['y']-target['y'])>reach or not line_of_sight(world,c['x'],c['y'],target['x'],target['y']): raise rules.Denied('NO_TARGET','No target in range.')
        if in_town(c['x'],c['y']) or in_town(target['x'],target['y']): raise rules.Denied('TOWN_PEACE')
        cooldown=(1.2 if op=='cast' else .85 if op=='lunge' else .55)*(1-min(.2,self._effects(c)['cooldown']))
        if now-c['last_attack']<cooldown: raise rules.Denied('RECOVERING','Wait for your weapon to recover.')
        if op=='cast' and c['focus']<1: raise rules.Denied('NO_FOCUS')
        damage=(7 if op=='cast' else (5 if c['specialty']=='blade' else 4))+self._effects(c)['damage']
        hand=self.db.execute("SELECT coalesce(max(power),2) FROM items WHERE holder_type='character' AND holder_id=? AND equipped=1 AND slot='hand'",(c['id'],)).fetchone()[0]
        if op!='cast':damage+=max(0,hand-2)
        if obj(c,'buffs',{}).get('overcharge',0)>now:damage+=1
        self.db.execute('UPDATE characters SET last_attack=?,focus=focus-? WHERE id=?',(now,1 if op=='cast' else 0,c['id']))
        if is_player:
            self.db.execute('UPDATE characters SET last_pvp=? WHERE id=?',(now,target['id']))
            self._damage_locked(target['id'],damage,now,'pvp')
        else:
            target['hp']=max(0,target['hp']-damage)
            if target['hp']==0:
                self._award_xp(c['id'],40 if target['role']=='boss' else 8,now,'encounter')
                self._new_item('salvage','Sentinel circuit','world',None,target['x'],target['y'])
                self._event(now,'ENEMY_FELL',c['id'],{'npc':target['id'],'boss':target['role']=='boss'})
            self.setmeta('world',canonical(world))
        self._event(now,'CAST' if op=='cast' else 'MELEE',c['id'],{'target':target['id'],'damage':damage})
        return {'damage':damage,'target_id':target['id'],'message':'Ward pulse.' if op=='cast' else 'Blade strike.'}

    def apply_damage(self,cid,amount,cause='pve'):
        """Internal world operation; clients cannot choose their own death cause."""
        with self.tx():
            now=self.now();self._process_locked(now);return self._damage_locked(cid,amount,now,cause)

    def _damage_locked(self,cid,amount,now,cause):
        c=self.db.execute('SELECT * FROM characters WHERE id=?',(cid,)).fetchone()
        if not c or not c['alive']: return None
        resistance=min(.5,self._effects(c)['armor']+(.2 if obj(c,'buffs',{}).get('guard',0)>now else 0))
        hp=max(0,c['hp']-max(0,float(amount))*(1-resistance))
        self.db.execute('UPDATE characters SET hp=?,last_hurt=?,version=version+1 WHERE id=?',(hp,now,cid))
        if hp>0: self._revision();return {'hp':hp}
        # A PvP injury remains relevant until full recovery; waiting out a timeout
        # cannot launder the belongings through an environmental/NPC death.
        actual='pvp' if cause=='pvp' or c['last_pvp']>0 else 'pve'
        eligible=[r['id'] for r in self.db.execute('SELECT id FROM characters WHERE account_id=? AND id!=? AND alive=1 AND created_at<=?',(c['account_id'],cid,now))]
        deadline=now+(rules.LONG_RECOVERY if eligible else rules.SHORT_RECOVERY);bid=uid('body')
        self.db.execute('UPDATE characters SET alive=0,hp=0,dead_at=? WHERE id=?',(now,cid))
        self.db.execute('INSERT INTO corpses(id,character_id,account_id,died_at,expires_at,eligible_ids,cause,x,y) VALUES(?,?,?,?,?,?,?,?,?)',(bid,cid,c['account_id'],now,deadline,canonical(eligible),actual,c['x'],c['y']))
        self.db.execute("UPDATE items SET holder_type='corpse',holder_id=?,x=?,y=?,equipped=0,version=version+1 WHERE holder_type='character' AND holder_id=?",(bid,c['x'],c['y'],cid))
        self._event(now,'CHARACTER_DIED',cid,{'corpse_id':bid,'cause':actual,'expires_at':deadline,'eligible_alternates':eligible})
        return {'corpse_id':bid,'expires_at':deadline,'eligible_alternates':eligible,'cause':actual}

    def snapshot(self,a,geometry_id=None):
        with self.tx():
            now=self.now();self._process_locked(now);ac=self._account(a)
            chars=[dict(c) for c in self.db.execute('SELECT * FROM characters WHERE account_id=? ORDER BY created_at,id',(a,))]
            for c in chars: c['appearance']=json.loads(c['appearance']);c['alive']=bool(c['alive']);self._project_character(c)
            player=next((c for c in chars if c['id']==ac['active_character']),None)
            world=json.loads(self.meta('world'));epoch=float(self.meta('epoch'))
            world.update({'time':now,'epoch':epoch,'atmosphere':self.causal.atmosphere(now),'continuum':self.causal.projection(now),'revision':int(self.meta('revision'))})
            inventory=[] if not player else [dict(i) for i in self.db.execute("SELECT id,kind,name,authority,holder_type,holder_id,version,sku,slot,equipped,power FROM items WHERE holder_type='character' AND holder_id=?",(player['id'],))]
            visible_items=[dict(i) for i in self.db.execute("SELECT id,kind,name,holder_type,holder_id,x,y,version FROM items WHERE holder_type IN ('world','corpse')")]
            bodies=[]
            for b in self.db.execute('SELECT b.*,c.name FROM corpses b JOIN characters c ON c.id=b.character_id WHERE b.reclaimed=0'):
                d=dict(b);d['own']=b['account_id']==a;d['eligible']=bool(player and player['id'] in json.loads(b['eligible_ids']))
                d.pop('eligible_ids');d.pop('account_id');bodies.append(d)
            others=[{'id':c['id'],'name':c['name'],'x':c['x'],'y':c['y'],'hp':c['hp'],'max_hp':c['max_hp'],'level':c['level'],'specialty':c['specialty'],'species':c['species'],'base_class':c['base_class'],'job_role':c['job_role'],'secondary_class':c['secondary_class'],'skills':json.loads(c['skills']),'appearance':json.loads(c['appearance'])} for c in self.db.execute('SELECT c.* FROM characters c JOIN accounts a ON a.active_character=c.id WHERE c.alive=1 AND c.account_id!=? AND a.last_seen>?',(a,now-30))]
            # An audit row is not public knowledge. Own receipts remain available;
            # local reports are separately acquired through sight/conversation.
            events=[{'seq':e['seq'],'at':e['at'],'kind':e['kind'],'actor':e['actor'],'payload':json.loads(e['payload'])}
                for e in self.db.execute("SELECT e.* FROM events e JOIN characters c ON c.id=e.actor WHERE c.account_id=? AND e.kind NOT IN ('CHARACTER_CREATED','CHARACTER_SELECTED') ORDER BY e.seq DESC LIMIT 12",(a,))]
            def visible(o):
                return bool(player and player['alive'] and o.get('x') is not None and o.get('y') is not None
                    and math.hypot(o['x']-player['x'],o['y']-player['y'])<=27
                    and line_of_sight(world,player['x'],player['y'],o['x'],o['y']))
            world['npcs']=[n for n in world['npcs'] if visible(n)]
            others=[o for o in others if visible(o)]
            bodies=[b for b in bodies if b['own'] or visible(b)]
            own_bodies={b['id'] for b in bodies if b['own']}
            visible_items=[i for i in visible_items if i['holder_id'] in own_bodies or visible(i)]
            perception_ok=self.meta('perception_fault') is None
            reports=self.perception.public_reports(player['id'] if player and player['alive'] else None,now) if perception_ok else []
            world['perception']={'available':perception_ok}
            extra=self._snapshot_expansion(player,world,now)
            world['power_grid']=self.blackout.projection()
            world['geometry_id']='open030:'+str(world['seed'])
            if geometry_id==world['geometry_id']:
                for key in ('grid','terrain','features','buildings','regions','decorations','safe_zone'):world.pop(key,None)
            return {'schema':'neon-veil/projection/0.30','account':{'id':a,'active_seconds':ac['active_seconds'],'slots':rules.slots(ac['active_seconds']),'characters':chars},
              'player':player,'inventory':inventory,'items':visible_items,'corpses':bodies,'players':others,'world':world,'events':events,'reports':reports,
              **extra,
              'rules':{'second_slot_after_seconds':86400,'strictly_greater':True,'pve_recovery':{'without_alternate':300,'with_alternate':900},'pvp_loot':'same-account pre-existing recovery only','town_pvp':False}}
