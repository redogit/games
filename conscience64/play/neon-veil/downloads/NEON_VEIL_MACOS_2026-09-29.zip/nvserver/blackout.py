"""T04 power/services over the existing causal engine.

One bounded incident, not a complete NPC repair system. All mutations run inside
the engine's transaction/savepoint. No player-facing scheduling or repair API.
"""
from __future__ import annotations
import json
from . import rules

SCHEMA = "neon-veil/grid-services/v1"
PREFIX = "rainmarket.blackout.first"
POLICY = {
    "capacity_loss": .35,
    "backup_capacity": .85,
    "exposure_interval": 180,
    "backup_delay": 900,
    "supply_premium": .15,
}

def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)

class GridServices:
    def __init__(self, service):
        self.owner=service
        self.db=service.db
        for kind, handler in (
            ("GRID_WARNING",self.warning),
            ("GRID_OVERLOADED",self.overload),
            ("REFRIGERATION_EXPOSURE",self.exposure),
            ("GRID_BACKUP_CONNECTED",self.backup),
        ):
            service.causal.register(kind,handler)

    def install(self, now):
        if self.owner.meta("rainmarket_power") is not None:
            self.state()  # Validate schema rather than silently replace a saved object.
            return
        self.write({
            "schema":SCHEMA, "id":"rainmarket-circuit", "phase":"QUIET",
            "capacity":1., "damage":0., "revision":0, "attached_at":float(now),
            "since":float(now), "incident_id":None, "repair_required":False,
            "conduit_isolated":False, "spoiled_units":0, "exposure_seconds":0,
            "exposure_index":0, "policy":dict(POLICY), "last_event":None,
        })
        self.owner._event(now,"GRID_SERVICES_ATTACHED",None,{
            "schema":SCHEMA,"history":"Future weather only; no retrospective incident."})

    def state(self):
        raw=self.owner.meta("rainmarket_power")
        if raw is None:
            raise rules.Denied("GRID_NOT_ATTACHED")
        row=json.loads(raw)
        if row.get("schema")!=SCHEMA:
            raise rules.Denied("GRID_SCHEMA_CONFLICT")
        return row

    def write(self,row):
        self.owner.setmeta("rainmarket_power",encode(row))

    def _set(self,row,event,**changes):
        row.update(changes)
        row["revision"]+=1
        row["last_event"]=event["event_id"]
        self.write(row)

    def on_weather(self,event,weather):
        row=self.state()
        # Migrations can have old due weather in backlog. Do not invent past damage.
        if event["scheduled_at"] < row["attached_at"]:
            return
        phase=event["payload"]["phase"]
        if row["phase"]=="QUIET" and phase%4==1:
            self.owner.causal.schedule(PREFIX+".warning","GRID_WARNING",
                event["scheduled_at"],(event["event_id"],),{})
        elif weather=="storm" and row["phase"] in ("QUIET","WARNING"):
            self.owner.causal.schedule(PREFIX+".outage","GRID_OVERLOADED",
                event["scheduled_at"],(event["event_id"],),{})

    def warning(self,event,now):
        row=self.state()
        if row["phase"]!="QUIET":
            raise rules.Denied("GRID_PHASE_CONFLICT")
        self._set(row,event,phase="WARNING",since=event["scheduled_at"])
        return {"applied":True,"circuit":row["id"],
                "message":"A transformer hum rises behind the market's lights."}

    def _bump_quotes(self):
        self.db.execute("""UPDATE offers SET version=version+1
            WHERE shop_id='forge'
            OR (shop_id='noodle-house' AND sku='noodles')
            OR (shop_id='lantern-goods' AND sku='salvage')""")

    def overload(self,event,now):
        row=self.state()
        if row["phase"] not in ("QUIET","WARNING") or row["incident_id"] is not None:
            raise rules.Denied("GRID_PHASE_CONFLICT")
        due=event["scheduled_at"]
        self.owner._market_tick(due)
        policy=row["policy"]
        self._set(row,event,phase="OUTAGE",incident_id=PREFIX,since=due,
            capacity=round(1-policy["capacity_loss"],6),damage=policy["capacity_loss"],
            repair_required=True,conduit_isolated=True)
        self._bump_quotes()
        interval=policy["exposure_interval"]
        # Explicit finite events: interval equality precedes backup restoration.
        count=policy["backup_delay"]//interval
        for i in range(1,count+1):
            self.owner.causal.schedule(f"{PREFIX}.exposure.{i}",
                "REFRIGERATION_EXPOSURE",due+i*interval,(event["event_id"],),
                {"incident":PREFIX,"index":i})
        self.owner.causal.schedule(PREFIX+".backup","GRID_BACKUP_CONNECTED",
            due+policy["backup_delay"],(event["event_id"],),{"incident":PREFIX})
        return {"applied":True,"circuit":row["id"],"capacity":row["capacity"],
            "closed_service":"forge","refrigeration":"noodle-house",
            "isolated_hazard":"hazard",
            "message":"Rainmarket's main feeder trips. Hexworks shutters; emergency lamps remain on."}

    def exposure(self,event,now):
        row=self.state()
        if event["payload"].get("incident")!=row["incident_id"]:
            raise rules.Denied("GRID_INCIDENT_CONFLICT")
        index=event["payload"].get("index")
        if type(index) is not int or index!=row["exposure_index"]+1:
            raise rules.Denied("EXPOSURE_SEQUENCE_CONFLICT")
        if row["phase"]!="OUTAGE":
            raise rules.Denied("GRID_PHASE_CONFLICT")
        self.owner._market_tick(event["scheduled_at"])
        offer=self.db.execute("""SELECT stock FROM offers
            WHERE shop_id='noodle-house' AND sku='noodles'""").fetchone()
        if offer is None:
            raise rules.Denied("MISSING_REFRIGERATOR_STOCK")
        removed=min(1,offer["stock"])
        if removed:
            self.db.execute("""UPDATE offers SET stock=stock-?,version=version+1
                WHERE shop_id='noodle-house' AND sku='noodles'""",(removed,))
        self._set(row,event,spoiled_units=row["spoiled_units"]+removed,
            exposure_seconds=row["exposure_seconds"]+row["policy"]["exposure_interval"],
            exposure_index=index)
        return {"applied":True,"shop":"noodle-house","sku":"noodles","removed":removed,
            "exposure_index":index,"message":"The kitchen discards stock from its unpowered cold store."}

    def backup(self,event,now):
        row=self.state()
        if row["phase"]!="OUTAGE" or event["payload"].get("incident")!=row["incident_id"]:
            raise rules.Denied("GRID_PHASE_CONFLICT")
        if row["exposure_seconds"]!=row["policy"]["backup_delay"]:
            raise rules.Denied("EXPOSURE_PENDING")
        self.owner._market_tick(event["scheduled_at"])
        self._set(row,event,phase="BACKUP",capacity=row["policy"]["backup_capacity"],
                  since=event["scheduled_at"])
        self._bump_quotes()
        return {"applied":True,"circuit":row["id"],"capacity":row["capacity"],
            "spoiled_units":row["spoiled_units"],"repair_required":True,
            "mechanism":"automatic alternate feeder; not NPC repair",
            "message":"An alternate feeder reconnects the market. The damaged conduit stays isolated."}

    def restock_allowed(self,shop,sku):
        if self.owner.meta("rainmarket_power") is None:
            return True
        row=self.state()
        return not (row["phase"]=="OUTAGE" and
            (shop=="forge" or (shop=="noodle-house" and sku=="noodles")))

    def price_multiplier(self,shop,sku):
        row=self.state()
        return 1+row["policy"]["supply_premium"] if (
            row["phase"]=="OUTAGE" and shop=="lantern-goods" and sku=="salvage") else 1.

    def service_status(self,shop):
        row=self.state()
        closed=shop=="forge" and row["phase"]=="OUTAGE"
        refrigeration=not(shop=="noodle-house" and row["phase"]=="OUTAGE")
        if closed:
            note="Hexworks has no safe machine power. The counter is closed; the doorway remains open."
        elif not refrigeration:
            note="Emergency kitchen service remains open. Cold storage is offline; hot drinks and shelter remain available."
        elif row["phase"]=="BACKUP" and shop in ("forge","noodle-house"):
            note="Trading on the alternate feeder. Transformer maintenance is still required."
        else:
            note="Service is open."
        return {"open":not closed,"refrigeration":refrigeration,
                "note":note,"circuit_revision":row["revision"]}

    # Small public interface; no component may infer openness from lamp appearance.
    service = service_status

    def hazard_live(self):
        return not self.state()["conduit_isolated"]

    def projection(self):
        row=self.state()
        return {"schema":SCHEMA,"id":row["id"],"phase":row["phase"],
            "capacity":row["capacity"],"revision":row["revision"],
            "repair_required":row["repair_required"],
            "region":{"x1":1,"y1":1,"x2":32,"y2":26},
            "transformer":{"id":"grid-terminal","x":8.5,"y":7.5},
            "isolated_hazards":["hazard"] if row["conduit_isolated"] else [],
            "essential_services_protected":True}

    def describe(self,feature_id):
        row=self.state()
        if feature_id=="hazard":
            return ("Conduit isolated for maintenance. This passage is no longer electrified."
                    if not self.hazard_live() else "Live voltage. Keep your distance.")
        if feature_id=="grid-terminal":
            return {
                "QUIET":"Civic grid online. Emergency services and town peace remain independent.",
                "WARNING":"The transformer is straining. An approaching storm is loading the feeder.",
                "OUTAGE":"Main feeder tripped. Hexworks is closed; kitchen refrigeration is off. Emergency town services remain open.",
                "BACKUP":"Alternate feeder online. The transformer still needs maintenance; the damaged conduit remains isolated."
            }[row["phase"]]
        return None
