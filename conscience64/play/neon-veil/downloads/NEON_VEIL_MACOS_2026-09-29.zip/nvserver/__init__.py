"""NEON//VEIL authoritative local development service."""
