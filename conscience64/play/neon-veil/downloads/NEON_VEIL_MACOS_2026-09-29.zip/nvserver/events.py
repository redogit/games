"""Durable causal scheduling on the game's existing SQLite transaction boundary.

No network execution, user code, clock endpoint, or client-supplied world facts.
Reducers are trusted server registrations. A recorded outcome and its effect are
one transaction; rejected/failed work stays pending rather than claiming success.
"""
from __future__ import annotations
import hashlib
import json
import math
import re
from typing import Callable
from . import rules
from .world import atmosphere

MAX_BATCH = 256
WEATHER_PERIOD = 90
SCHEMA = 'neon-veil/causal-event/v1'

def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def timestamp(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise rules.Denied('INVALID_EVENT_TIME')
    return float(value)

class CausalEngine:
    def __init__(self, service):
        self.service = service
        self.db = service.db
        self.handlers: dict[str, Callable] = {}
        self.register('WEATHER_CHANGED', self._weather)

    def register(self, kind: str, reducer: Callable):
        """Trusted local composition only. Not exposed by the HTTP router."""
        if not isinstance(kind,str) or not re.fullmatch(r'[A-Z_]{1,64}',kind) or not callable(reducer):
            raise ValueError('A named server reducer is required')
        if kind in self.handlers:
            raise ValueError('Reducer replacement requires an explicit migration')
        self.handlers[kind] = reducer

    def install(self, now):
        """Called within startup's existing BEGIN IMMEDIATE; never executescript."""
        self.db.execute('''CREATE TABLE IF NOT EXISTS causal_schedule(
            ordinal INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
            scheduled_at REAL NOT NULL, parents TEXT NOT NULL, payload TEXT NOT NULL,
            digest TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending'
                CHECK(status IN ('pending','committed'))
        )''')
        self.db.execute("CREATE INDEX IF NOT EXISTS causal_due ON causal_schedule(status,scheduled_at,ordinal)")
        self.db.execute('''CREATE TABLE IF NOT EXISTS causal_outcomes(
            event_id TEXT PRIMARY KEY REFERENCES causal_schedule(event_id),
            audit_seq INTEGER UNIQUE NOT NULL REFERENCES events(seq),
            scheduled_at REAL NOT NULL, committed_at REAL NOT NULL,
            receipt TEXT NOT NULL
        )''')
        if self.service.meta('causal_schema') is None:
            phase = int(self.service.meta('phase') or 0)
            self.service.setmeta('causal_schema', SCHEMA)
            self.service.setmeta('causal_attached_phase', phase)
            self.service._event(now, 'CAUSAL_ENGINE_ATTACHED', None, {
                'schema': SCHEMA, 'phase': phase,
                'history_boundary': 'Earlier weather history remains unchanged; no invented replay.'})
            self._schedule_phase(phase + 1, ())

    def schedule(self, event_id, kind, scheduled_at, parents=(), payload=None):
        """Must participate in a caller-owned transaction. Identity is immutable."""
        if not self.db.in_transaction:
            raise RuntimeError('Schedule requires the authoritative transaction')
        if not isinstance(event_id,str) or not re.fullmatch(r'[a-zA-Z0-9_.:-]{1,160}',event_id):
            raise rules.Denied('INVALID_EVENT_ID')
        if kind not in self.handlers:
            raise rules.Denied('UNKNOWN_EVENT_KIND')
        due = timestamp(scheduled_at)
        if not isinstance(parents,(tuple,list)) or len(parents)>8 or any(not isinstance(p,str) for p in parents):
            raise rules.Denied('INVALID_CAUSES')
        if len(set(parents)) != len(parents) or event_id in parents:
            raise rules.Denied('INVALID_CAUSES')
        if payload is None: payload={}
        if not isinstance(payload,dict): raise rules.Denied('INVALID_EVENT_PAYLOAD')
        raw = encode({'schema': SCHEMA, 'event_id': event_id, 'kind': kind,
                      'scheduled_at': due, 'parents': list(parents), 'payload': payload})
        if len(raw.encode('utf-8'))>16384: raise rules.Denied('EVENT_TOO_LARGE')
        digest=hashlib.sha256(raw.encode('utf-8')).hexdigest()
        existing=self.db.execute('SELECT digest FROM causal_schedule WHERE event_id=?',(event_id,)).fetchone()
        if existing:
            if existing['digest'] != digest: raise rules.Denied('EVENT_ID_REUSED')
            return event_id
        # Parents must already be scheduled. This makes the dependency graph
        # append-only and acyclic, even when several effects share a due time.
        for parent in parents:
            r=self.db.execute('SELECT scheduled_at FROM causal_schedule WHERE event_id=?',(parent,)).fetchone()
            if not r or r['scheduled_at']>due: raise rules.Denied('INVALID_CAUSES')
        self.db.execute('INSERT INTO causal_schedule(event_id,kind,scheduled_at,parents,payload,digest) VALUES(?,?,?,?,?,?)',
                        (event_id,kind,due,encode(list(parents)),encode(payload),digest))
        return event_id

    def _schedule_phase(self, phase, parents):
        due=float(self.service.meta('epoch')) + phase * WEATHER_PERIOD
        return self.schedule(f'environment.phase.{phase}', 'WEATHER_CHANGED', due,
                             parents, {'phase': phase})

    def _weather(self, event, now):
        phase=event['payload'].get('phase')
        if type(phase) is not int or phase != int(self.service.meta('phase'))+1:
            raise rules.Denied('WEATHER_SEQUENCE_CONFLICT')
        expected=float(self.service.meta('epoch'))+phase*WEATHER_PERIOD
        if event['scheduled_at'] != expected or event['event_id'] != f'environment.phase.{phase}':
            raise rules.Denied('WEATHER_SOURCE_CONFLICT')
        state=atmosphere(phase*WEATHER_PERIOD)
        self.service._market_tick(event['scheduled_at'])
        self.service.setmeta('phase',phase)
        self.service.blackout.on_weather(event,state['weather'])
        self._schedule_phase(phase+1,(event['event_id'],))
        return {'applied':True, 'phase':phase,'weather':state['weather'],
                'power':state['power'],'elapsed_phases':1}

    def outcome(self, event_id):
        """A stored row is not proof until its receipt is well formed and bound.

        Do not let malformed JSON escape as a generic exception: that would roll
        back the enclosing service transaction, including earlier item expiry.
        A Denied result leaves the dependent event pending behind the existing
        catch-up barrier. The original corrupt bytes are retained for recovery.
        This is structural integrity, not authenticity against database admins.
        """
        with self.service.lock:
            row=self.db.execute("""SELECT event_id,audit_seq,scheduled_at,committed_at,receipt
                FROM causal_outcomes WHERE event_id=?""",(event_id,)).fetchone()
            if row is None:return None
            try:
                receipt=json.loads(row['receipt'])
                if not isinstance(receipt,dict):raise ValueError('Outcome object required')
                if (receipt['schema']!=SCHEMA or receipt['event_id']!=row['event_id']
                    or receipt['ok'] is not True or receipt['status']!='COMMITTED'
                    or not isinstance(receipt['kind'],str) or not receipt['kind']):
                    raise ValueError('Outcome identity/status mismatch')
                for key in ('audit_seq','before_revision','after_revision'):
                    if type(receipt[key]) is not int or receipt[key]<0:
                        raise ValueError('Outcome sequence/revision invalid')
                if receipt['audit_seq']!=row['audit_seq'] or receipt['after_revision']<=receipt['before_revision']:
                    raise ValueError('Outcome sequence/revision mismatch')
                for key in ('scheduled_at','committed_at'):
                    value=receipt[key]
                    if type(value) not in (int,float) or not math.isfinite(value) or value!=row[key]:
                        raise ValueError('Outcome time mismatch')
                if receipt['committed_at']<receipt['scheduled_at']:raise ValueError('Outcome before due time')
                parents=receipt['parent_ids']
                if (not isinstance(parents,list) or len(parents)>8
                    or any(not isinstance(p,str) for p in parents)
                    or len(set(parents))!=len(parents) or event_id in parents):
                    raise ValueError('Outcome causes invalid')
                if not isinstance(receipt['result'],dict) or type(receipt['result'].get('applied')) is not bool:
                    raise ValueError('Outcome effect receipt invalid')
                return receipt
            except (ValueError,KeyError,TypeError,OverflowError,UnicodeError):
                raise rules.Denied('EVENT_OUTCOME_INTEGRITY_FAILED') from None

    def has_due(self, now):
        return bool(self.db.execute("SELECT 1 FROM causal_schedule WHERE status='pending' AND scheduled_at<=? LIMIT 1",(now,)).fetchone())

    def _commit_locked(self, event_id, expected_revision, now):
        old=self.outcome(event_id)
        if old is not None:return old
        row=self.db.execute('SELECT * FROM causal_schedule WHERE event_id=?',(event_id,)).fetchone()
        if not row:raise rules.Denied('UNKNOWN_EVENT')
        if type(expected_revision) is not int or expected_revision!=int(self.service.meta('revision')):
            raise rules.Denied('STALE_WORLD_REVISION')
        if row['scheduled_at']>now:raise rules.Denied('EVENT_NOT_DUE')
        if row['status'] != 'pending':raise rules.Denied('MISSING_EVENT_OUTCOME')
        try:
            parents=json.loads(row['parents']);payload=json.loads(row['payload'])
            raw=encode({'schema':SCHEMA,'event_id':row['event_id'],'kind':row['kind'],
                        'scheduled_at':row['scheduled_at'],'parents':parents,'payload':payload})
            digest=hashlib.sha256(raw.encode('utf-8')).hexdigest()
        except (ValueError,TypeError):
            raise rules.Denied('EVENT_INTEGRITY_FAILED') from None
        if digest != row['digest']:raise rules.Denied('EVENT_INTEGRITY_FAILED')
        if any(self.outcome(p) is None for p in parents):raise rules.Denied('CAUSE_NOT_COMMITTED')
        reducer=self.handlers.get(row['kind'])
        if reducer is None:raise rules.Denied('UNKNOWN_EVENT_KIND')
        event={'event_id':row['event_id'],'kind':row['kind'],'scheduled_at':row['scheduled_at'],
               'parents':parents,'payload':json.loads(row['payload'])}
        # Savepoint contains reducer mutations, child schedules, audit, and receipt.
        # Anything failing after an effect rolls back the entire individual event.
        self.db.execute('SAVEPOINT causal_effect')
        try:
            result=reducer(event,now)
            if not isinstance(result,dict) or type(result.get('applied')) is not bool:
                raise rules.Denied('INVALID_EFFECT_RECEIPT')
            seq=self.service._event(now,row['kind'],None,{
                **result,'causal':{'schema':SCHEMA,'event_id':event_id,'parent_ids':parents,
                                 'scheduled_at':row['scheduled_at'],'input_sha256':row['digest']}})
            receipt={'schema':SCHEMA,'ok':True,'status':'COMMITTED','event_id':event_id,
                     'kind':row['kind'],'parent_ids':parents,'scheduled_at':row['scheduled_at'],
                     'committed_at':now,'audit_seq':seq,'before_revision':expected_revision,
                     'after_revision':int(self.service.meta('revision')),'result':result}
            raw=encode(receipt)
            self.db.execute('INSERT INTO causal_outcomes VALUES(?,?,?,?,?)',(event_id,seq,row['scheduled_at'],now,raw))
            self.db.execute("UPDATE causal_schedule SET status='committed' WHERE event_id=?",(event_id,))
            self.service.perception.observe_event(event,receipt,now)
            self.db.execute('RELEASE causal_effect')
            return receipt
        except BaseException:
            self.db.execute('ROLLBACK TO causal_effect');self.db.execute('RELEASE causal_effect')
            raise

    def commit_transition(self, event_id, expected_revision, now):
        """Internal synchronous entry; registered reducers only, not an HTTP API."""
        now=max(timestamp(now),self.service.now())
        with self.service.tx():
            try:return self._commit_locked(event_id,expected_revision,now)
            except rules.Denied as error:
                return {'ok':False,'code':error.code,'message':error.message,'event_id':event_id}

    def run_due_locked(self, now, budget=MAX_BATCH):
        if type(budget) is not int or not 1<=budget<=MAX_BATCH:raise ValueError('Budget must be 1..256')
        processed=0;blocked=None
        for _ in range(budget):
            row=self.db.execute("SELECT event_id FROM causal_schedule WHERE status='pending' AND scheduled_at<=? ORDER BY scheduled_at,ordinal LIMIT 1",(now,)).fetchone()
            if not row:break
            try:self._commit_locked(row['event_id'],int(self.service.meta('revision')),now)
            except rules.Denied as error:
                blocked={'event_id':row['event_id'],'code':error.code};break
            processed+=1
        return {'processed':processed,'has_due':self.has_due(now),'blocked':blocked,'budget':budget}

    def service_due_events(self, now, budget=MAX_BATCH):
        now=max(timestamp(now),self.service.now())
        with self.service.tx():
            self.service.setmeta('now',now)
            return self.run_due_locked(now,budget)

    def projection(self, now):
        """Public catch-up status; no handler source, scheduled payload or secret RNG."""
        return {'schema':SCHEMA,'catching_up':self.has_due(now),
                'environment_phase':int(self.service.meta('phase'))}

    def atmosphere(self, now):
        elapsed=max(0,now-float(self.service.meta('epoch')))
        result=atmosphere(elapsed)
        phase=int(self.service.meta('phase'))
        committed=atmosphere(phase*WEATHER_PERIOD)
        for key in ('phase','weather','power','rain'):result[key]=committed[key]
        result['next_change_in']=max(0,float(self.service.meta('epoch'))+(phase+1)*WEATHER_PERIOD-now)
        return result
