"""Pure, bounded knowledge projections. These functions never read live game state."""
from __future__ import annotations
import copy
import hashlib
import json
import math

SCHEMA = 'neon-veil/observation/v1'
MEMORY_LIMIT = 64


def encode(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def area(x,y,cell=2):
    return {'x':math.floor(x/cell)*cell+cell/2,
            'y':math.floor(y/cell)*cell+cell/2,'cell':cell}


def derive_belief(observations,now):
    """One subject only. Delivery never refreshes observation time or certainty.

    Copies of the same root count once. A newer observation supersedes, but does
    not erase, an older one. Equal-time contradictions remain unresolved.
    """
    if not math.isfinite(now):raise ValueError('Finite server time required')
    rows=[r for r in observations if r['observed_at']<=r['delivered_at']<=now<r['expires_at']]
    if len({r['subject'] for r in rows})>1:raise ValueError('One subject per belief')
    roots={}
    for r in rows:
        prior=roots.get(r['root_id'])
        if prior is None or (r['uncertainty'],len(r['path']),r['id']) < (prior['uncertainty'],len(prior['path']),prior['id']):
            roots[r['root_id']]=r
    rows=sorted(roots.values(),key=lambda r:(-r['observed_at'],r['id']))[:MEMORY_LIMIT]
    if not rows:
        return {'status':'UNKNOWN','claim':None,'area':None,'uncertainty':None,
                'distinct_origins':0,'evidence_ids':[],'superseded_ids':[],
                'version':hashlib.sha256(b'unknown').hexdigest()}
    newest=rows[0]['observed_at'];current=[r for r in rows if r['observed_at']==newest]
    values={encode({'claim':r['claim'],'area':r['area']}) for r in current}
    chosen=min(current,key=lambda r:(r['uncertainty'],len(r['path']),r['id']))
    conflicted=len(values)>1
    uncertainty=chosen['uncertainty']+(now-newest)*(.35 if chosen['subject'].startswith('actor:') else .01)
    ids=[r['id'] for r in rows]
    return {'status':'CONFLICTED' if conflicted else 'ESTIMATE',
            'subject':chosen['subject'],'claim':None if conflicted else copy.deepcopy(chosen['claim']),
            'area':None if conflicted else copy.deepcopy(chosen['area']),
            'observed_at':newest,'expires_at':min(r['expires_at'] for r in current),
            'uncertainty':round(uncertainty,4),'distinct_origins':len({r['origin_id'] for r in rows}),
            'preferred_id':chosen['id'],
            'evidence_ids':ids,'superseded_ids':[r['id'] for r in rows if r['observed_at']<newest],
            'version':hashlib.sha256(encode(ids).encode()).hexdigest()}


def report_view(row,now):
    """Audience-safe text and provenance, not an authority receipt or live truth."""
    indirect=row['modality'] in ('radio','voice')
    origin=row['origin_name'];speaker=row.get('speaker_name',origin)
    lead=(speaker+' reports' if speaker==origin else speaker+' relays '+origin+"'s report") if indirect else (origin+' observed')
    age=max(0,int(now-row['observed_at']))
    return {'id':row['id'],'root_id':row['root_id'],'origin':origin,
            'source_id':row['origin_id'],'speaker':speaker,'modality':row['modality'],
            'path':list(row['path']),'observed_at':row['observed_at'],
            'delivered_at':row['delivered_at'],'expires_at':row['expires_at'],
            'age_seconds':age,'evidence_event_id':row.get('evidence_event_id'),
            'authority':'HEARSAY' if indirect else 'OBSERVATION',
            'text':f"{lead}: {row['text']} (Observed {age}s ago; not a live guarantee.)"}
