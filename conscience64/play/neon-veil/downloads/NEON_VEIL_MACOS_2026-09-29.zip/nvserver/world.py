"""Seeded open region. Geometry is generated once, persisted, and authoritative.
The plaza spine is preserved; bounded lots vary by seed. Interiors are connected
walkable spaces, not menu teleports. This is a finite region, not an infinite MMO.
"""
import math,random
W,H=96,80
SPAWN=(5.5,8.5)
def make_world(seed=270926):
    r=random.Random(seed);grid=[['.' for _ in range(W)] for _ in range(H)];terrain=[['street' for _ in range(W)] for _ in range(H)]
    for x in range(W):grid[0][x]=grid[H-1][x]='#'
    for y in range(H):grid[y][0]=grid[y][W-1]='#'
    buildings=[];features=[];decor=[]
    def building(id,name,box,door,kind='building'):
        x1,y1,x2,y2=box;dx,dy=door
        for y in range(y1,y2+1):
            for x in range(x1,x2+1):grid[y][x]='#' if x in (x1,x2) or y in (y1,y2) else '.';terrain[y][x]='interior'
        grid[dy][dx]='.'
        b={'id':id,'name':name,'x1':x1,'y1':y1,'x2':x2,'y2':y2,'door_x':dx+.5,'door_y':dy+.5};buildings.append(b)
        # A service/landmark is near its doorway inside the room, not behind a wall.
        sx=dx+(.5 if x1<dx<x2 else (1.5 if dx==x1 else -.5));sy=dy+(.5 if y1<dy<y2 else (1.5 if dy==y1 else -.5))
        features.append({'id':id,'kind':kind,'name':name,'x':sx,'y':sy,'building':id})
        decor.extend([{'id':id+'-lamp','kind':'lamp','x':dx+.5,'y':dy+.5,'size':.8}, {'id':id+'-bench','kind':'bench','x':x1+1.5,'y':y2-.5,'size':.5}])
    # Preserve spawn, safe zone and mission fixtures. Streets are never quest-gated.
    building('lantern-goods','Lantern Exchange',(2,1,10,5),(6,5),'shop')
    building('noodle-house','Rainmarket Kitchen',(2,14,9,20),(6,14),'shop')
    building('archive','Public Archive',(15,2,21,6),(18,6),'landmark')
    building('forge','Hexworks Workshop',(16,14,20,19),(18,14),'shop')
    building('observatory','Signal Observatory',(23,2,29,8),(25,8),'landmark')
    building('pump-house','Old Pump House',(25,16,28,20),(27,16),'landmark')
    features.extend([
      {'id':'moth','kind':'contact','name':'Moth · optional contracts','x':7.5,'y':8.5},
      {'id':'shelter','kind':'shelter','name':'Lantern shelter','x':3.5,'y':9.5},
      {'id':'relay','kind':'terminal','name':'Rain relay','x':24.5,'y':12.5},
      {'id':'grid-terminal','kind':'terminal','name':'Civic grid console','x':8.5,'y':7.5},
      {'id':'hazard','kind':'hazard','name':'Ruptured power conduit','x':22.5,'y':18.5}])
    regions=[{'id':'rainmarket','name':'Rainmarket','x1':1,'y1':1,'x2':32,'y2':26,'terrain':'street'},
             {'id':'greenway','name':'Greenway Commons','x1':32,'y1':1,'x2':64,'y2':40,'terrain':'garden'},
             {'id':'ash-district','name':'Ashworks','x1':64,'y1':1,'x2':95,'y2':40,'terrain':'industrial'},
             {'id':'tidal-reach','name':'Tidal Reach','x1':1,'y1':26,'x2':32,'y2':79,'terrain':'marsh'},
             {'id':'stonefold','name':'Stonefold Ruins','x1':32,'y1':40,'x2':64,'y2':79,'terrain':'stone'},
             {'id':'veil-gardens','name':'Veil Gardens','x1':64,'y1':40,'x2':95,'y2':79,'terrain':'garden'}]
    for reg in regions:
        for y in range(reg['y1'],reg['y2']):
            for x in range(reg['x1'],reg['x2']):
                if terrain[y][x]!='interior':terrain[y][x]=reg['terrain']
    # Lot grid leaves four-tile streets. Bounded generation, stable source seed.
    for i,(x,y) in enumerate([(35,5),(49,20),(67,6),(81,22),(5,32),(18,51),(35,44),(49,64),(68,44),(81,64),(6,68),(65,65)]):
        bw,bh=r.randint(5,8),r.randint(5,8);door=(x+r.randint(1,bw-1),y+bh)
        building('site-'+str(i),['Glass conservatory','Restoration depot','Tide records','Quiet workshop','Weather station','Memorial hall'][i%6],(x,y,x+bw,y+bh),door,'landmark')
    for i,(x,y,name) in enumerate([(38,14,'Greenway spring'),(70,18,'Ashworks overpass'),(14,40,'Tidal lookout'),(42,57,'Stonefold circle'),(73,58,'Veil orchard')]):
        features.append({'id':'landmark-'+str(i),'kind':'landmark','name':name,'x':x+.5,'y':y+.5})
    # Sparse ornamental props never change collision: paths remain readable.
    for i in range(110):
        x=r.randrange(2,W-2)+.5;y=r.randrange(2,H-2)+.5
        if terrain[int(y)][int(x)]=='interior' or grid[int(y)][int(x)]=='#':continue
        kind='tree' if terrain[int(y)][int(x)] in ('garden','marsh') else ('lamp' if i%3 else 'crate')
        decor.append({'id':'prop-'+str(i),'kind':kind,'x':x,'y':y,'size':.7+r.random()*.6})
    return {'id':'rainmarket','name':'Meridian Open Reach','generation':'0.30','seed':seed,'width':W,'height':H,'grid':[''.join(row) for row in grid],'terrain':['|'.join(row) for row in terrain],'features':features,'buildings':buildings,'regions':regions,'decorations':decor[:180],
      'safe_zone':{'x1':1,'y1':1,'x2':12,'y2':21},
      'npcs':[{'id':'warden-1','kind':'wraith','name':'Relay sentinel','x':20.5,'y':10.5,'hp':16,'max_hp':16,'role':'hold','attack_at':0},
              {'id':'warden-2','kind':'skitter','name':'Relay scout','x':26.5,'y':13.5,'hp':12,'max_hp':12,'role':'flank','attack_at':0},
              {'id':'custodian','kind':'brute','name':'The Custodian','x':29.5,'y':18.5,'hp':120,'max_hp':120,'role':'boss','attack_at':0}]}
def in_town(x,y):return 1<=x<12 and 1<=y<21
def passable(world,x,y,radius=.18):
    w=world['width'];h=world['height']
    for a,b in [(x-radius,y-radius),(x+radius,y-radius),(x-radius,y+radius),(x+radius,y+radius)]:
        if not (0<=a<w and 0<=b<h) or world['grid'][int(b)][int(a)]=='#':return False
    return True
def line_of_sight(world,x,y,tx,ty):
    d=math.hypot(tx-x,ty-y);steps=max(1,math.ceil(d*6))
    return all(passable(world,x+(tx-x)*i/steps,y+(ty-y)*i/steps,.02) for i in range(1,steps))
def atmosphere(elapsed):
    index=max(0,int(elapsed//90));mode=('rain','rain','storm','mist')[index%4]
    return {'phase':index,'weather':mode,'rain':{'rain':.62,'storm':1,'mist':.13}[mode], 'power':not(index%8 in(2,3)), 'erosion':min(1,elapsed/864000), 'world_hour':int(elapsed/60)%24,'next_change_in':90-elapsed%90}
