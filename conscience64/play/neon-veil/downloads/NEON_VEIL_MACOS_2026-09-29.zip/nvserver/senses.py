"""Server-owned observation archive and perception-limited delivery channels.

No public event injection. Calls that write join the caller's authoritative
transaction. Archived facts are immutable; active views are capped and expire.
"""
from __future__ import annotations
import copy
from collections import OrderedDict
import hashlib
import json
import math
from . import rules
from .observation_archive import ObservationArchive
from .perception import SCHEMA, MEMORY_LIMIT, encode, area, derive_belief, report_view
from .world import line_of_sight, in_town

RADIO_RANGE=18.
RADIO_DELAY=2.
MAX_HOPS=2
MAX_OBSERVERS=12
VOICE_RANGE=2.3
SIGHT_TTL=12.
EVENT_TTL=600.


class PerceptionSystem:
    HOT_CACHE_LIMIT=64
    RAY_CACHE_LIMIT=256
    def __init__(self,service):
        self.owner=service;self.db=service.db
        self._world_source=None;self._world_value=None
        self._profiles_key=None;self._profiles_value=None
        self._power_source=None;self._power_phase=None
        self._sight_cache=OrderedDict()
        self._geometry_key=None;self._ray_cache=OrderedDict()
        self.archive=ObservationArchive(self)
        service.causal.register('REPORT_DELIVERED',self._deliver)

    def install(self,now):
        self.db.execute('''CREATE TABLE IF NOT EXISTS perception_observations(
          ordinal INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,
          observer TEXT NOT NULL,root_id TEXT NOT NULL,subject TEXT NOT NULL,
          observed_at REAL NOT NULL,delivered_at REAL NOT NULL,expires_at REAL NOT NULL,
          body TEXT NOT NULL,digest TEXT NOT NULL,UNIQUE(observer,root_id))''')
        self.db.execute('CREATE INDEX IF NOT EXISTS perception_memory ON perception_observations(observer,expires_at,observed_at)')
        # Root samples are the only rows queried by this access path. Include the
        # original ordinal tie-break so SQLite need not sort relayed observations.
        self.db.execute('CREATE INDEX IF NOT EXISTS perception_direct_latest ON perception_observations(observer,subject,observed_at DESC,ordinal DESC) WHERE root_id=id')
        self.db.execute('DROP INDEX IF EXISTS perception_subject')
        self.db.execute('''CREATE TABLE IF NOT EXISTS perception_routes(
          root_id TEXT NOT NULL,recipient TEXT NOT NULL,event_id TEXT UNIQUE NOT NULL,
          PRIMARY KEY(root_id,recipient))''')
        for verb in ('UPDATE','DELETE'):
            self.db.execute(f'''CREATE TRIGGER IF NOT EXISTS perception_no_{verb.lower()}
              BEFORE {verb} ON perception_observations
              BEGIN SELECT RAISE(ABORT,'Observation archive is immutable'); END''')
        if self.owner.meta('perception_schema') is None:
            self.owner.setmeta('perception_schema',SCHEMA)
            self.owner.setmeta('perception_attached_at',now)
        elif self.owner.meta('perception_schema')!=SCHEMA:
            raise rules.Denied('PERCEPTION_SCHEMA_CONFLICT')
        self.archive.install(now)

    def _read_world(self):
        """Private read-only borrow keyed by exact database source, never by time.

        No public projection or mutating caller receives this cached object.
        Comparing the stored bytes catches direct SQL writes and transaction rollback.
        """
        raw=self.owner.meta('world')
        if raw!=self._world_source:
            value=json.loads(raw)
            self._world_value=value;self._world_source=raw
        return self._world_value

    def tactical_world(self):
        """Private frame: static geometry borrowed read-only, NPCs copied for mutation.

        Never return this borrow from snapshot(). Only NPC dictionaries are mutable
        in the existing tactical reducer. Exact raw-source keys survive rollback.
        """
        source=self._read_world()
        npcs=source['npcs']
        # JSON-sourced primitive fields are immutable. Future nested state keeps
        # the original recursive-copy path, not a shallow alias into authority.
        primitive=(str,int,float,bool,type(None))
        if all(type(v) in primitive for n in npcs for v in n.values()):
            detached=[dict(n) for n in npcs]
        else:detached=copy.deepcopy(npcs)
        return {**source,'npcs':detached}

    def _visible(self,world,x,y,tx,ty):
        """Exact geometry-question cache; never caches belief, range or time.

        Re-read width, height, every immutable grid row and both endpoints on
        each call. Changed cells, rollback or a moved target invalidate reuse.
        One geometry and 256 bounded rays are retained. Nonstandard mutable row
        carriers use the original function without caching.
        """
        rows=world['grid']
        if any(type(row) is not str for row in rows):
            return line_of_sight(world,x,y,tx,ty)
        geometry=(world['width'],world['height'],tuple(rows),line_of_sight)
        if geometry!=self._geometry_key:
            self._ray_cache.clear();self._geometry_key=geometry
        key=(x,y,tx,ty)
        if key in self._ray_cache:
            self._ray_cache.move_to_end(key)
            return self._ray_cache[key]
        result=line_of_sight(world,x,y,tx,ty)
        self._ray_cache[key]=result
        while len(self._ray_cache)>self.RAY_CACHE_LIMIT:
            self._ray_cache.popitem(last=False)
        return result

    def _transaction(self):
        if not self.db.in_transaction:raise RuntimeError('Authoritative transaction required')

    def observers(self,world):
        """Declared sensor profiles, reused only for exactly equal inputs.

        Read current power source and sensor fields even on a hit. This catches
        direct SQL writes, transaction rollback and in-frame position mutations.
        Returned flat dictionaries are detached; the cache is not caller-owned.
        """
        raw=self.owner.meta('rainmarket_power')
        if raw!=self._power_source:
            phase=self.owner.blackout.state()['phase']  # validate before caching
            self._power_source=raw;self._power_phase=phase
        features=tuple((f['id'],f['name'],f['x'],f['y']) for f in world['features']
                       if f['id']=='moth' or f['kind']=='shop')
        npcs=tuple((n['id'],n['name'],n['x'],n['y']) for n in world['npcs'] if n['hp']>0)
        key=(raw,features,npcs,MAX_OBSERVERS)
        if key!=self._profiles_key:
            out=[{'id':id,'name':name.split(' · ')[0],'x':x,'y':y,
                  'group':'civic','sight':9.,'stationary':True}
                 for id,name,x,y in features]
            outage=self._power_phase=='OUTAGE'
            for id,name,x,y in npcs:
                failed=id=='warden-1' and outage and 1<=x<32 and 1<=y<26
                out.append({'id':id,'name':name,'x':x,'y':y,
                            'group':'security','sight':4. if failed else 7.,'stationary':False})
            self._profiles_value=out[:MAX_OBSERVERS];self._profiles_key=key
        return [dict(o) for o in self._profiles_value]

    def _observer(self,observer_id,world,now):
        row=next((o for o in self.observers(world) if o['id']==observer_id),None)
        if row:return row
        c=self.db.execute('''SELECT c.id,c.name,c.x,c.y FROM characters c JOIN accounts a
          ON a.active_character=c.id WHERE c.id=? AND c.alive=1 AND a.last_seen>=?''',(observer_id,now-30)).fetchone()
        return {**dict(c),'group':'player','sight':9.,'stationary':False} if c else None

    def _decode(self,row):
        if row is None:return None
        try:
            body=self.archive.body_text(row)
            if hashlib.sha256(body.encode()).hexdigest()!=row['digest']:
                raise rules.Denied('OBSERVATION_INTEGRITY_FAILED')
            result=json.loads(body)
            if result['schema']!=SCHEMA or any(result[key]!=row[key] for key in ('id','observer','root_id','subject','observed_at','delivered_at','expires_at')):
                raise rules.Denied('OBSERVATION_INTEGRITY_FAILED')
            return result
        except (ValueError,KeyError,TypeError,AttributeError,UnicodeError):
            raise rules.Denied('OBSERVATION_INTEGRITY_FAILED') from None

    def get(self,observation_id):
        return self._decode(self.db.execute('SELECT * FROM perception_observations WHERE id=?',(observation_id,)).fetchone())

    def archive_count(self,observer_id):
        return self.db.execute('SELECT count(*) FROM perception_observations WHERE observer=?',(observer_id,)).fetchone()[0]

    def memory(self,observer_id,now):
        rows=self.db.execute('''SELECT * FROM perception_observations
          WHERE observer=? AND delivered_at<=? AND expires_at>?
          ORDER BY observed_at DESC,ordinal DESC LIMIT ?''',(observer_id,now,now,MEMORY_LIMIT)).fetchall()
        return [self._decode(r) for r in rows]

    def beliefs(self,observer_id,now):
        groups={}
        for r in self.memory(observer_id,now):groups.setdefault(r['subject'],[]).append(r)
        return {k:derive_belief(v,now) for k,v in sorted(groups.items())}

    def _store(self,row):
        self._transaction()
        # A root keeps its original identity; another route cannot refresh it.
        old=self.db.execute('SELECT * FROM perception_observations WHERE observer=? AND root_id=?',
                            (row['observer'],row['root_id'])).fetchone()
        if old:return self._decode(old)
        raw=encode(row)
        self.db.execute('''INSERT INTO perception_observations
          (id,observer,root_id,subject,observed_at,delivered_at,expires_at,body,digest)
          VALUES(?,?,?,?,?,?,?,?,?)''',(row['id'],row['observer'],row['root_id'],row['subject'],
          row['observed_at'],row['delivered_at'],row['expires_at'],raw,hashlib.sha256(raw.encode()).hexdigest()))
        return row

    def _observe(self,observer,subject,claim,location,modality,observed_at,delivered_at,
                 ttl,uncertainty,seq,event_id,text,geometry):
        self._transaction()
        if not self.db.execute('SELECT 1 FROM events WHERE seq=?',(seq,)).fetchone():
            raise rules.Denied('UNCOMMITTED_EVIDENCE')
        row={'schema':SCHEMA,'observer':observer['id'],'origin_id':observer['id'],
             'origin_name':observer['name'],'speaker_name':observer['name'],
             'subject':subject,'claim':claim,'area':location,'modality':modality,
             'observed_at':float(observed_at),'delivered_at':float(delivered_at),
             'expires_at':float(observed_at+ttl),'uncertainty':float(uncertainty),
             'evidence_seq':seq,'evidence_event_id':event_id,'path':[observer['id']],
             'parent_id':None,'text':text,
             'basis':{'sensor_position':{'x':observer['x'],'y':observer['y']},
                      'sensor_range':observer['sight'] if modality=='sight' else observer.get('heard_range',10.),
                      'policy':SCHEMA,'geometry_sha256':hashlib.sha256('\n'.join(geometry['grid']).encode()).hexdigest(),
                      'source_revision':int(self.owner.meta('revision'))}}
        ident='obs.'+hashlib.sha256(encode(row).encode()).hexdigest()[:40]
        row.update(id=ident,root_id=ident)
        return self._store(row)

    def _latest_sight(self,observer,subject):
        """A 64-entry private decode cache, never an authority or a memory cap.

        Always query the current indexed row and compare every stored field.
        Cold bodies bypass this cache so segment bytes are reverified. The result
        is used only internally; public get()/memory() still return new objects.
        """
        row=self.db.execute('''SELECT * FROM perception_observations
          WHERE observer=? AND subject=? AND root_id=id
          ORDER BY observed_at DESC,ordinal DESC LIMIT 1''',(observer,subject)).fetchone()
        key=(observer,subject)
        if row is None:
            self._sight_cache.pop(key,None)
            return None
        exact=tuple(row)
        old=self._sight_cache.get(key)
        if row['body']!='' and old is not None and old[0]==exact:
            self._sight_cache.move_to_end(key)
            return old[1]
        decoded=self._decode(row)
        if row['body']!='':
            self._sight_cache[key]=(exact,decoded)
            self._sight_cache.move_to_end(key)
            while len(self._sight_cache)>self.HOT_CACHE_LIMIT:
                self._sight_cache.popitem(last=False)
        else:self._sight_cache.pop(key,None)
        return decoded

    def sight_targets(self,npc,targets,world,now):
        self._transaction()
        if not targets:return []
        observer=next((o for o in self.observers(world) if o['id']==npc['id']),None)
        if not observer:return []
        seen=[c for c in targets if not in_town(c['x'],c['y'])
          and math.hypot(c['x']-observer['x'],c['y']-observer['y'])<observer['sight']
          and self._visible(world,observer['x'],observer['y'],c['x'],c['y'])]
        if not seen:return []
        target=min(seen,key=lambda c:(math.hypot(c['x']-observer['x'],c['y']-observer['y']),c['id']))
        subject='actor:'+target['id'];location=area(target['x'],target['y'])
        old=self._latest_sight(observer['id'],subject)
        # A live sight check is performed each tactical tick; only archive samples
        # at a bounded cadence. Relays never receive this transient exact position.
        if old is None or (now-old['observed_at']>=2 and (old['area']!=location or now-old['observed_at']>=4)):
            seq=self.owner._event(now,'NPC_SIGHT_SAMPLE',None,{'observer':observer['id'],
              'subject':subject,'area':location,'modality':'sight'})
            old=self._observe(observer,subject,{'value':'present'},location,'sight',now,now,
                SIGHT_TTL,math.sqrt(2),seq,None,'A moving figure was last seen in this area.',world)
            self._broadcast(old,world,now)
        return [{'id':target['id'],'x':target['x'],'y':target['y'],
                 'observed_now':now,'observation_id':old['id']}]

    def hear(self,observer_id,signal,world,now):
        self._transaction();o=self._observer(observer_id,world,now)
        if o is None:return None
        x,y=signal['x'],signal['y'];d=math.hypot(o['x']-x,o['y']-y)
        limit=10. if self._visible(world,o['x'],o['y'],x,y) else 3.
        if d>limit:return None
        kind=signal.get('kind','impact')
        if kind not in ('impact','electrical_trip','transformer_hum'):raise rules.Denied('UNKNOWN_SOUND')
        return self._observe({**o,'heard_range':limit},'sound:'+kind,{'value':kind},area(x,y,4),'sound',now,now,
          60.,3.,signal['audit_seq'],signal.get('event_id'),
          {'impact':'An impact was heard nearby.','electrical_trip':'An electrical crack was heard near the market.',
           'transformer_hum':'An unusually loud transformer hum was heard.'}[kind],world)

    def _queue_known(self,row,sender,receiver,now):
        """Reuse the caller's one authoritative sensor snapshot per broadcast."""
        recipient=receiver['id']
        old=self.db.execute('SELECT event_id FROM perception_routes WHERE root_id=? AND recipient=?',
                            (row['root_id'],recipient)).fetchone()
        if old:return old[0]
        if recipient in row['path'] or len(row['path'])>MAX_HOPS or row['modality']=='voice':return None
        if now+RADIO_DELAY>=row['expires_at']:return None
        if sender['group'] not in ('civic','security') or sender['group']!=receiver['group']:return None
        if math.hypot(sender['x']-receiver['x'],sender['y']-receiver['y'])>RADIO_RANGE:return None
        key='perception.report.'+hashlib.sha256((row['root_id']+'|'+recipient).encode()).hexdigest()[:40]
        cause=row.get('delivery_event_id') or row.get('evidence_event_id')
        parents=(cause,) if cause and self.db.execute('SELECT 1 FROM causal_schedule WHERE event_id=?',(cause,)).fetchone() else ()
        self.owner.causal.schedule(key,'REPORT_DELIVERED',now+RADIO_DELAY,parents,
            {'observation_id':row['id'],'sender':sender['id'],'recipient':recipient})
        self.db.execute('INSERT INTO perception_routes VALUES(?,?,?)',(row['root_id'],recipient,key))
        return key

    def queue_report(self,row,recipient,now):
        self._transaction()
        # Ignore caller-provided claim changes; only archived facts may travel.
        row=self.get(row['id'])
        if not row:return None
        w=self._read_world()
        profiles={o['id']:o for o in self.observers(w)}
        sender=profiles.get(row['observer']);receiver=profiles.get(recipient)
        if not sender or not receiver:return None
        return self._queue_known(row,sender,receiver,now)

    def _broadcast(self,row,world,now):
        if row['modality']=='voice' or len(row['path'])>MAX_HOPS or now+RADIO_DELAY>=row['expires_at']:return
        profiles=self.observers(world)
        sender=next((o for o in profiles if o['id']==row['observer']),None)
        if not sender:return
        for receiver in profiles:
            if receiver['id'] not in row['path'] and receiver['group']==sender['group']:
                self._queue_known(row,sender,receiver,now)

    def _relay(self,row,receiver,sender,when,modality,event_id=None):
        copy={**row,'observer':receiver['id'],'parent_id':row['id'],
              'path':row['path']+[receiver['id']],'modality':modality,
              'delivered_at':float(when),'uncertainty':row['uncertainty']+(2. if modality=='radio' else .5),
              'speaker_name':sender['name'],'delivery_event_id':event_id,
              'delivery_basis':{'channel':modality,'checked_at':when,
                 'range_limit':RADIO_RANGE if modality=='radio' else VOICE_RANGE,
                 'line_of_sight_required':modality=='voice',
                 'from':{'x':sender['x'],'y':sender['y']},
                 'to':{'x':receiver['x'],'y':receiver['y']},
                 'state_revision':int(self.owner.meta('revision'))}}
        copy['id']='obs.'+hashlib.sha256(encode({k:v for k,v in copy.items() if k!='id'}).encode()).hexdigest()[:40]
        return self._store(copy)

    def _deliver(self,event,now):
        data=event['payload'];row=self.get(data['observation_id'])
        if row is None:raise rules.Denied('MISSING_SOURCE_OBSERVATION')
        if row['expires_at']<=now:return {'applied':False,'reason':'expired'}
        if data['sender']!=row['observer'] or data['recipient'] in row['path'] or len(row['path'])>MAX_HOPS:
            raise rules.Denied('REPORT_PATH_CONFLICT')
        world=self._read_world()
        profiles={o['id']:o for o in self.observers(world)}
        sender=profiles.get(data['sender']);receiver=profiles.get(data['recipient'])
        if not sender or not receiver:return {'applied':False,'reason':'observer_unavailable'}
        if sender['group']!=receiver['group']:return {'applied':False,'reason':'channel_denied'}
        if math.hypot(sender['x']-receiver['x'],sender['y']-receiver['y'])>RADIO_RANGE:
            return {'applied':False,'reason':'out_of_range'}
        delivered=self._relay(row,receiver,sender,now,'radio',event['event_id'])
        self._broadcast(delivered,world,now)
        return {'applied':True,'observation_id':delivered['id'],'recipient':receiver['id'],
                'origin_id':row['origin_id'],'source_observed_at':row['observed_at']}

    def observe_event(self,event,receipt,now):
        """Called after receipt insertion, before enclosing transaction commits."""
        if event['kind'] not in ('GRID_WARNING','GRID_OVERLOADED','GRID_BACKUP_CONNECTED','REFRIGERATION_EXPOSURE'):return
        due=event['scheduled_at']
        if due<float(self.owner.meta('perception_attached_at')):return
        world=self._read_world();signals=[];kind=event['kind']
        if kind=='REFRIGERATION_EXPOSURE':
            if receipt['result'].get('removed',0)==0:return
            signals=[('noodle-house','kitchen:stock','discarded','The kitchen discarded food from its unpowered cold store.')]
        else:
            phase={'GRID_WARNING':'WARNING','GRID_OVERLOADED':'OUTAGE','GRID_BACKUP_CONNECTED':'BACKUP'}[kind]
            text={'WARNING':'The civic feeder is straining.',
                  'OUTAGE':'The civic feeder has tripped; emergency town services remain available.',
                  'BACKUP':'An alternate feeder is connected, but the damaged transformer still needs maintenance.'}[phase]
            signals=[('grid-terminal','grid:rainmarket',phase,text)]
            if kind!='GRID_WARNING':
                signals += [('forge','service:forge',phase,'Hexworks '+('closed its powered counter.' if phase=='OUTAGE' else 'reopened on the alternate feeder.')),
                            ('noodle-house','service:kitchen',phase,'The kitchen '+('lost refrigeration but kept its counter open.' if phase=='OUTAGE' else 'reconnected its refrigeration.'))]
        observers=self.observers(world)
        # A current moving position is not proof of presence at a past event.
        if abs(now-due)<=2:
            for c in self.db.execute('''SELECT c.id,c.name,c.x,c.y FROM characters c JOIN accounts a ON a.active_character=c.id
              WHERE c.alive=1 AND a.last_seen>=? LIMIT 32''',(now-30,)):
                observers.append({**dict(c),'group':'player','sight':9.,'stationary':False})
        for source,subject,value,text in signals:
            f=next((f for f in world['features'] if f['id']==source),None)
            if not f:continue
            for o in observers:
                if not o['stationary'] and abs(now-due)>2:continue
                d=math.hypot(o['x']-f['x'],o['y']-f['y'])
                if d<=o['sight'] and self._visible(world,o['x'],o['y'],f['x'],f['y']):
                    row=self._observe(o,subject,{'value':value},area(f['x'],f['y']),'sight',due,due,
                          EVENT_TTL,math.sqrt(2),receipt['audit_seq'],event['event_id'],text,world)
                elif source=='grid-terminal' and kind in ('GRID_WARNING','GRID_OVERLOADED'):
                    row=self.hear(o['id'],{'x':f['x'],'y':f['y'],'audit_seq':receipt['audit_seq'],
                      'event_id':event['event_id'],'kind':'electrical_trip' if kind=='GRID_OVERLOADED' else 'transformer_hum'},world,due)
                else:row=None
                if row and o['group']!='player':self._broadcast(row,world,due)

    def tell(self,speaker_id,character,world,now):
        """Nearby voluntary conversation. Nothing gets turned into an accepted goal."""
        self._transaction();speaker=self._observer(speaker_id,world,now)
        receiver=self._observer(character['id'],world,now)
        if not speaker or not receiver or speaker['group']!='civic':return []
        if math.hypot(receiver['x']-speaker['x'],receiver['y']-speaker['y'])>VOICE_RANGE or not self._visible(world,speaker['x'],speaker['y'],receiver['x'],receiver['y']):return []
        beliefs=self.beliefs(speaker_id,now);delivered=[]
        for subject,belief in sorted(beliefs.items()):
            if subject.startswith('actor:') or belief['status']!='ESTIMATE':continue
            row=self.get(belief['preferred_id'])
            if receiver['id'] in row['path']:continue
            delivered.append(self._relay(row,receiver,speaker,now,'voice'))
            if len(delivered)>=3:break
        return [report_view(r,now) for r in delivered]

    def public_reports(self,character_id,now):
        if not character_id:return []
        beliefs=self.beliefs(character_id,now);reports=[]
        for subject,b in beliefs.items():
            if subject.startswith('actor:') or b['status']!='ESTIMATE':continue
            reports.append(report_view(self.get(b['preferred_id']),now))
        return sorted(reports,key=lambda r:(-r['observed_at'],r['id']))[:8]
