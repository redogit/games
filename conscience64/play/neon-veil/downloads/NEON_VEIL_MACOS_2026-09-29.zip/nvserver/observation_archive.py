"""Lossless, bounded cold storage for expired perception payloads.

The immutable ID/time/digest catalog remains in perception_observations. Only the
storage representation of a body changes: from exact UTF-8 to a checked compressed
segment in the SAME database transaction. No source, chain or expired fact is deleted.
This is compression, not constant-space historical retention or authenticity.
"""
from __future__ import annotations
import hashlib,json,math,sqlite3,zlib
from . import rules

CODEC='neon-veil/observation-segment/zlib-json-v1'
MAX_BATCH=256
MAX_RAW_BYTES=2*1024*1024
HOT_RETENTION=300.0
CHECK_INTERVAL=30.0
IDENTITY=('ordinal','id','observer','root_id','subject','observed_at','delivered_at','expires_at','digest')


def _bad():
    raise rules.Denied('OBSERVATION_ARCHIVE_INTEGRITY_FAILED')


def unpack_segment(segment):
    """Bounded decompression and full segment identity verification, every read."""
    if segment is None:_bad()
    packed=segment['packed']
    if (segment['codec']!=CODEC or type(packed) is not bytes
        or not 0<len(packed)<=MAX_RAW_BYTES*2
        or not 0<segment['raw_bytes']<=MAX_RAW_BYTES
        or not 1<=segment['members']<=MAX_BATCH
        or hashlib.sha256(packed).hexdigest()!=segment['packed_sha256']):_bad()
    try:
        inflater=zlib.decompressobj()
        raw=inflater.decompress(packed,MAX_RAW_BYTES+1)
        if (len(raw)!=segment['raw_bytes'] or not inflater.eof
            or inflater.unused_data or inflater.unconsumed_tail
            or hashlib.sha256(raw).hexdigest()!=segment['id']):_bad()
        items=json.loads(raw)
        if not isinstance(items,list) or len(items)!=segment['members']:_bad()
        found={}
        for pair in items:
            if (not isinstance(pair,list) or len(pair)!=2 or not all(isinstance(v,str) for v in pair)
                or pair[0] in found):_bad()
            found[pair[0]]=pair[1]
        return found
    except (ValueError,TypeError,zlib.error,UnicodeError):_bad()


def archived_body(db,observation_id):
    row=db.execute('''SELECT s.* FROM perception_segments s
        JOIN perception_segment_members m ON m.segment_id=s.id
        WHERE m.observation_id=?''',(observation_id,)).fetchone()
    bodies=unpack_segment(row)
    if observation_id not in bodies:_bad()
    return bodies[observation_id]


class ObservationArchive:
    def __init__(self,perception):
        self.perception=perception;self.owner=perception.owner;self.db=perception.db
        self._packing=False
        # A connection-local guard is never exposed to game requests.
        self.db.create_function('nv_perception_compacting',0,lambda:int(self._packing))

    def install(self,now):
        self.db.execute('''CREATE TABLE IF NOT EXISTS perception_segments(
            id TEXT PRIMARY KEY,codec TEXT NOT NULL,raw_bytes INTEGER NOT NULL,
            members INTEGER NOT NULL,packed BLOB NOT NULL,packed_sha256 TEXT NOT NULL)''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS perception_segment_members(
            observation_id TEXT PRIMARY KEY REFERENCES perception_observations(id),
            segment_id TEXT NOT NULL REFERENCES perception_segments(id))''')
        self.db.execute('CREATE INDEX IF NOT EXISTS perception_segment_lookup ON perception_segment_members(segment_id)')
        self.db.execute("CREATE INDEX IF NOT EXISTS perception_hot_expiry ON perception_observations(expires_at,ordinal) WHERE body<>''")
        for table in ('perception_segments','perception_segment_members'):
            short='perception_segments' if table=='perception_segments' else 'perception_members'
            for verb in ('UPDATE','DELETE'):
                self.db.execute(f'''CREATE TRIGGER IF NOT EXISTS {short}_no_{verb.lower()}
                    BEFORE {verb} ON {table} BEGIN SELECT RAISE(ABORT,'Cold evidence is immutable'); END''')
        # Upgrade the storage-only guard inside startup's writer transaction. Every
        # identity column is pinned; no delete and no arbitrary hot-body overwrite.
        self.db.execute('DROP TRIGGER IF EXISTS perception_no_update')
        equal=' AND '.join(f'NEW.{k} IS OLD.{k}' for k in IDENTITY)
        self.db.execute(f'''CREATE TRIGGER perception_no_update BEFORE UPDATE ON perception_observations
            WHEN coalesce(nv_perception_compacting()=1 AND OLD.body<>'' AND NEW.body=''
                AND {equal} AND EXISTS(SELECT 1 FROM perception_segment_members
                   WHERE observation_id=OLD.id),0)=0
            BEGIN SELECT RAISE(ABORT,'Observation archive is immutable'); END''')
        self.db.execute('DROP TRIGGER IF EXISTS perception_no_delete')
        self.db.execute("""CREATE TRIGGER perception_no_delete BEFORE DELETE ON perception_observations
            WHEN coalesce(nv_perception_compacting()=1 AND OLD.body<>''
                AND EXISTS(SELECT 1 FROM perception_segment_members WHERE observation_id=OLD.id),0)=0
            BEGIN SELECT RAISE(ABORT,'Observation archive is immutable'); END""")
        if self.owner.meta('perception_archive_schema') is None:
            self.owner.setmeta('perception_archive_schema',CODEC)
            self.owner.setmeta('perception_archive_due',now+CHECK_INTERVAL)
        elif self.owner.meta('perception_archive_schema')!=CODEC:
            raise rules.Denied('OBSERVATION_ARCHIVE_SCHEMA_CONFLICT')

    def body_text(self,row):
        return archived_body(self.db,row['id']) if row['body']=='' else row['body']

    def _retire_hot(self,ids):
        # Shrinking a large SQLite cell in place leaves unusable internal holes.
        # Repack these catalog rows atomically with EXACT original ordinal/ID/time/
        # digest metadata. The cold payload already exists and was verified.
        placeholders=','.join('?' for _ in ids)
        records=[dict(r) for r in self.db.execute(
            'SELECT * FROM perception_observations WHERE id IN ('+placeholders+')',ids)]
        if len(records)!=len(ids):_bad()
        for row in records:row['body']=''
        columns=list(records[0]);insert=','.join(columns);values=','.join('?' for _ in columns)
        self.db.execute('PRAGMA defer_foreign_keys=ON')
        self._packing=True
        try:
            self.db.executemany('DELETE FROM perception_observations WHERE id=?',((i,) for i in ids))
            self.db.executemany('INSERT INTO perception_observations ('+insert+') VALUES('+values+')',
                                ([r[k] for k in columns] for r in records))
            # Prove replacement before releasing the savepoint. Parent/member FKs
            # are also checked when the outer authoritative transaction commits.
            after={r['id']:dict(r) for r in self.db.execute(
                'SELECT * FROM perception_observations WHERE id IN ('+placeholders+')',ids)}
            if after!={r['id']:r for r in records}:_bad()
        finally:self._packing=False

    def compact(self,now,limit=MAX_BATCH):
        self.perception._transaction()
        if type(limit) is not int or not 1<=limit<=MAX_BATCH:raise ValueError('Archive batch must be1..256')
        if isinstance(now,bool) or not isinstance(now,(int,float)) or not math.isfinite(now):raise ValueError('Finite time required')
        cutoff=now-HOT_RETENTION
        self.db.execute('SAVEPOINT observation_compaction')
        try:
            candidates=self.db.execute('''SELECT * FROM perception_observations
                WHERE body<>'' AND expires_at<=? ORDER BY expires_at,ordinal LIMIT ?''',(cutoff,limit)).fetchall()
            pairs=[];source=[];size=2
            for row in candidates:
                self.perception._decode(row)  # Verify body AND immutable indexed identity first.
                pair=[row['id'],row['body']]
                extra=len(json.dumps(pair,ensure_ascii=False,separators=(',',':')).encode())+1
                if size+extra>MAX_RAW_BYTES:
                    if not pairs:raise rules.Denied('OBSERVATION_TOO_LARGE_TO_ARCHIVE')
                    break
                size+=extra;pairs.append(pair);source.append(row)
            result={'compacted':0,'raw_bytes':0,'packed_bytes':0,'has_more':False}
            if pairs:
                raw=json.dumps(pairs,ensure_ascii=False,separators=(',',':')).encode('utf-8')
                packed=zlib.compress(raw,6)
                segment={'id':hashlib.sha256(raw).hexdigest(),'codec':CODEC,'raw_bytes':len(raw),
                         'members':len(pairs),'packed':packed,'packed_sha256':hashlib.sha256(packed).hexdigest()}
                if unpack_segment(segment)!=dict(pairs):_bad()
                self.db.execute('''INSERT INTO perception_segments
                    (id,codec,raw_bytes,members,packed,packed_sha256) VALUES(:id,:codec,:raw_bytes,:members,:packed,:packed_sha256)''',segment)
                # Read back stored bytes before removing a single hot payload.
                verified=unpack_segment(self.db.execute('SELECT * FROM perception_segments WHERE id=?',(segment['id'],)).fetchone())
                if verified!=dict(pairs):_bad()
                self.db.executemany('INSERT INTO perception_segment_members VALUES(?,?)',((r['id'],segment['id']) for r in source))
                self._retire_hot([r['id'] for r in source])
                result.update(compacted=len(pairs),raw_bytes=len(raw),packed_bytes=len(packed),segment_id=segment['id'])
            result['has_more']=self.db.execute("SELECT 1 FROM perception_observations WHERE body<>'' AND expires_at<=? LIMIT 1",(cutoff,)).fetchone() is not None
            self.db.execute('RELEASE observation_compaction')
            return result
        except BaseException:
            self.db.execute('ROLLBACK TO observation_compaction');self.db.execute('RELEASE observation_compaction')
            raise

    def maybe_compact(self,now):
        due=float(self.owner.meta('perception_archive_due'))
        if now<due:return None
        result=self.compact(now)
        self.owner.setmeta('perception_archive_due',now+(1.0 if result['has_more'] else CHECK_INTERVAL))
        return result


def verify_all(db):
    """Read-only archive verification with each compressed segment decoded once."""
    observations=0;hot=0;cold=0;raw_bytes=0;packed_bytes=0
    from .perception import SCHEMA
    def check(row,body):
        if hashlib.sha256(body.encode()).hexdigest()!=row['digest']:_bad()
        value=json.loads(body)
        if value['schema']!=SCHEMA or any(value[k]!=row[k] for k in IDENTITY if k not in ('ordinal','digest')):_bad()
    for row in db.execute("SELECT * FROM perception_observations WHERE body<>''"):
        check(row,row['body']);observations+=1;hot+=1
    for segment in db.execute('SELECT * FROM perception_segments ORDER BY id'):
        bodies=unpack_segment(segment);raw_bytes+=segment['raw_bytes'];packed_bytes+=len(segment['packed'])
        members=db.execute('''SELECT o.* FROM perception_observations o
            JOIN perception_segment_members m ON m.observation_id=o.id WHERE m.segment_id=?''',(segment['id'],)).fetchall()
        if {r['id'] for r in members}!=set(bodies):_bad()
        for row in members:
            if row['body']!='':_bad()
            check(row,bodies[row['id']]);observations+=1;cold+=1
    if observations!=db.execute('SELECT count(*) FROM perception_observations').fetchone()[0]:_bad()
    if cold!=db.execute('SELECT count(*) FROM perception_segment_members').fetchone()[0]:_bad()
    return {'ok':True,'observations':observations,'hot':hot,'cold':cold,
            'archived_raw_bytes':raw_bytes,'archived_packed_bytes':packed_bytes,
            'boundary':'Lossless payload compression; IDs, indexes, audit and delivery receipts still occupy growing storage.'}
