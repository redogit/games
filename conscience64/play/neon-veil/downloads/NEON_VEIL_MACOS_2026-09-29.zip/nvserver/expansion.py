"""0.30 gameplay extension. Every mutation runs inside GameService's intent
transaction; costs, ranks, custody, clock and rewards are never client facts.
"""
import json,math
from pathlib import Path
from . import rules
from .world import make_world,passable,line_of_sight,SPAWN
CATALOG=json.loads((Path(__file__).resolve().parents[1]/'client/data/catalog.json').read_text())
SPECIES={x['id']:x for x in CATALOG['species']}
CLASSES={x['id']:x for x in CATALOG['classes']}
JOBS={x['id']:x for x in CATALOG['jobs']}
PATHS={x['id']:x for x in CATALOG['paths']}
NODES={x['id']:x for x in CATALOG['nodes']}
GOALS={x['id']:x for x in CATALOG['goals']}
GOODS={x['id']:x for x in CATALOG['goods']}
OPS={'goal','learn','secondary','buy','sell','equip','consume','work','ability'}
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def obj(c,k,default=None):
    v=c[k];return json.loads(v) if isinstance(v,str) else (v if v is not None else default)
def xp_for(level):return 20*level+3*level*(level-1)

class Expansion:
    def _migrate_expansion(self,now):
        cols={r['name'] for r in self.db.execute('PRAGMA table_info(characters)')}
        additions={'species':"TEXT NOT NULL DEFAULT 'human'",'base_class':"TEXT NOT NULL DEFAULT 'guardian'",'job_role':"TEXT NOT NULL DEFAULT 'courier'",'start_path':"TEXT NOT NULL DEFAULT 'explore'",'secondary_class':'TEXT', 'skills':"TEXT NOT NULL DEFAULT '{}'", 'goals':"TEXT NOT NULL DEFAULT '{}'",'discoveries':"TEXT NOT NULL DEFAULT '[]'",'buffs':"TEXT NOT NULL DEFAULT '{}'",'last_work':'REAL NOT NULL DEFAULT 0','last_ability':'REAL NOT NULL DEFAULT 0'}
        for name,definition in additions.items():
            if name not in cols:self.db.execute(f'ALTER TABLE characters ADD COLUMN {name} {definition}')
        icols={r['name'] for r in self.db.execute('PRAGMA table_info(items)')}
        for name,definition in {'sku':'TEXT','slot':'TEXT','equipped':'INTEGER NOT NULL DEFAULT 0'}.items():
            if name not in icols:self.db.execute(f'ALTER TABLE items ADD COLUMN {name} {definition}')
        self.db.execute('CREATE TABLE IF NOT EXISTS shops(id TEXT PRIMARY KEY,treasury INTEGER NOT NULL CHECK(treasury>=0),restocked REAL NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS offers(shop_id TEXT NOT NULL REFERENCES shops(id),sku TEXT NOT NULL,stock INTEGER NOT NULL CHECK(stock>=0),version INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(shop_id,sku))')
        world=json.loads(self.meta('world'))
        if world.get('generation')!='0.30':
            self.setmeta('world_pre030',enc(world));new=make_world(world.get('seed',270926));new['npcs']=world.get('npcs',new['npcs']);self.setmeta('world',enc(new));world=new
            self._event(now,'REGION_OPENED',None,{'preserved_world':'world_pre030','generation':'0.30'})
        for c in self.db.execute('SELECT * FROM characters WHERE alive=1').fetchall():
            if not passable(world,c['x'],c['y']):
                self.db.execute('UPDATE characters SET x=?,y=? WHERE id=?',(*SPAWN,c['id']))
                self._event(now,'MIGRATION_RELOCATION',c['id'],{'from':[c['x'],c['y']],'to':list(SPAWN)})
        if self.meta('expansion_version')!='0.30':
            self.db.execute("UPDATE items SET slot='hand',equipped=0 WHERE kind='blade'")
            # Old inventories could contain many blades. Preserve all identities
            # and custody, but select only one hand item under the new slot rule.
            seen=set()
            for it in self.db.execute("SELECT id,holder_id FROM items WHERE kind='blade' AND holder_type='character' ORDER BY power DESC,id").fetchall():
                if it['holder_id'] not in seen:
                    seen.add(it['holder_id']);self.db.execute('UPDATE items SET equipped=1 WHERE id=?',(it['id'],))
            # Legacy practice is mapped once, not reinterpreted on later launches.
            self.db.execute("UPDATE characters SET base_class=CASE specialty WHEN 'cipher' THEN 'artificer' WHEN 'hexer' THEN 'scholar' ELSE 'guardian' END")
            self.setmeta('expansion_version','0.30');self.setmeta('schema','0.30.0')
        for f in world['features']:
            if f['kind']!='shop':continue
            self.db.execute('INSERT OR IGNORE INTO shops VALUES(?,?,?)',(f['id'],600,now))
            for g in GOODS.values():self.db.execute('INSERT OR IGNORE INTO offers(shop_id,sku,stock) VALUES(?,?,?)',(f['id'],g['id'],g['capacity']))

    def _build_choice(self,args):
        spec=args.get('specialty','blade');base=args.get('base_class',{'blade':'guardian','cipher':'artificer','hexer':'scholar'}.get(spec,'guardian'))
        if spec not in rules.SPECIALTIES:raise rules.Denied('UNKNOWN_SPECIALTY')
        result={'species':args.get('species','human'),'base_class':base,'job_role':args.get('job_role','courier'),'start_path':args.get('start_path','explore')}
        for key,catalog in [('species',SPECIES),('base_class',CLASSES),('job_role',JOBS),('start_path',PATHS)]:
            if not isinstance(result[key],str) or result[key] not in catalog:raise rules.Denied('INVALID_BUILD','Choose a listed '+key.replace('_',' ')+'.')
        return result

    def _initialize_build(self,cid,choice,now):
        self.db.execute('UPDATE characters SET species=?,base_class=?,job_role=?,start_path=?,specialty=? WHERE id=?',(choice['species'],choice['base_class'],choice['job_role'],choice['start_path'],CLASSES[choice['base_class']]['specialty'],cid))
        self.db.execute("UPDATE items SET slot='hand',equipped=1 WHERE holder_type='character' AND holder_id=? AND kind='blade'",(cid,))
        self._event(now,'BUILD_CHOSEN',cid,choice)

    def _tree(self,c):
        base=c['base_class'];second=c['secondary_class'];pair='.'.join(sorted([base,second])) if second else ''
        rows=[];skills=obj(c,'skills',{});points=max(0,c['level']-1-sum(skills.values()))
        for n in NODES.values():
            valid=(n['tree']=='base' and n['owner'] in (base,second)) or (n['tree']=='job' and n['owner']==c['job_role']) or(n['tree']=='combo' and n['owner']==pair)
            if not valid:continue
            floor=max(51,49+n['level']) if n['tree']=='base' and n['owner']==second else n['level']
            rank=skills.get(n['id'],0);ready=c['level']>=floor and points>=n['cost'] and rank<n['max_rank'] and all(skills.get(k,0)>=v for k,v in n['requires'])
            rows.append({**n,'level':floor,'rank':rank,'available':ready})
        return rows

    def _effects(self,c):
        effects={'health':0,'focus':0,'armor':0,'damage':0,'speed':0,'healing':0,'discount':0,'cooldown':0,'scan':0,'xp':0}
        for id,rank in obj(c,'skills',{}).items():
            n=NODES.get(id)
            if n and n['effect']:effects[n['effect']]+=n['value']*rank
        for i in self.db.execute("SELECT * FROM items WHERE holder_type='character' AND holder_id=? AND equipped=1",(c['id'],)):
            g=GOODS.get(i['sku'],{});effects['armor']+=g.get('armor',0);effects['focus']+=g.get('focus_bonus',0)
        effects['armor']=min(.3,effects['armor']);effects['discount']=min(.12,effects['discount']);effects['speed']=min(.15,effects['speed']);return effects

    def _focus_max(self,c):return (6 if c['specialty']=='hexer' else 4)+self._effects(c)['focus']
    def _abilities(self,c):
        names=['strike','interact','scan','rest',CLASSES[c['base_class']]['ability']]
        if c['secondary_class']:names.append(CLASSES[c['secondary_class']]['ability'])
        if c['specialty']=='hexer':names.append('ward')
        for id,rank in obj(c,'skills',{}).items():
            if rank and NODES.get(id,{}).get('ability'):names.append(NODES[id]['ability'])
        return sorted(set(names))

    def _award_xp(self,cid,amount,now,reason):
        c=self.db.execute('SELECT * FROM characters WHERE id=?',(cid,)).fetchone();xp=c['xp']+max(0,int(amount*(1+self._effects(c)['xp'])));level=c['level']
        while level<100 and xp>=xp_for(level):level+=1
        self.db.execute('UPDATE characters SET xp=?,level=? WHERE id=?',(xp,level,cid))
        if level>c['level']:self._event(now,'LEVEL_GAINED',cid,{'from':c['level'],'level':level,'skill_points':level-c['level'],'reason':reason})
        return level

    def _goal_projection(self,c):
        saved=obj(c,'goals',{});return [{**g,**saved.get(g['id'],{'state':'offered','tracked':False,'progress':{}})} for g in GOALS.values()]

    def _goal_signal(self,cid,signal,amount,now):
        c=self.db.execute('SELECT * FROM characters WHERE id=?',(cid,)).fetchone();saved=obj(c,'goals',{});changed=False
        for gid,g in saved.items():
            spec=GOALS.get(gid)
            if not spec or g['state']!='active' or signal not in spec['required']:continue
            g['progress'][signal]=min(spec['required'][signal],g['progress'].get(signal,0)+amount);changed=True
            if all(g['progress'].get(k,0)>=v for k,v in spec['required'].items()):
                g['state']='complete';g['tracked']=False
                # Relay's reward is paid only by physically returning the item.
                if gid!='relay':
                    self._award_xp(cid,spec['xp'],now,'goal:'+gid);self.db.execute('UPDATE characters SET cred=cred+? WHERE id=?',(spec['cred'],cid))
                self._event(now,'GOAL_COMPLETED',cid,{'goal':gid})
        if changed:self.db.execute('UPDATE characters SET goals=? WHERE id=?',(enc(saved),cid))

    def _goal_action(self,c,args,now):
        self._fields(args,{'goal_id','action'});gid=args.get('goal_id');action=args.get('action');data=obj(c,'goals',{})
        if not isinstance(gid,str) or gid not in GOALS or action not in ('start','pause','resume','abandon','track','untrack'):raise rules.Denied('INVALID_GOAL')
        g=data.get(gid,{'state':'offered','tracked':False,'progress':{}})
        if g['state']=='complete':raise rules.Denied('GOAL_ALREADY_COMPLETE','Completed goals cannot pay again.')
        if action in ('start','resume','track'):
            for q in data.values():q['tracked']=False
            g['state']='active';g['tracked']=True
        elif action=='pause':g['state']='paused';g['tracked']=False
        elif action=='abandon':g['state']='abandoned';g['tracked']=False
        else:g['tracked']=False
        data[gid]=g;self.db.execute('UPDATE characters SET goals=? WHERE id=?',(enc(data),c['id']));self._event(now,'GOAL_CHANGED',c['id'],{'goal':gid,'state':g['state'],'tracked':g['tracked']});return {'message':'Goal '+g['state']+'. You remain free to explore.'}

    def _shop(self,c,sid,world):
        if not isinstance(sid,str):raise rules.Denied('UNKNOWN_SHOP')
        f=next((f for f in world['features'] if f['kind']=='shop' and f['id']==sid),None)
        if not f:raise rules.Denied('UNKNOWN_SHOP')
        if math.hypot(c['x']-f['x'],c['y']-f['y'])>2.3 or not line_of_sight(world,c['x'],c['y'],f['x'],f['y']):raise rules.Denied('OUT_OF_REACH','Visit the shop before trading.')
        status=self.blackout.service_status(sid)
        if not status['open']:raise rules.Denied('SERVICE_UNAVAILABLE',status['note'])
        return self.db.execute('SELECT * FROM shops WHERE id=?',(sid,)).fetchone()

    def _quote(self,c,offer,now):
        g=GOODS[offer['sku']];effects=self._effects(c) if c else {'discount':0};buffs=obj(c,'buffs',{}) if c else {}
        discount=effects['discount']+(.05 if buffs.get('bargain',0)>now else 0)
        # Stock-sensitive prices, bounded above/below; sell price is always below buy price.
        price=math.ceil(g['price']*(1+.25*(1-offer['stock']/g['capacity']))*(1-discount)*self.blackout.price_multiplier(offer['shop_id'],offer['sku']))
        return max(math.ceil(g['price']*.8),price)

    def _market_tick(self,now):
        for v in self.db.execute('SELECT * FROM shops WHERE restocked+300<=?',(now,)).fetchall():
            slots=min(6,int((now-v['restocked'])//300))
            for row in self.db.execute('SELECT * FROM offers WHERE shop_id=?',(v['id'],)).fetchall():
                if not self.blackout.restock_allowed(v['id'],row['sku']):continue
                stock=min(GOODS[row['sku']]['capacity'],row['stock']+slots)
                if stock!=row['stock']:self.db.execute('UPDATE offers SET stock=?,version=version+1 WHERE shop_id=? AND sku=?',(stock,v['id'],row['sku']))
            # Daily neighborhood supply budget is an explicit bounded world source, not a trade exploit.
            treasury=min(1000,v['treasury']+slots*15)
            self.db.execute('UPDATE shops SET restocked=?,treasury=? WHERE id=?',(v['restocked']+int((now-v['restocked'])//300)*300,treasury,v['id']))
            self._event(now,'MARKET_RESTOCKED',None,{'shop':v['id'],'bounded_intervals':slots})

    def _exp_dispatch(self,c,op,args,now,world):
        if op=='goal':return self._goal_action(c,args,now)
        if op=='secondary':
            self._fields(args,{'class_id'});cid=args.get('class_id')
            if c['level']<=50:raise rules.Denied('SECONDARY_LOCKED','A second class opens after level 50: level 51.')
            if c['secondary_class']:raise rules.Denied('SECONDARY_CHOSEN','Your primary class and chosen secondary are preserved.')
            if not isinstance(cid,str) or cid not in CLASSES or cid==c['base_class']:raise rules.Denied('INVALID_SECONDARY')
            self.db.execute('UPDATE characters SET secondary_class=? WHERE id=?',(cid,c['id']));self._event(now,'SECONDARY_CHOSEN',c['id'],{'primary':c['base_class'],'secondary':cid});return {'message':'A second discipline, not a replacement for your first.'}
        if op=='learn':
            self._fields(args,{'node_id'});nid=args.get('node_id');n=next((n for n in self._tree(c) if n['id']==nid),None)
            if not n or not n['available']:raise rules.Denied('SKILL_LOCKED','Check level, previous ranks and available skill points.')
            skills=obj(c,'skills',{});skills[nid]=skills.get(nid,0)+1;self.db.execute('UPDATE characters SET skills=? WHERE id=?',(enc(skills),c['id']))
            fresh=self.db.execute('SELECT * FROM characters WHERE id=?',(c['id'],)).fetchone();maxhp=24+self._effects(fresh)['health'];self.db.execute('UPDATE characters SET max_hp=?,hp=min(hp,?) WHERE id=?',(maxhp,maxhp,c['id']))
            self._event(now,'SKILL_LEARNED',c['id'],{'node':nid,'rank':skills[nid]});return {'message':n['name']+' improved one small step.'}
        if op in ('buy','sell','work'):
            allowed={'shop_id','sku','version','quoted_price'} if op=='buy' else ({'shop_id','item_id','version'} if op=='sell' else {'shop_id'})
            self._fields(args,allowed);sid=args.get('shop_id');shop=self._shop(c,sid,world)
            if op=='work':
                if now-c['last_work']<60:raise rules.Denied('SHIFT_COOLDOWN','Another local shift opens after sixty seconds.')
                if shop['treasury']<18:raise rules.Denied('SHOP_FUNDS','The shop cannot fund a shift right now.')
                self.db.execute('UPDATE shops SET treasury=treasury-18 WHERE id=?',(sid,));self.db.execute('UPDATE characters SET cred=cred+18,last_work=? WHERE id=?',(now,c['id']));self._award_xp(c['id'],5,now,'work');self._goal_signal(c['id'],'work',1,now)
                self._event(now,'LOCAL_WORK',c['id'],{'shop':sid,'job':c['job_role'],'cred':18});return {'message':'A short '+JOBS[c['job_role']]['name'].lower()+' shift: 18 cred, 5 experience.'}
            if op=='buy':
                sku=args.get('sku');offer=self.db.execute('SELECT * FROM offers WHERE shop_id=? AND sku=?',(sid,sku if isinstance(sku,str) else '')).fetchone()
                if not offer:raise rules.Denied('UNKNOWN_GOOD')
                if type(args.get('version')) is not int or args['version']!=offer['version']:raise rules.Denied('STALE_QUOTE','Stock changed. Read the fresh quote before buying.')
                if offer['stock']<=0:raise rules.Denied('OUT_OF_STOCK')
                price=self._quote(c,offer,now)
                if 'quoted_price' in args and (type(args['quoted_price']) is not int or args['quoted_price']!=price):raise rules.Denied('STALE_QUOTE','The price changed. Confirm the current quote before buying.')
                if c['cred']<price:raise rules.Denied('INSUFFICIENT_CRED')
                g=GOODS[sku];self.db.execute('UPDATE characters SET cred=cred-? WHERE id=?',(price,c['id']));self.db.execute('UPDATE shops SET treasury=treasury+? WHERE id=?',(price,sid));self.db.execute('UPDATE offers SET stock=stock-1,version=version+1 WHERE shop_id=? AND sku=?',(sid,sku))
                ident=self._new_item(g['kind'],g['name'],'character',c['id'],power=g['power']);self.db.execute('UPDATE items SET sku=?,slot=? WHERE id=?',(sku,g['slot'],ident))
                self._goal_signal(c['id'],'purchase',1,now);self._event(now,'PURCHASED',c['id'],{'item':ident,'shop':sid,'paid':price});return {'item_id':ident,'message':g['name']+' purchased.'}
            it=self._held(c,args)
            if it['kind'] in ('relay_data','relay_shard') or (not it['sku'] and it['kind'] not in ('salvage','blade','medkit')):raise rules.Denied('NOT_TRADEABLE')
            sku=it['sku'] or ('salvage' if it['kind']=='salvage' else 'shock_blade' if it['kind']=='blade' else 'medkit');g=GOODS[sku];price=math.floor(g['price']*.35)
            if not it['sku'] and it['kind']=='blade':price=0 # starter tool cannot mint money through replacement characters
            if not it['sku'] and it['kind']=='medkit':price=0
            if price==0:raise rules.Denied('STARTER_NOT_RESALE','Starter supplies are usable, not a character-creation money source.')
            if shop['treasury']<price:raise rules.Denied('SHOP_FUNDS')
            self.db.execute("UPDATE items SET holder_type='reclaimed',holder_id=NULL,equipped=0,version=version+1 WHERE id=?",(it['id'],));self.db.execute('UPDATE characters SET cred=cred+? WHERE id=?',(price,c['id']));self.db.execute('UPDATE shops SET treasury=treasury-? WHERE id=?',(price,sid));self.db.execute('UPDATE offers SET stock=min(?,stock+1),version=version+1 WHERE shop_id=? AND sku=?',(g['capacity'],sid,sku));self.db.execute('UPDATE characters SET focus=min(focus,?) WHERE id=?',(self._focus_max(c),c['id']));self._event(now,'SOLD',c['id'],{'item':it['id'],'shop':sid,'received':price});return {'message':'Sold for '+str(price)+' cred.'}
        if op in ('equip','consume'):
            self._fields(args,{'item_id','version'});it=self._held(c,args);g=GOODS.get(it['sku'],{})
            if op=='equip':
                if not it['slot']:raise rules.Denied('NOT_EQUIPMENT')
                self.db.execute("UPDATE items SET equipped=0,version=version+1 WHERE holder_type='character' AND holder_id=? AND slot=? AND equipped=1",(c['id'],it['slot']))
                self.db.execute('UPDATE items SET equipped=1,version=version+1 WHERE id=?',(it['id'],));self.db.execute('UPDATE characters SET focus=min(focus,?) WHERE id=?',(self._focus_max(c),c['id']));self._event(now,'EQUIPPED',c['id'],{'item':it['id'],'slot':it['slot']});return {'message':it['name']+' equipped.'}
            if it['kind'] not in ('food','medkit'):raise rules.Denied('NOT_CONSUMABLE')
            heal=g.get('heal',10 if it['kind']=='medkit' else 0)*(1+self._effects(c)['healing']);focus=g.get('focus',0)
            if c['hp']>=c['max_hp'] and c['focus']>=self._focus_max(c):raise rules.Denied('NO_BENEFIT','You are already recovered. Keep the food for later.')
            self.db.execute("UPDATE items SET holder_type='reclaimed',holder_id=NULL,equipped=0,version=version+1 WHERE id=?",(it['id'],))
            self.db.execute('UPDATE characters SET hp=min(max_hp,hp+?),focus=min(?,focus+?),last_pvp=CASE WHEN hp+?>=max_hp THEN 0 ELSE last_pvp END WHERE id=?',(heal,self._focus_max(c),focus,heal,c['id']));self._event(now,'CONSUMED',c['id'],{'item':it['id'],'kind':it['kind']});return {'message':it['name']+' used. No upkeep chore added.'}
        if op=='ability':
            self._fields(args,{'ability_id'});ability=args.get('ability_id')
            if ability not in self._abilities(c):raise rules.Denied('ABILITY_LOCKED')
            if ability in ('pulse','ward','lunge'):
                result=self._attack(c,{},now,world,'cast' if ability in ('pulse','ward') else 'lunge')
                self._goal_signal(c['id'],'practice',1,now);return result
            if ability in ('strike','interact','rest','scan'):raise rules.Denied('USE_DEFAULT_ACTION')
            cooldown=20 if ability=='cadence' else 12
            if now-c['last_ability']<cooldown*(1-min(.2,self._effects(c)['cooldown'])):raise rules.Denied('RECOVERING')
            cost=0 if ability=='cadence' else 3 if ability=='confluence' else 2 if ability=='mend' else 1
            if c['focus']<cost:raise rules.Denied('NO_FOCUS')
            buffs=obj(c,'buffs',{});hp=c['hp'];focus=c['focus']-cost
            if ability in ('mend','confluence'):
                if hp>=c['max_hp'] and ability=='mend':raise rules.Denied('ALREADY_HEALTHY')
                hp=min(c['max_hp'],hp+(10 if ability=='confluence' else 6)*(1+self._effects(c)['healing']))
            if ability=='cadence':focus=min(self._focus_max(c),focus+2)
            if ability in ('guard','confluence'):buffs['guard']=now+8
            if ability=='stride':buffs['stride']=now+6
            if ability=='bargain':buffs['bargain']=now+120
            if ability=='overcharge':buffs['overcharge']=now+8
            self.db.execute('UPDATE characters SET hp=?,focus=?,buffs=?,last_ability=?,last_pvp=CASE WHEN ?>=max_hp THEN 0 ELSE last_pvp END WHERE id=?',(hp,focus,enc(buffs),now,hp,c['id']))
            self._goal_signal(c['id'],'practice',1,now);self._event(now,'ABILITY_USED',c['id'],{'ability':ability});return {'message':ability.capitalize()+' applied.'}
        raise rules.Denied('UNKNOWN_OPERATION')

    def _held(self,c,args):
        it=self.db.execute('SELECT * FROM items WHERE id=?',(args.get('item_id'),)).fetchone()
        if not it or it['holder_type']!='character' or it['holder_id']!=c['id']:raise rules.Denied('NOT_IN_CUSTODY')
        if type(args.get('version')) is not int or args['version']!=it['version']:raise rules.Denied('STALE_VERSION')
        return it

    def _place_visit(self,c,f,now):
        seen=obj(c,'discoveries',[])
        if f['kind']=='shop':
            self._goal_signal(c['id'],'shop',1,now)
            status=self.blackout.service_status(f['id'])
            return {'shop_id':f['id'],'message':status['note'] if not status['open'] or not status['refrigeration'] else f['name']+': browse, trade or take a short shift.'}
        if f['kind']=='landmark':
            if f['id'] not in seen:
                seen.append(f['id']);self.db.execute('UPDATE characters SET discoveries=? WHERE id=?',(enc(seen),c['id']));self._award_xp(c['id'],12,now,'discovery');self._goal_signal(c['id'],'landmark',1,now);self._event(now,'DISCOVERED',c['id'],{'place':f['name']});return {'message':f['name']+' discovered. 12 experience.'}
            return {'message':f['name']+'. A place you know, not a repeat reward.'}
        return None

    def _project_character(self,p):
        for key in ('skills','goals','discoveries','buffs'):
            if isinstance(p[key],str):p[key]=json.loads(p[key])
        p['skill_points']=max(0,p['level']-1-sum(p['skills'].values()));p['next_level_xp']=xp_for(p['level']);p['abilities']=self._abilities(p);p['focus_max']=self._focus_max(p);p['effects']=self._effects(p)
        if p['secondary_class']:p['combo_name']=' / '.join(CLASSES[k]['name'] for k in (p['base_class'],p['secondary_class']))
        else:p['combo_name']=None
        return p

    def _snapshot_expansion(self,p,world,now):
        vendors=[]
        for f in world['features']:
            if f['kind']!='shop':continue
            v=self.db.execute('SELECT * FROM shops WHERE id=?',(f['id'],)).fetchone();offers=[]
            for o in self.db.execute('SELECT * FROM offers WHERE shop_id=? ORDER BY sku',(v['id'],)):
                g=GOODS[o['sku']];offers.append({**g,'sku':o['sku'],'stock':o['stock'],'version':o['version'],'price':self._quote(p,o,now),'sell_price':math.floor(g['price']*.35)})
            vendors.append({**f,'treasury':v['treasury'],'offers':offers,'service':self.blackout.service_status(f['id'])})
        return {'goals':self._goal_projection(p) if p else [],'skill_tree':self._tree(p) if p else [],'shops':vendors,'catalog_version':CATALOG['schema']}
