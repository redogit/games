"""Versioned admission rules. Presentation never grants an entitlement."""
import math
import re
import unicodedata

VERSION = 'neon-veil/intent/1'
SLOT_SECONDS = 86400
SHORT_RECOVERY = 300
LONG_RECOVERY = 900
POWER_RATIO = .8
MAX_LEVEL_DELTA = 2
SPECIALTIES = ('blade', 'cipher', 'hexer')
SHAPE_KEYS = ('height','head','headWidth','headDepth','jaw','neck','shoulders','chest','depth','waist','hips','torso','arms','armThickness','legs','legThickness','hands','feet','gluteDepth','calf')
DEFAULT_APPEARANCE = {
    'skin':'#b98262','hair':'#19212b','eyes':'#82bba6','coat':'#253142','accent':'#70e0c7',
    'hair_style':'short','presentation':'neutral','pronouns':'',
    'shape': {k:1.0 for k in SHAPE_KEYS},
}
class Denied(Exception):
    def __init__(self, code, message=None):
        self.code=code; self.message=message or code.replace('_',' ').capitalize()
        super().__init__(self.message)

def number(value, lo, hi, field='value'):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not lo<=value<=hi:
        raise Denied('INVALID_PARAMETER',f'{field} must be a finite number between {lo} and {hi}.')
    return float(value)

def player_name(value):
    if not isinstance(value,str): raise Denied('INVALID_NAME')
    value=unicodedata.normalize('NFC',value).strip()
    if not 1<=len(value)<=32 or any(unicodedata.category(c).startswith('C') or c in '<>{}' for c in value):
        raise Denied('INVALID_NAME','Use 1–32 readable characters for your name.')
    return value

def appearance(value):
    if value is None: value={}
    if not isinstance(value,dict): raise Denied('INVALID_APPEARANCE')
    permitted=set(DEFAULT_APPEARANCE)|{'height'}
    if set(value)-permitted: raise Denied('APPEARANCE_FIELDS','Only appearance fields may be imported.')
    out={**DEFAULT_APPEARANCE,'shape':dict(DEFAULT_APPEARANCE['shape'])}
    for k,v in value.items():
        if k in ('skin','hair','eyes','coat','accent'):
            if not isinstance(v,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',v): raise Denied('INVALID_COLOR')
            out[k]=v.lower()
        elif k=='shape':
            if not isinstance(v,dict) or set(v)-set(SHAPE_KEYS): raise Denied('INVALID_SHAPE')
            for key,n in v.items(): out['shape'][key]=number(n,.6,1.5,key)
        elif k=='height': out['shape']['height']=number(v,.6,1.5,'height')
        elif k=='hair_style':
            if v not in ('short','crop','curls','long','locs','bald'): raise Denied('INVALID_STYLE')
            out[k]=v
        elif k=='presentation':
            if v not in ('neutral','soft','angular'): raise Denied('INVALID_STYLE')
            out[k]=v
        elif k=='pronouns':
            if not isinstance(v,str) or len(v)>32 or any(ord(c)<32 or c in '<>' for c in v): raise Denied('INVALID_PRONOUNS')
            out[k]=v
    return out

def slots(seconds): return 2 if seconds>SLOT_SECONDS else 1

def pvp_permission(attacker, victim, in_town):
    if in_town(attacker['x'],attacker['y']) or in_town(victim['x'],victim['y']): raise Denied('TOWN_PEACE','Town is protected. Violence against players is not allowed here.')
    if attacker['account_id']==victim['account_id']: raise Denied('SELF_ACCOUNT_PVP')
    p1=attacker['power'];p2=victim['power']
    if abs(attacker['level']-victim['level'])>MAX_LEVEL_DELTA or min(p1,p2)/max(p1,p2)<POWER_RATIO:
        raise Denied('POWER_BAND','That player is outside the fair combat band.')
