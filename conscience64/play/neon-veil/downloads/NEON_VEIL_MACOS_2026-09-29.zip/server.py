#!/usr/bin/env python3
"""NEON//VEIL local authoritative server; Python 3.10+, standard library only.

Loopback only by default. --lan is an explicit trusted-LAN development option,
not authentication hardening or permission to expose this process publicly.
"""
from __future__ import annotations
import argparse
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import re
import threading
import time
from urllib.parse import urlsplit, unquote, parse_qs
import webbrowser
from nvserver.service import GameService

ROOT=Path(__file__).resolve().parent
MAX_BODY=32768
class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self,address,service,static=ROOT/'client',lan=False):
        super().__init__(address,Handler);self.service=service;self.static=Path(static).resolve();self.lan=lan;self.closed=threading.Event();self.rate={};self.rate_lock=threading.Lock()
    def tick(self):
        while not self.closed.wait(.25):
            try:self.service.process()
            except Exception as e: print('World scheduler error:',type(e).__name__,flush=True)

class Handler(BaseHTTPRequestHandler):
    server_version='NeonVeil/0.30'
    protocol_version='HTTP/1.1'
    def setup(self):
        super().setup();self.connection.settimeout(10)
    def log_message(self,fmt,*args):
        if getattr(self.server,'verbose',False):super().log_message(fmt,*args)
    def _headers(self,code,ctype,length,cookie=None):
        self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(length))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers()
    def js(self,code,obj,cookie=None):
        data=json.dumps(obj,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode();self._headers(code,'application/json; charset=utf-8',len(data),cookie)
        if self.command!='HEAD': self.wfile.write(data)
    def denied(self,code,message):self.js(code,{'ok':False,'code':'HTTP_REJECTED','message':message})
    def host_ok(self):
        host=self.headers.get('Host','');port=self.server.server_port
        allowed={f'127.0.0.1:{port}',f'localhost:{port}',f'[::1]:{port}'}
        if self.server.lan:
            # LAN mode still rejects arbitrary DNS hostnames/rebinding.
            try:
                import ipaddress
                ip=ipaddress.ip_address(host.rsplit(':',1)[0]);allowed.add(host) if ip.is_private and host.endswith(':'+str(port)) else None
            except ValueError:pass
        return host in allowed
    def session(self):
        try:
            c=SimpleCookie();c.load(self.headers.get('Cookie',''));token=c['nv_session'].value if 'nv_session' in c else ''
        except Exception: token=''
        return self.server.service.resolve_session(token)
    def do_HEAD(self):self.do_GET()
    def do_GET(self):
        if not self.host_ok():return self.denied(403,'Unrecognized host.')
        path=urlsplit(self.path).path
        try:
            if path=='/api/session':
                if self.headers.get('Sec-Fetch-Site')=='cross-site':return self.denied(403,'Same-origin session required.')
                s=self.session();cookie=None
                if not s:
                    s=self.server.service.new_account();cookie=f"nv_session={s['token']}; Path=/; HttpOnly; SameSite=Strict; Max-Age=31536000"
                return self.js(200,{'ok':True,'account_id':s['id'],'csrf':s['csrf'],'version':'0.30.0'},cookie)
            if path=='/api/state':
                s=self.session()
                if not s:return self.denied(401,'Open a local session first.')
                return self.js(200,self.server.service.snapshot(s['id'],geometry_id=parse_qs(urlsplit(self.path).query).get('geometry',[''])[0]))
            if path.startswith('/api/'):return self.denied(404,'Unknown endpoint.')
            p=(self.server.static/unquote(path).lstrip('/')).resolve()
            if path=='/':p=self.server.static/'index.html'
            if not p.is_relative_to(self.server.static) or not p.is_file() or p.suffix.lower() not in {'.html','.css','.js','.json','.svg','.png','.webp','.ico'}:
                return self.denied(404,'Resource not found.')
            data=p.read_bytes();ctype=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
            if p.suffix in ('.html','.css','.js','.json'):ctype+='; charset=utf-8'
            self._headers(200,ctype,len(data))
            if self.command!='HEAD':self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:
            print('Request error:',type(e).__name__,flush=True);self.denied(500,'Server could not complete this request.')
    def do_POST(self):
        if not self.host_ok():self.close_connection=True;return self.denied(403,'Unrecognized host.')
        origin=self.headers.get('Origin');expected='http://'+self.headers.get('Host','')
        if origin and origin!=expected:self.close_connection=True;return self.denied(403,'Same-origin request required.')
        if self.headers.get('Sec-Fetch-Site')=='cross-site':self.close_connection=True;return self.denied(403,'Cross-site request rejected.')
        s=self.session()
        if not s or self.headers.get('X-NV-CSRF')!=s['csrf']:self.close_connection=True;return self.denied(403,'Session and request token required.')
        if not self.headers.get('Content-Type','').startswith('application/json'):self.close_connection=True;return self.denied(415,'Use JSON.')
        try:
            n=int(self.headers.get('Content-Length','-1'))
            if not 0<=n<=MAX_BODY:raise ValueError()
        except ValueError:self.close_connection=True;return self.denied(413,'Request exceeds the size limit.')
        try:body=json.loads(self.rfile.read(n),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
        except (ValueError,UnicodeError):return self.denied(400,'Malformed JSON.')
        with self.server.rate_lock:
            now=time.monotonic();start,count=self.server.rate.get(s['id'],(now,0))
            if now-start>=1:start,count=now,0
            if count>=40:return self.denied(429,'Input rate limit. Slow down and retry.')
            self.server.rate[s['id']]=(start,count+1)
        path=urlsplit(self.path).path
        try:
            if path=='/api/heartbeat':
                if not isinstance(body,dict) or set(body)-{'focused'}:return self.denied(400,'Unexpected heartbeat fields.')
                credited=self.server.service.heartbeat(s['id'],body.get('focused') is True)
                return self.js(200,{'ok':True,'credited':credited})
            if path=='/api/intent':return self.js(200,self.server.service.intent(s['id'],body))
            return self.denied(404,'Unknown endpoint.')
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:
            print('Intent error:',type(e).__name__,flush=True);return self.denied(500,'Server could not complete this request.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',type=int,default=8080);p.add_argument('--data',type=Path,default=ROOT/'data/world.sqlite3')
    p.add_argument('--open',action='store_true');p.add_argument('--lan',action='store_true',help='Explicit trusted LAN testing only, no public internet')
    args=p.parse_args()
    if not 1024<=args.port<=65535:p.error('Choose a port from 1024 to 65535.')
    service=GameService(args.data)
    try:srv=Server(('0.0.0.0' if args.lan else '127.0.0.1',args.port),service,lan=args.lan)
    except OSError as e:
        service.close();print(f'Cannot bind port {args.port}: {e}. Choose another --port.');return 1
    thread=threading.Thread(target=srv.tick,daemon=True);thread.start()
    url=f'http://127.0.0.1:{args.port}/'
    print(f'NEON//VEIL 0.30\n{url}\nPersistent world: {args.data}\nCtrl+C stops the server. Deadlines catch up on restart.',flush=True)
    if args.lan:print('Trusted LAN mode. Do not forward this port to the internet.',flush=True)
    if args.open:threading.Timer(.4,lambda:webbrowser.open(url)).start()
    try:srv.serve_forever()
    except KeyboardInterrupt:pass
    finally:srv.closed.set();srv.server_close();thread.join(2);service.close()
    return 0
if __name__=='__main__':raise SystemExit(main())
