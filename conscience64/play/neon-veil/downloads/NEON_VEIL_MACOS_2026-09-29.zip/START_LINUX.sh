#!/bin/sh
# Named convenience entry; real platform detection stays in the shared controller.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
exec sh "$ROOT/START_NEON_VEIL.sh" "$@"
