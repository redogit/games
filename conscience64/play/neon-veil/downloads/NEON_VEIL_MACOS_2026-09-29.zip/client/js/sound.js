/* Committed server projection -> the retained Musilanguage game engine -> audio.
 * This is an artistic adapter, not semantic translation or world authority. */
'use strict';
(()=>{
class Soundscape{
 constructor(){this.context=null;this.enabled=false;this.volume=.14;this.timer=null;this.step=0;this.next=0;this.notes=0;this.master=null;this.rainGain=null;this.engine=null;this.analyser=null}
 state(){const s=window.NeonAPI?.state,p=s?.player,a=s?.world?.atmosphere;const reg=s?.world?.regions?.find(r=>p&&p.x>=r.x1&&p.x<r.x2&&p.y>=r.y1&&p.y<r.y2),room=s?.world?.buildings?.find(b=>p&&p.x>b.x1+1&&p.x<b.x2&&p.y>b.y1+1&&p.y<b.y2);return {mode:reg?.id==='veil-gardens'?'astral':room?.id==='observatory'?'matrix':'street',region:reg?.id,room:!!room,music:{rhythm:window.NeonPower.poweredAt(s?.world,p?.x,p?.y)?0xad:0x89},style:'dark-ambient',s,p,a}}
 danger(){const s=window.NeonAPI?.state,p=s?.player;if(!p)return 0;return Math.min(1,s.world.npcs.filter(n=>n.hp>0&&Math.hypot(n.x-p.x,n.y-p.y)<6).length*.23+(p.hp<8?.25:0))}
 async toggle(){if(this.enabled){this.stop();return false}await this.start();return this.enabled}
 async start(){
  const C=window.AudioContext||window.webkitAudioContext;if(!C)throw Error('Audio is not supported in this browser.');
  if(!this.context){this.context=new C();this.master=this.context.createGain();this.master.gain.value=0;const compressor=this.context.createDynamicsCompressor();compressor.threshold.value=-18;compressor.ratio.value=4;this.analyser=this.context.createAnalyser();this.master.connect(compressor);compressor.connect(this.analyser);this.analyser.connect(this.context.destination);
   this.engine=window.createNeonVeilMusilanguage({worldSemantics:()=>({danger:this.danger(),profile:'dark-ambient',bpm:86+Math.round(this.danger()*20)}),campaign:()=>({heat:this.state().p?.heat||0}),ensureJob:()=>({complete:this.state().p?.job==='complete'}),getState:()=>this.state(),motifForCurrent:()=>this.state().region==='greenway'?[50,57,62,65,62,60,57,53]:this.state().region==='tidal-reach'?[50,53,57,60,57,53,50,48]:[50,57,60,62,57,65,60,57],beatCycle:()=>4,musicType:()=> 'triangle',kick:(t,a)=>this.kick(t,a),noiseHit:(t,d,a)=>this.noise(t,d,a),synthNote:(f,t,d,a,type,pan,detune)=>this.note(f,t,d,a,type,pan,detune),midiHz:n=>440*Math.pow(2,(n-69)/12)});
  }
  await this.context.resume();if(this.context.state!=='running')throw Error('Audio is suspended. Tap Sound again.');
  this.enabled=true;this.master.gain.setTargetAtTime(this.volume,this.context.currentTime,.3);this.rain();this.next=this.context.currentTime+.1;this.step=0;
  this.timer=setInterval(()=>{if(!this.enabled)return;const now=this.context.currentTime;while(this.next<now+.2){const beat=this.engine.step(this.step++,this.next)||.7;this.next+=beat/2}this.rainGain?.gain.setTargetAtTime((this.state().room?.025:.08)+(this.state().a?.rain||0)*(this.state().room?.025:.13),now,.8)},70);
 }
 note(freq,when,duration,amplitude,type='sine',pan=0,detune=0){
  const ac=this.context;if(!this.enabled||!ac)return;const osc=ac.createOscillator(),gain=ac.createGain(),p=ac.createStereoPanner();osc.type=['sine','triangle','square','sawtooth'].includes(type)?type:'sine';osc.frequency.value=freq;osc.detune.value=detune||0;p.pan.value=pan||0;
  gain.gain.setValueAtTime(0,when);gain.gain.linearRampToValueAtTime(Math.min(.055,amplitude||.02),when+.015);gain.gain.exponentialRampToValueAtTime(.0001,when+duration+.12);
  osc.connect(gain);gain.connect(p);p.connect(this.master);osc.start(when);osc.stop(when+duration+.15);osc.onended=()=>{osc.disconnect();gain.disconnect();p.disconnect()};this.notes++;
 }
 kick(when,amp){const ac=this.context;if(!this.enabled)return;const o=ac.createOscillator(),g=ac.createGain();o.frequency.setValueAtTime(110,when);o.frequency.exponentialRampToValueAtTime(43,when+.16);g.gain.setValueAtTime(Math.min(.14,amp),when);g.gain.exponentialRampToValueAtTime(.0001,when+.19);o.connect(g);g.connect(this.master);o.start(when);o.stop(when+.21);o.onended=()=>{o.disconnect();g.disconnect()}}
 noise(when,d=.08,amp=.02){const ac=this.context;if(!this.enabled)return;const b=ac.createBuffer(1,Math.ceil(ac.sampleRate*d),ac.sampleRate),x=b.getChannelData(0);for(let i=0;i<x.length;i++)x[i]=(Math.random()*2-1)*(1-i/x.length);const src=ac.createBufferSource(),g=ac.createGain(),filter=ac.createBiquadFilter();src.buffer=b;filter.type='highpass';filter.frequency.value=2400;g.gain.value=amp;src.connect(filter);filter.connect(g);g.connect(this.master);src.start(when);src.onended=()=>{src.disconnect();filter.disconnect();g.disconnect()}}
 rain(){const ac=this.context,b=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate),x=b.getChannelData(0);let last=0;for(let i=0;i<x.length;i++){const n=Math.random()*2-1;last=.8*last+.2*n;x[i]=last*.45}const src=ac.createBufferSource(),filter=ac.createBiquadFilter(),g=ac.createGain();src.buffer=b;src.loop=true;filter.type='lowpass';filter.frequency.value=2200;g.gain.value=.13;src.connect(filter);filter.connect(g);g.connect(this.master);src.start();this.rainSource=src;this.rainGain=g;this.rainFilter=filter}
 setVolume(v){this.volume=Math.min(.4,Math.max(0,Number(v)||0));if(this.enabled)this.master?.gain.setTargetAtTime(this.volume,this.context.currentTime,.1)}
 stop(){this.enabled=false;clearInterval(this.timer);this.timer=null;if(this.context){this.master.gain.setTargetAtTime(0,this.context.currentTime,.05);setTimeout(()=>{if(!this.enabled)this.context.suspend()},220)}try{this.rainSource?.stop();this.rainSource?.disconnect();this.rainGain?.disconnect();this.rainFilter?.disconnect()}catch(_){}this.rainSource=null}
 cue(kind){if(!this.enabled)return;const t=this.context.currentTime;this.note(kind==='cast'?660:kind==='hit'?150:392,t,.11,.035,'sine')}
}
window.NeonSound=new Soundscape();
})();
