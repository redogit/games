'use strict';
(()=>{
const TAU=Math.PI*2;
class Renderer{
 constructor(canvas){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.assets=window.NeonVeilAssets;this.camera={x:5.5,y:8.5,yaw:0};this.last=0;this.frames=0;this.swingAt=0;this.reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;this.cachedSprites=new Map();this.props=new Map();this.depthBuffer=null;this.textures=new Map();this.lastPlayer=null;this.lastHurt=0;this.cwidth=0;this.cheight=0;
  this.assets.preload('shared');this.assets.preloadDistrict('rainmarket');
  new ResizeObserver(()=>this.paint(performance.now(),true)).observe(canvas.parentElement);
  const frame=t=>{if(!document.hidden&&(t-this.last>33||!this.frames)){this.last=t;this.paint(t)}requestAnimationFrame(frame)};requestAnimationFrame(frame);
 }
 spriteFor(p){const key=p.id+JSON.stringify([p.appearance,p.species,p.base_class,p.job_role,p.secondary_class,p.skills]);if(this.cachedSprites.has(key))return this.cachedSprites.get(key);const c=document.createElement('canvas');c.width=180;c.height=300;window.NeonAppearance.draw(c.getContext('2d'),p.appearance||NeonAppearance.defaults(),180,300,p);this.cachedSprites.set(key,c);if(this.cachedSprites.size>40)this.cachedSprites.delete(this.cachedSprites.keys().next().value);return c}
 propFor(kind){
  if(this.props.has(kind))return this.props.get(kind);
  const cv=document.createElement('canvas');cv.width=128;cv.height=192;const c=cv.getContext('2d');
  if(kind==='tree'){
   c.strokeStyle='#48584d';c.lineWidth=10;c.beginPath();c.moveTo(64,184);c.lineTo(61,78);c.lineTo(35,48);c.moveTo(62,107);c.lineTo(97,59);c.stroke();
   for(let i=0;i<9;i++){c.fillStyle=['#345e50','#426f5a','#527e60'][i%3];c.beginPath();c.ellipse(35+(i%3)*27,34+Math.floor(i/3)*26,27,25,0,0,TAU);c.fill()}
   c.fillStyle='#a1b898';for(let i=0;i<12;i++){c.beginPath();c.arc(22+(i*17)%88,24+(i*23)%81,2,0,TAU);c.fill()}
  }else if(kind==='lamp'||kind==='lamp-off'){
   c.fillStyle='#354651';c.fillRect(60,45,8,139);c.fillRect(44,180,40,8);c.fillStyle='#242f3c';c.fillRect(43,24,42,39);c.fillStyle=kind==='lamp'?'#b8dba9':'#374943';c.fillRect(49,31,30,22);
   if(kind==='lamp'){const g=c.createRadialGradient(64,42,3,64,42,42);g.addColorStop(0,'#b7f6ba4c');g.addColorStop(1,'#b7f6ba00');c.fillStyle=g;c.fillRect(20,0,88,100);}
  }else if(kind==='bench'){
   c.fillStyle='#5f5b4f';c.fillRect(8,118,112,15);c.fillRect(14,81,99,24);c.fillStyle='#364952';c.fillRect(18,102,8,66);c.fillRect(100,102,8,66);c.fillStyle='#999378';c.fillRect(15,84,96,3);
  }else if(kind==='crate'){
   c.fillStyle='#3c5158';c.fillRect(15,105,100,77);c.fillStyle='#7b836b';c.fillRect(20,109,90,4);c.fillRect(20,174,90,4);c.strokeStyle='#263f47';c.lineWidth=6;c.strokeRect(21,115,84,55);c.fillStyle='#b2b88d';c.fillRect(47,129,34,16);
  }else if(kind==='shop'||kind==='shop-closed'){
   c.fillStyle='#293c48';c.fillRect(9,55,110,128);c.fillStyle='#bcaa80';c.fillRect(4,97,120,12);c.fillStyle='#19333b';c.fillRect(12,10,104,50);c.strokeStyle='#abceb3';c.lineWidth=3;c.strokeRect(12,10,104,50);c.fillStyle='#d2e8c7';c.font='bold 16px system-ui';c.textAlign='center';c.fillText(kind==='shop-closed'?'CLOSED':'EXCHANGE',64,40);for(let i=0;i<4;i++){c.fillStyle=['#b59065','#66837a','#93a28a','#877a9c'][i];c.fillRect(15+i*26,68,20,26)}
  }else if(kind.startsWith('transformer-')){
   const damaged=kind==='transformer-outage'||kind==='transformer-backup';
   c.fillStyle='#243943';c.fillRect(12,38,104,145);c.strokeStyle='#8aa6ad';c.lineWidth=4;c.strokeRect(14,40,100,139);
   for(let i=0;i<5;i++){c.fillStyle=damaged?'#715044':'#47616a';c.fillRect(23+i*18,64,9,87)}
   c.fillStyle=kind==='transformer-outage'?'#eab277':kind==='transformer-warning'?'#dcc887':'#a2cfb1';c.fillRect(29,45,70,12);
   c.fillStyle='#e6e9d8';c.font='bold 12px system-ui';c.textAlign='center';c.fillText(damaged?'MAINTENANCE':'CIVIC GRID',64,169);
   if(damaged){c.strokeStyle='#d8af82';c.lineWidth=4;c.beginPath();c.moveTo(24,90);c.lineTo(103,140);c.stroke()}
  }else if(kind==='landmark'){
   c.fillStyle='#566974';c.fillRect(44,98,40,83);c.fillStyle='#304952';c.fillRect(14,27,100,77);c.strokeStyle='#87aaac';c.lineWidth=3;c.strokeRect(14,27,100,77);c.fillStyle='#b9d2c3';for(let i=0;i<4;i++)c.fillRect(27,45+i*12,74-i*8,4);
  }
  this.props.set(kind,cv);return cv;
 }
 texture(seed){
  const key=seed%5;if(this.textures.has(key))return this.textures.get(key);
  const cv=document.createElement('canvas');cv.width=256;cv.height=256;const c=cv.getContext('2d');const palettes=[['#172f3b','#315768','#68c8bd'],['#202a3a','#475366','#8aadd0'],['#283239','#485957','#c1a86d'],['#212839','#3f4865','#9690c4'],['#132b32','#2c4a53','#61a9b5']];const p=palettes[key];c.fillStyle=p[0];c.fillRect(0,0,256,256);
  c.fillStyle='#070f15';c.fillRect(0,0,4,256);c.fillRect(0,253,256,3);
  for(let y=16;y<210;y+=48)for(let x=18;x<248;x+=50){c.fillStyle=p[1];c.fillRect(x,y,30,30);c.fillStyle=((x+y+seed)%7<4)?p[2]:'#11212b';c.globalAlpha=.52;c.fillRect(x+2,y+2,26,26);c.globalAlpha=1;c.fillStyle='#0b151e';c.fillRect(x+14,y,2,30);c.fillRect(x,y+14,30,2)}
  c.fillStyle='#0a151f';c.fillRect(0,215,256,6);c.fillStyle=p[2];c.globalAlpha=.42;c.fillRect(0,222,256,2);c.globalAlpha=1;c.strokeStyle='#8bafb21c';for(let i=0;i<18;i++){c.beginPath();c.moveTo((i*17)%256,0);c.lineTo((i*17)%256-12,256);c.stroke()}
  this.textures.set(key,cv);return cv;
 }
 ray(grid,x,y,angle,max=35){
  const dx=Math.cos(angle),dy=Math.sin(angle);let mx=Math.floor(x),my=Math.floor(y);const ddx=Math.abs(1/dx),ddy=Math.abs(1/dy),sx=dx<0?-1:1,sy=dy<0?-1:1;let sidex=(dx<0?x-mx:mx+1-x)*ddx,sidey=(dy<0?y-my:my+1-y)*ddy,side=0,d=max;
  for(let n=0;n<80;n++){
   if(sidex<sidey){sidex+=ddx;mx+=sx;side=0}else{sidey+=ddy;my+=sy;side=1}
   if(my<0||my>=grid.length||mx<0||mx>=grid[0].length)break;
   d=side===0?sidex-ddx:sidey-ddy;if(d>max)break;
   if(grid[my][mx]==='#'){let u=side===0?y+d*dy:x+d*dx;u-=Math.floor(u);if((side===0&&dx>0)||(side===1&&dy<0))u=1-u;return {dist:Math.max(.04,d),side,u,x:mx,y:my}}
  }
  return {dist:max,side,u:0,x:mx,y:my};
 }
 paint(t,force=false){
  const cv=this.canvas,c=this.ctx;if(!c)return;const rect=cv.getBoundingClientRect();const scale=Math.min(devicePixelRatio||1,1.5,1280/Math.max(1,rect.width));const w=Math.max(1,Math.round(rect.width*scale)),h=Math.max(1,Math.round(rect.height*scale));
  if(w!==cv.width||h!==cv.height){cv.width=w;cv.height=h}
  if(h<2||w<2)return;this.frames++;
  const S=window.NeonAPI?.state,player=S?.player,world=S?.world,atm=world?.atmosphere||{rain:.6,weather:'rain',power:true},input=window.NeonInput;
  if(player){
   const ack=input?.motionAck,point=ack&&ack.revision>(world.revision||0)?ack:player;
   if(this.lastPlayer!==player.id||Math.hypot(point.x-this.camera.x,point.y-this.camera.y)>3){this.camera.x=point.x;this.camera.y=point.y;this.lastPlayer=player.id}
   this.camera.x+=(point.x-this.camera.x)*.48;this.camera.y+=(point.y-this.camera.y)*.48;this.camera.yaw=input?.yaw??player.yaw;
  }
  const cam=this.camera,yaw=cam.yaw,room=world?.buildings?.find(b=>cam.x>b.x1+1&&cam.x<b.x2&&cam.y>b.y1+1&&cam.y<b.y2),region=world?.regions?.find(r=>cam.x>=r.x1&&cam.x<r.x2&&cam.y>=r.y1&&cam.y<r.y2),green=region?.terrain==='garden'||region?.terrain==='marsh',power=window.NeonPower.poweredAt(world,cam.x,cam.y),sky=c.createLinearGradient(0,0,0,h*.6);sky.addColorStop(0,power?'#102338':'#090f20');sky.addColorStop(1,power?'#35505b':'#252b3a');c.fillStyle=sky;c.fillRect(0,0,w,h);
  // Skyline moves with heading, not with the player's importance to world time.
  const horizon=h*.49;for(let i=-2;i<22;i++){const bw=w/14,x=((i*w/14-yaw*w*.09)% (w*1.5)+w*1.5)%(w*1.5)-w*.25,top=h*.08+((i*i*13+187)%170)/400*h;c.fillStyle=i%2?'#132636':'#182e3d';c.fillRect(x,top,bw*.86,horizon-top);if(power){c.fillStyle='#6db8af44';for(let j=0;j<4;j++)c.fillRect(x+bw*.18+j*bw*.13,top+10,bw*.03,Math.max(6,h*.07))}}
  const floor=c.createLinearGradient(0,horizon,0,h);floor.addColorStop(0,'#1d303b');floor.addColorStop(.2,'#182b33');floor.addColorStop(1,'#09131c');c.fillStyle=floor;c.fillRect(0,horizon,w,h-horizon);
  // Perspective wet paving. Bounded rows, no full-frame per-pixel readback.
  c.lineWidth=1;for(let j=1;j<20;j++){const z=j/20,y=horizon+(h-horizon)*z*z;c.strokeStyle=`rgba(128,171,175,${.04+z*.055})`;c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke()}
  c.save();c.globalAlpha=.12;for(let i=0;i<12;i++){const x=(i*.19*w+Math.sin(yaw+i)*w*.3)%w;c.fillStyle=i%3?'#5a979c':'#9a7962';c.beginPath();c.moveTo(x,horizon);c.lineTo(x+w*.012,horizon);c.lineTo(x+w*.085,h);c.lineTo(x-w*.08,h);c.closePath();c.fill()}c.restore();
  if(!world){this.rain(t,c,w,h,atm);return}
  if(room){c.fillStyle=power?'#34332e':'#1b2227';c.fillRect(0,0,w,horizon);c.strokeStyle='#aba58c20';for(let i=1;i<9;i++){c.beginPath();c.moveTo(w/2,horizon);c.lineTo(i*w/8,0);c.stroke()}c.fillStyle=power?'#dacb9b99':'#67837b55';c.fillRect(w*.39,h*.08,w*.22,h*.015)}
  else if(green){c.fillStyle='#597c531e';c.fillRect(0,horizon,w,h-horizon)}
  const fov=Math.PI/2.8,focal=w/(2*Math.tan(fov/2)),count=Math.min(640,Math.ceil(w/2)),strip=w/count;
  if(!this.depthBuffer||this.depthBuffer.length!==count)this.depthBuffer=new Float32Array(count);const z=this.depthBuffer;
  for(let i=0;i<count;i++){
   const offset=Math.atan((i/count-.5)*2*Math.tan(fov/2)),r=this.ray(world.grid,cam.x,cam.y,yaw+offset),d=Math.max(.07,r.dist*Math.cos(offset));z[i]=d;
   const wallH=Math.min(h*15,focal*1.85/d),bottom=horizon+focal*.76/d,top=bottom-wallH;
   const texture=this.texture(room?2:green?4:(Math.abs(r.x*7+r.y*11))%5);
   c.drawImage(texture,Math.floor(r.u*255),0,1,256,i*strip,top,strip+1,wallH);
   c.fillStyle=`rgba(3,10,19,${Math.min(.84,d/26+(r.side?.12:0)+(power?0:.13))})`;c.fillRect(i*strip,top,strip+1,wallH);
   // Low neon ledge and muted reflection on the wet street.
   if((r.x+r.y)%4===0&&power){const sy=bottom-wallH*.18;c.fillStyle='#64e1c455';c.fillRect(i*strip,sy,strip+1,Math.max(1,wallH*.012));if(bottom<h){c.fillStyle='#418f9214';c.fillRect(i*strip,bottom,strip+1,Math.min(h-bottom,wallH*.24))}}
  }
  const objects=[];
  const push=(o,kind,size=1)=>objects.push({...o,drawKind:kind,size});
  for(const n of world.npcs)if(n.hp>0)push(n,'npc',n.role==='boss'?1.9:1.0);
  for(const f of world.features)push(f,f.kind,f.kind==='contact'?1:1.15);
  for(const d of world.decorations||[])if(Math.hypot(d.x-cam.x,d.y-cam.y)<24)push(d,'decoration',d.kind==='tree'?2.0:d.kind==='lamp'?1.6:d.size);
  for(const p of S.players)push(p,'player',1);
  for(const b of S.corpses)push(b,'corpse',.45);
  for(const item of S.items)if(item.holder_type==='world')push(item,'item',.35);
  const sprites=[];for(const o of objects){const dx=o.x-cam.x,dy=o.y-cam.y,depth=dx*Math.cos(yaw)+dy*Math.sin(yaw),lat=-dx*Math.sin(yaw)+dy*Math.cos(yaw);if(depth<.15||depth>27)continue;const sx=w*.5+lat/depth*focal,height=focal*o.size/depth,bottom=horizon+focal*.72/depth,width=height*(o.drawKind==='contact'||o.drawKind==='player'?.60:.73);if(sx+width/2<0||sx-width/2>w)continue;sprites.push({o,depth,sx,height,width,bottom})}
  sprites.sort((a,b)=>b.depth-a.depth);
  for(const s of sprites){const {o,depth,sx,height,width,bottom}=s;const left=sx-width/2,top=bottom-height;let img=null;
   if(o.drawKind==='player')img=this.spriteFor(o);
   else if(o.drawKind==='npc')img=this.assets.image('enemy.'+o.kind);
   else if(o.drawKind==='contact')img=this.assets.image('runner.cipher');
   else if(o.id==='grid-terminal')img=this.propFor(window.NeonPower.fixtureKind(world,o));
   else if(o.drawKind==='terminal')img=this.assets.image('prop.terminal.locked');
   else if(o.drawKind==='shelter')img=this.assets.image('prop.exit');
   else if(o.drawKind==='decoration')img=this.propFor(window.NeonPower.fixtureKind(world,o));
   else if(o.drawKind==='shop'||o.drawKind==='landmark')img=this.propFor(window.NeonPower.fixtureKind(world,o));
   else if(o.drawKind==='item')img=this.assets.image(o.kind==='salvage'?'prop.relic':'prop.key');
   else if(o.drawKind==='hazard')img=this.assets.image('prop.well');
   c.save();c.beginPath();for(let i=Math.max(0,Math.floor(left/strip));i<Math.min(count,Math.ceil((left+width)/strip));i++)if(depth<z[i]+.04)c.rect(i*strip,Math.max(0,top-30),strip+1,height+40);c.clip();
   c.globalAlpha=Math.max(.25,1-depth/34);c.fillStyle='#040c12aa';c.beginPath();c.ellipse(sx,bottom-2,width*.42,height*.05,0,0,TAU);c.fill();
   if(img)c.drawImage(img,left,top,width,height);
   else{c.fillStyle=o.drawKind==='corpse'?'#56727c':'#59998f';c.fillRect(left,top,width,height)}
   if(['terminal','contact','shelter','shop','landmark'].includes(o.drawKind)&&depth<10){c.fillStyle=o.drawKind==='shelter'?'#f4d596':'#8bf0d4';c.font=`600 ${Math.max(9,Math.min(14,height*.12))}px system-ui`;c.textAlign='center';c.fillText(o.drawKind==='contact'?'MOTH':o.drawKind==='shelter'?'SHELTER':o.id==='grid-terminal'?(world.power_grid?.repair_required?'GRID · MAINTENANCE':'CIVIC GRID'):o.drawKind==='terminal'?'RELAY':o.name.toUpperCase(),sx,top-5)}
   if(o.drawKind==='hazard'){c.fillStyle='#ffd47c';c.font=`600 ${Math.max(10,Math.min(14,height*.12))}px system-ui`;c.textAlign='center';c.fillText(window.NeonPower.hazardLabel(world,o.id),sx,top-6)}
   c.restore();
  }
  if(!room)this.rain(t,c,w,h,atm);
  // Consistent first-person utility blade; no firearms. Small action-only motion.
  if(player?.alive){const swing=!this.reduced?Math.max(0,1-(t-this.swingAt)/280):0;const bend=Math.sin(swing*Math.PI);c.save();c.translate(w*.82-bend*w*.18,h*.95);c.rotate(-.29-bend*.9);
   c.fillStyle=player.appearance.coat;c.beginPath();c.moveTo(-w*.07,0);c.lineTo(w*.07,0);c.lineTo(w*.04,-h*.11);c.lineTo(-w*.04,-h*.10);c.closePath();c.fill();c.fillStyle=player.appearance.skin;c.fillRect(-w*.025,-h*.15,w*.05,h*.08);
   c.fillStyle='#263740';c.fillRect(-w*.02,-h*.19,w*.04,h*.09);c.fillStyle='#bad4d9';c.beginPath();c.moveTo(-w*.014,-h*.18);c.lineTo(-w*.014,-h*.4);c.lineTo(0,-h*.46);c.lineTo(w*.014,-h*.39);c.lineTo(w*.014,-h*.18);c.closePath();c.fill();c.strokeStyle=player.appearance.accent;c.lineWidth=1;c.beginPath();c.moveTo(0,-h*.21);c.lineTo(0,-h*.4);c.stroke();c.restore()}
  const vignette=c.createRadialGradient(w*.5,h*.45,h*.15,w*.5,h*.5,Math.max(w,h)*.65);vignette.addColorStop(0,'#02070d00');vignette.addColorStop(1,'#02070d9c');c.fillStyle=vignette;c.fillRect(0,0,w,h);
  if(player&&!player.alive){c.fillStyle='#0b121c8c';c.fillRect(0,0,w,h)}
 }
 rain(t,c,w,h,a){const still=this.reduced||document.querySelector('dialog[open]');const time=still?0:t*.001;const count=Math.floor(45+(a.rain||0)*80);c.lineWidth=.7;c.strokeStyle=a.weather==='storm'?'#b4d1e359':'#9ecdd637';c.beginPath();for(let i=0;i<count;i++){const x=((i*137.9+time*31)%(w+80))-40,y=((i*71.7+time*(230+i%70))%(h+40))-20;c.moveTo(x,y);c.lineTo(x-3-a.rain*2,y+9+a.rain*7)}c.stroke();}
 swing(){this.swingAt=performance.now()}
}
window.NeonRendererClass=Renderer;
})();
