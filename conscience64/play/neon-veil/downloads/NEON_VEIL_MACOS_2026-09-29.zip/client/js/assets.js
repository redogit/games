"use strict";
(()=>{
class NeonAssetManager{
  constructor(url="assets/manifest.json"){
    this.url=url;
    this.manifest=null;
    this.images=new Map();
    this.promises=new Map();
    this.failed=new Set();
    this.ready=false;
    this._init=this._loadManifest();
  }
  async _loadManifest(){
    try{
      const res=await fetch(this.url,{cache:"no-cache"});
      if(!res.ok)throw new Error(`asset manifest ${res.status}`);
      this.manifest=await res.json();
      this.ready=true;
      return this.manifest;
    }catch(err){
      console.warn("Asset manifest unavailable; renderer fallbacks remain active.",err);
      this.manifest={version:"fallback",base:"assets",assets:{},groups:{}};
      return this.manifest;
    }
  }
  async whenReady(){return this._init}
  record(id){return this.manifest?.assets?.[id]||null}
  src(id){
    const r=this.record(id);if(!r)return null;
    return `${this.manifest.base||"assets"}/${r.src}`;
  }
  image(id){return this.images.get(id)||null}
  has(id){return this.images.has(id)}
  async load(id){
    await this._init;
    if(this.images.has(id))return this.images.get(id);
    if(this.failed.has(id))return null;
    if(this.promises.has(id))return this.promises.get(id);
    const src=this.src(id);
    if(!src){this.failed.add(id);return null}
    const p=new Promise(resolve=>{
      const img=new Image();
      img.decoding="async";
      img.onload=async()=>{
        try{if(img.decode)await img.decode()}catch(_){}
        this.images.set(id,img);this.promises.delete(id);resolve(img);
        dispatchEvent(new CustomEvent("neon-assets-changed",{detail:{id}}));
      };
      img.onerror=()=>{this.failed.add(id);this.promises.delete(id);resolve(null)};
      img.src=src;
    });
    this.promises.set(id,p);return p;
  }
  async preload(ids){
    if(typeof ids==="string"){
      await this._init;
      ids=this.manifest.groups?.[ids]||[ids];
    }
    return Promise.all([...new Set(ids||[])].map(id=>this.load(id)));
  }
  async preloadDistrict(slug){
    await this._init;
    return this.preload(this.manifest.groups?.[`district.${slug}`]||[]);
  }
  status(){
    return {
      version:this.manifest?.version||"loading",
      loaded:this.images.size,
      failed:[...this.failed],
      pending:this.promises.size
    };
  }
}
window.NeonVeilAssets=new NeonAssetManager();
})();
