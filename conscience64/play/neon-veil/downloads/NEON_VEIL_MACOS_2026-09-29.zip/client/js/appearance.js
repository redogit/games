/* Adapted from the recovered Player Creator v15 shape schema and articulated
 * modelGeometry ratios. Neutral game defaults; no source identity, references,
 * media, private links or learner records are imported. See docs/PROVENANCE.md. */
'use strict';
(()=>{
const shapeKeys=['height','head','headWidth','headDepth','jaw','neck','shoulders','chest','depth','waist','hips','torso','arms','armThickness','legs','legThickness','hands','feet','gluteDepth','calf'];
const defaults=()=>({skin:'#b98262',hair:'#19212b',eyes:'#82bba6',coat:'#253142',accent:'#70e0c7',hair_style:'short',presentation:'neutral',pronouns:'',shape:Object.fromEntries(shapeKeys.map(k=>[k,1]))});
function importTemplate(input){
 if(!input||typeof input!=='object')throw Error('Choose an appearance or Player Creator JSON file.');
 const source=input.appearance||input, out=defaults();
 const shape=source.shape||input.shape;
 if(!shape||typeof shape!=='object')throw Error('This file has no compatible shape parameters.');
 for(const k of shapeKeys)if(k in shape){const n=shape[k];if(typeof n!=='number'||!Number.isFinite(n)||n<.6||n>1.5)throw Error(`Shape ${k} must be between 0.6 and 1.5.`);out.shape[k]=n}
 for(const k of ['skin','hair','eyes','coat','accent'])if(typeof source[k]==='string'&&/^#[0-9a-f]{6}$/i.test(source[k]))out[k]=source[k];
 if(['short','crop','curls','long','locs','bald'].includes(source.hair_style))out.hair_style=source.hair_style;
 if(['neutral','soft','angular'].includes(source.presentation))out.presentation=source.presentation;
 if(typeof source.pronouns==='string'&&source.pronouns.length<=32)out.pronouns=source.pronouns.replace(/[<>\x00-\x1f]/g,'');
 return out;
}
function geometry(appearance){
 const sh=appearance.shape,H=1.68*sh.height,p=(x,y,z=0)=>({x,y,z});
 const torso=sh.torso,hipY=H*.47,waistY=hipY+H*.13*torso,chestY=hipY+H*.26*torso;
 const g={pelvis:p(0,hipY),waist:p(0,waistY),chest:p(0,chestY),neck:p(0,chestY+H*.125),head:p(0,chestY+H*.20)};
 for(const [side,sign] of [['L',-1],['R',1]]){
  const sx=sign*.24*sh.shoulders,sy=chestY+.04*H;
  g['shoulder'+side]=p(sx,sy);g['elbow'+side]=p(sx+sign*.08,sy-.28*sh.arms);g['wrist'+side]=p(sx+sign*.04,sy-.51*sh.arms);g['hand'+side]=p(sx+sign*.04,sy-.59*sh.arms);
  g['hip'+side]=p(sign*.145*sh.hips,hipY);g['knee'+side]=p(sign*.145*sh.hips,hipY-.37*sh.legs);g['ankle'+side]=p(sign*.155*sh.hips,hipY-.72*sh.legs);g['foot'+side]=p(sign*.165*sh.hips,hipY-.75*sh.legs,.18*sh.feet);
 }
 return g;
}
function draw(ctx,a,w,h,build={}){
 const sh=a.shape||defaults().shape,g=geometry(a),s=Math.min(w/1.35,h/2.72),ox=w*.5,oy=h*.94;
 const P=p=>({x:ox+p.x*s,y:oy-p.y*s}),ellipse=(p,rx,ry,color)=>{p=P(p);ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(p.x,p.y,rx*s,ry*s,0,0,Math.PI*2);ctx.fill()},limb=(a,b,r,col)=>{a=P(a);b=P(b);ctx.strokeStyle=col;ctx.lineWidth=r*s*2;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()};
 ctx.clearRect(0,0,w,h);ctx.save();ctx.shadowColor='rgba(0,0,0,.25)';ctx.shadowBlur=5;
 for(const side of ['L','R']){
  limb(g['hip'+side],g['knee'+side],.075*sh.legThickness,'#202736');limb(g['knee'+side],g['ankle'+side],.059*sh.calf,'#18212b');
  ellipse(g['foot'+side],.07*sh.feet,.038,'#111721');
 }
 // The silhouette remains clothed; body dimensions are appearance, never power.
 const pelvis=P(g.pelvis),waist=P(g.waist),chest=P(g.chest),neck=P(g.neck);
 const shoulder=.245*sh.shoulders*s,hip=.18*sh.hips*s,wa=.135*sh.waist*s,depth=.19*sh.chest*s;
 ctx.fillStyle=a.coat;ctx.beginPath();ctx.moveTo(neck.x-.08*s,neck.y);ctx.lineTo(chest.x-shoulder,chest.y-.08*s);ctx.lineTo(waist.x-wa,waist.y);ctx.lineTo(pelvis.x-hip,pelvis.y+.08*s);ctx.quadraticCurveTo(pelvis.x,pelvis.y+.10*sh.gluteDepth*s,pelvis.x+hip,pelvis.y+.08*s);ctx.lineTo(waist.x+wa,waist.y);ctx.lineTo(chest.x+shoulder,chest.y-.08*s);ctx.lineTo(neck.x+.08*s,neck.y);ctx.closePath();ctx.fill();
 ellipse(g.chest,.16*sh.chest,.145*sh.depth,a.coat);
 ctx.strokeStyle=a.accent;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(neck.x-.06*s,neck.y);ctx.lineTo(chest.x,chest.y+.13*s);ctx.lineTo(neck.x+.06*s,neck.y);ctx.stroke();
 for(const side of ['L','R']){limb(g['shoulder'+side],g['elbow'+side],.06*sh.armThickness,a.coat);limb(g['elbow'+side],g['wrist'+side],.05*sh.armThickness,a.coat);ellipse(g['hand'+side],.042*sh.hands,.058*sh.hands,a.skin)}
 limb(g.neck,g.head,.04*sh.neck,a.skin);
 const hd=P(g.head),rx=.105*sh.headWidth*sh.head*s,ry=.132*sh.head*s;
 ctx.fillStyle=a.skin;ctx.beginPath();ctx.moveTo(hd.x-rx,hd.y);ctx.bezierCurveTo(hd.x-rx,hd.y-ry*1.5,hd.x+rx,hd.y-ry*1.5,hd.x+rx,hd.y);ctx.bezierCurveTo(hd.x+rx*sh.jaw*.9,hd.y+ry,hd.x-rx*sh.jaw*.9,hd.y+ry,hd.x-rx,hd.y);ctx.fill();
 ctx.shadowBlur=0;ctx.fillStyle=a.hair;const hair=a.hair_style;
 if(hair!=='bald'){
  ctx.beginPath();ctx.ellipse(hd.x,hd.y-ry*.48,rx*1.10,ry*.65,0,Math.PI,Math.PI*2);ctx.lineTo(hd.x+rx,hd.y-ry*.1);ctx.lineTo(hd.x-rx,hd.y-ry*.2);ctx.closePath();ctx.fill();
  if(['long','locs'].includes(hair))for(const sign of [-1,1]){ctx.beginPath();ctx.ellipse(hd.x+sign*rx*.99,hd.y+ry*.2,rx*.30,ry*1.2,sign*.12,0,Math.PI*2);ctx.fill()}
  if(hair==='curls'||hair==='locs')for(let i=0;i<9;i++){ctx.beginPath();ctx.arc(hd.x+Math.cos(i*Math.PI/8+Math.PI)*rx,hd.y-ry*.15+Math.sin(i*Math.PI/8+Math.PI)*ry*.95,rx*.30,0,Math.PI*2);ctx.fill()}
 }
 const eyes=.12*rx;ctx.fillStyle=a.eyes;for(const sign of [-1,1]){ctx.beginPath();ctx.ellipse(hd.x+sign*rx*.4,hd.y-ry*.03,eyes,eyes*.8,0,0,Math.PI*2);ctx.fill()}
 ctx.strokeStyle='rgba(55,27,24,.5)';ctx.lineWidth=Math.max(1,s*.005);ctx.beginPath();ctx.moveTo(hd.x-rx*.18,hd.y+ry*.44);ctx.quadraticCurveTo(hd.x,hd.y+ry*.49,hd.x+rx*.18,hd.y+ry*.44);ctx.stroke();
 // Fabric seams, belt and an understated field-kit patch.
 ctx.strokeStyle='rgba(220,241,250,.20)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(chest.x,chest.y+.1*s);ctx.lineTo(waist.x,waist.y);ctx.stroke();
 ctx.fillStyle='#121c25';ctx.fillRect(waist.x-wa,waist.y-.015*s,wa*2,.032*s);ctx.fillStyle=a.accent;ctx.fillRect(waist.x-.018*s,waist.y-.019*s,.036*s,.042*s);

 // Species anatomy and occupation/class attire are separate from customizable skin/build.
 const species=build.species||'human',cl=build.base_class||'',job=build.job_role||'';
 ctx.lineCap='round';ctx.strokeStyle=a.accent;ctx.fillStyle=a.skin;ctx.lineWidth=Math.max(1,s*.012);
 if(species==='verdant'||species==='pelagic')for(const sign of [-1,1]){
  ctx.beginPath();ctx.moveTo(hd.x+sign*rx*.85,hd.y-ry*.25);ctx.lineTo(hd.x+sign*rx*1.85,hd.y-ry*.65);ctx.lineTo(hd.x+sign*rx*1.3,hd.y+ry*.35);ctx.closePath();ctx.fill();ctx.stroke();
 }
 if(species==='verdant')for(const sign of [-1,1]){ctx.beginPath();ctx.moveTo(hd.x+sign*rx*.65,hd.y-ry*.75);ctx.lineTo(hd.x+sign*rx*1.3,hd.y-ry*1.6);ctx.lineTo(hd.x+sign*rx*1.55,hd.y-ry*1.55);ctx.moveTo(hd.x+sign*rx,hd.y-ry*1.3);ctx.lineTo(hd.x+sign*rx*.7,hd.y-ry*1.55);ctx.stroke()}
 if(species==='cinderkin')for(const sign of [-1,1]){ctx.strokeStyle='#d0ae82';ctx.lineWidth=s*.035;ctx.beginPath();ctx.moveTo(hd.x+sign*rx*.65,hd.y-ry*.70);ctx.quadraticCurveTo(hd.x+sign*rx*1.4,hd.y-ry*1.65,hd.x+sign*rx*.95,hd.y-ry*1.85);ctx.stroke()}
 if(species==='stonekin'){ctx.fillStyle='#c1c4c088';ctx.beginPath();ctx.moveTo(hd.x-rx*.8,hd.y-ry*.6);ctx.lineTo(hd.x,hd.y-ry*.88);ctx.lineTo(hd.x+rx*.7,hd.y-ry*.55);ctx.lineTo(hd.x,hd.y-ry*.3);ctx.closePath();ctx.fill()}
 if(species==='synthborn'){ctx.strokeStyle=a.accent;ctx.lineWidth=s*.009;ctx.beginPath();ctx.moveTo(hd.x,hd.y-ry*.85);ctx.lineTo(hd.x,hd.y-ry*.1);ctx.moveTo(hd.x-rx*.7,hd.y+ry*.15);ctx.lineTo(hd.x-rx*.4,hd.y+ry*.5);ctx.moveTo(hd.x+rx*.7,hd.y+ry*.15);ctx.lineTo(hd.x+rx*.4,hd.y+ry*.5);ctx.stroke()}
 if(species==='pelagic'){ctx.fillStyle=a.accent;for(const sign of [-1,1])for(let i=0;i<3;i++)ctx.fillRect(hd.x+sign*rx*.72,hd.y+ry*(.17+i*.14),rx*.12,ry*.065)}
 ctx.strokeStyle=a.accent;ctx.lineWidth=s*.02;
 if(cl==='guardian'){ctx.fillStyle='#829caa';ctx.fillRect(chest.x-shoulder-.02*s,chest.y-.11*s,.11*s,.12*s);ctx.fillRect(chest.x+shoulder-.09*s,chest.y-.11*s,.11*s,.12*s)}
 if(cl==='duelist'||cl==='ranger'){ctx.beginPath();ctx.moveTo(chest.x-shoulder*.7,chest.y-.06*s);ctx.lineTo(pelvis.x+hip*.8,pelvis.y+.03*s);ctx.stroke()}
 if(cl==='scholar'||cl==='bard'){ctx.fillStyle=a.accent;ctx.globalAlpha=.65;ctx.fillRect(waist.x-.032*s,waist.y+.03*s,.064*s,.24*s);ctx.globalAlpha=1}
 if(cl==='physician'||job==='medic'){ctx.fillStyle='#f0d8ce';ctx.fillRect(chest.x+.09*s,chest.y,.04*s,.12*s);ctx.fillRect(chest.x+.05*s,chest.y+.04*s,.12*s,.04*s)}
 if(cl==='artificer'||job==='engineer'){ctx.fillStyle='#d3af69';ctx.fillRect(waist.x+.06*s,waist.y+.03*s,.12*s,.15*s);ctx.fillStyle='#222e39';ctx.fillRect(waist.x+.075*s,waist.y+.05*s,.09*s,.05*s)}
 if(cl==='envoy'||job==='broker'){ctx.fillStyle=a.accent;ctx.beginPath();ctx.moveTo(neck.x,neck.y+.02*s);ctx.lineTo(chest.x-.06*s,chest.y+.05*s);ctx.lineTo(chest.x,chest.y+.13*s);ctx.lineTo(chest.x+.06*s,chest.y+.05*s);ctx.closePath();ctx.fill()}
 if(job==='courier'){ctx.strokeStyle='#b7c5c2';ctx.lineWidth=s*.03;ctx.beginPath();ctx.moveTo(chest.x+shoulder*.7,chest.y-.04*s);ctx.lineTo(pelvis.x-hip*.6,pelvis.y);ctx.stroke();ctx.fillStyle='#304e51';ctx.fillRect(pelvis.x-hip-.05*s,pelvis.y-.06*s,.14*s,.15*s)}
 if(job==='cook'){ctx.fillStyle='#b9aaa088';ctx.fillRect(waist.x-wa*.9,waist.y-.06*s,wa*1.8,.24*s)}
 if(job==='archivist'){ctx.strokeStyle=a.accent;ctx.lineWidth=s*.012;ctx.beginPath();ctx.arc(hd.x-rx*.4,hd.y-ry*.04,rx*.3,0,Math.PI*2);ctx.stroke()}
 if(job==='ecologist'){ctx.fillStyle='#8fbd83';for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(waist.x+(.04+i*.045)*s,waist.y+.085*s,.026*s,.045*s,.4,0,Math.PI*2);ctx.fill()}}
 if(job==='performer'){ctx.strokeStyle='#debf92';ctx.lineWidth=s*.02;ctx.strokeRect(pelvis.x+.05*s,pelvis.y-.06*s,.14*s,.10*s)}
 const marks=Math.min(5,Math.floor(Object.values(build.skills||{}).reduce((n,x)=>n+x,0)/2));ctx.fillStyle=a.accent;for(let i=0;i<marks;i++)ctx.fillRect(chest.x-.09*s,chest.y+(.06+i*.025)*s,.05*s,.012*s);
 if(build.secondary_class){ctx.strokeStyle='#e9dbad';ctx.lineWidth=s*.008;ctx.strokeRect(chest.x-.13*s,chest.y+.04*s,.07*s,.09*s)}
 ctx.restore();
}
window.NeonAppearance=Object.freeze({shapeKeys:Object.freeze(shapeKeys),defaults,importTemplate,geometry,draw});
})();
