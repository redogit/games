"use strict";
window.createNeonVeilMusilanguage=function createNeonVeilMusilanguage(h){
  const engine=Object.freeze({
    version:"neon-veil-musilanguage/0.22",
    encode(){
      const sem=h.worldSemantics(),c=h.campaign(),j=h.ensureJob(),state=h.getState();
      const layer=state?.mode||"street";
      const density=Math.min(1,(sem?.danger||0)*.65+(c?.heat||0)*.045+(j?.complete?-.12:.08));
      const transpose=layer==="matrix"?12:layer==="astral"?7:0;
      return {layer,density,transpose,profile:sem?.profile||"dark-ambient",bpm:sem?.bpm||82,motif:h.motifForCurrent()};
    },
    step(step,time){
      const state=h.getState();
      if(!state?.music)return;
      const m=this.encode(),motif=m.motif,idx=step%motif.length,n=motif[idx]+m.transpose,root=motif[0]+m.transpose;
      const spb=60/m.bpm,eighth=spb/2;
      const active=((state.music.rhythm>>(step%8))&1)!==0;
      const strong=step%Math.max(1,h.beatCycle())===0;
      const type=m.layer==="matrix"?"square":m.layer==="astral"?"sine":h.musicType();
      if(strong)h.kick(time,.06+.055*m.density);
      if(step%2===1)h.noiseHit(time,.045,.01+.02*m.density,m.layer!=="astral");
      if(active){
        h.synthNote(h.midiHz(n),time,Math.min(.22,eighth*.72),.018+.025*m.density,type,(idx%2?.16:-.16));
        if(step%2===0)h.synthNote(h.midiHz(root-24),time,Math.min(.28,eighth*.9),.022+.018*m.density,m.layer==="matrix"?"square":"sine",0);
        if(step%4===0){
          h.synthNote(h.midiHz(root),time+.012,Math.min(.45,eighth*1.7),.009+.012*m.density,"sine",-0.24,-5);
          h.synthNote(h.midiHz(root+7),time+.018,Math.min(.45,eighth*1.7),.008+.010*m.density,"sine",0.24,5);
        }
      }
      return spb;
    }
  });
  return engine;
};

window.NEON_VEIL_MUSILANGUAGE=Object.freeze({
  package:"neon-veil/musilanguage",
  version:"0.22",
  carriers:Object.freeze(["WorldSemantics","campaign","street","matrix","astral","rhythm","motif"]),
  contract:Object.freeze({
    remoteDependencies:0,
    evidenceTransfer:"DENY",
    source:"local game state",
    output:"WebAudio schedule"
  }),
  create:window.createNeonVeilMusilanguage
});
