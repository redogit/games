'use strict';
(async()=>{
const Catalog=await window.NeonCatalogReady;
const $=id=>document.getElementById(id),api=window.NeonAPI,A=window.NeonAppearance;
const renderer=new window.NeonRendererClass($('worldCanvas'));window.NeonRenderer=renderer;
const input=new window.NeonInputClass($('worldCanvas'),api);window.NeonInput=input;
let appearance=A.defaults(),templateId=null,creatorOffered=false,deathShown=null,lastAnnounce=0,announceTimer,kitRevision=-1;
let prefs={volume:.14,reduced:matchMedia('(prefers-reduced-motion: reduce)').matches,sensitivity:1,keys:{...NEON_DEFAULT_KEYS}};
try{const p=JSON.parse(localStorage.getItem('neon-veil/preferences/029')||'null');if(p){prefs.volume=Math.min(.4,Math.max(0,Number(p.volume)||0));prefs.reduced=!!p.reduced;prefs.sensitivity=Math.min(2,Math.max(.5,Number(p.sensitivity)||1));if(p.keys)for(const k of Object.keys(NEON_DEFAULT_KEYS))if(typeof p.keys[k]==='string'&&p.keys[k].length===1&&p.keys[k]!=='\t')prefs.keys[k]=p.keys[k]}}catch(_){}
function savePrefs(){try{localStorage.setItem('neon-veil/preferences/029',JSON.stringify(prefs))}catch(_){}renderer.reduced=prefs.reduced;input.sensitivity=prefs.sensitivity;input.map={...prefs.keys};NeonSound.setVolume(prefs.volume)}
savePrefs();$('motionSetting').checked=prefs.reduced;$('volumeSetting').value=prefs.volume;$('sensitivitySetting').value=prefs.sensitivity;
function announce(text){$('announcement').textContent=text;clearTimeout(announceTimer);announceTimer=setTimeout(()=>$('announcement').textContent='',8500)}
function openDialog(id){input.clear();const d=$(id);if(!d.open){d.returnFocus=document.activeElement;d.showModal()}d.querySelector('[tabindex="-1"]')?.focus()}
function closeDialog(d){input.clear();d.close()}
for(const d of document.querySelectorAll('dialog')){
 d.querySelector('[data-close]')?.addEventListener('click',()=>closeDialog(d));
 d.addEventListener('close',()=>{
  // Native dialog close is queued. Never steal focus or clear fresh movement
  // after the player has already focused the world or a different dialog.
  if(document.querySelector('dialog[open]'))return;
  const focused=document.activeElement;
  if(focused===document.body||focused===d||d.contains(focused)){
   const opener=d.returnFocus;
   (opener?.isConnected&&!opener.closest('dialog:not([open])')?opener:$('worldCanvas')).focus({preventScroll:true});
  }
 });
 d.addEventListener('cancel',()=>input.clear());
}
$('helpButton').onclick=()=>openDialog('help');$('kitButton').onclick=()=>{renderKit();openDialog('fieldKit')};
const creator=new window.NeonCreatorClass(Catalog,api,{announce,open:openDialog,clear:()=>input.clear()});
function showCreator(template=null){creator.open(template)}
function closeOthers(){for(const d of document.querySelectorAll('dialog[open]'))d.close();input.clear()}
const progression=new window.NeonProgressionClass(Catalog,api,{open:openDialog,act,announce});
function remaining(body){return Math.max(0,body.expires_at-(api.state?.world.time||0))}
function formatTime(n){n=Math.max(0,Math.ceil(n));return String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0')}
function target(){
 const S=api.state,p=S?.player;if(!p?.alive)return null;const vals=[];
 for(const f of S.world.features)vals.push({...f,category:'feature'});
 for(const i of S.items)if(i.x!=null)vals.push({...i,category:'item'});
 for(const p of S.players)vals.push({...p,category:'player'});
 for(const n of S.world.npcs)if(n.hp>0)vals.push({...n,category:'enemy'});
 let best=null;
 for(const x of vals){const dx=x.x-p.x,dy=x.y-p.y,d=Math.hypot(dx,dy),ang=Math.atan2(Math.sin(Math.atan2(dy,dx)-input.yaw),Math.cos(Math.atan2(dy,dx)-input.yaw));if(d>2.3||Math.abs(ang)>.85)continue;const score=d+Math.abs(ang);if(!best||score<best.score)best={...x,score,distance:d}}
 return best;
}
async function act(op,args={},keepOpen=false){
 if(op!=='select'&&!api.state?.player?.alive){showCreator();return}
 try{if(op==='ability'&&['ward','pulse','lunge'].includes(args.ability_id)){const turn=await input.syncYaw();if(!turn.ok)throw Error(turn.message||turn.code)}const r=await api.intent(op,args);if(!r.ok)throw Error(r.message||r.code);if(r.result?.message)announce(r.result.message);await api.refresh(true);if(!keepOpen)closeOthers();if(r.result?.shop_id)progression.shop(r.result.shop_id);else if(r.result?.open_goals)progression.open('goalsPanel');return r}
 catch(e){announce(e.message);return null}
}
async function action(name){
 if(name==='kit'){$('kitButton').click();return}
 if(name==='goals'){progression.open('goalsPanel');return}
 if(name==='skills'){progression.open('skillsPanel');return}
 if(!api.online||!api.state?.player?.alive)return;
 if(name==='use'){
   await input.syncYaw();const t=target();
   if(t?.category==='item')return act('loot',{item_id:t.id,version:t.version});
   if(t?.category==='feature')return act('interact',{target_id:t.id});
   announce('Look toward a nearby person or object to interact.');return;
 }
 if(name==='ward'){const cl=Catalog.classes.find(x=>x.id===api.state.player.base_class);if(cl)return act('ability',{ability_id:cl.ability});return}
 if(name==='strike'){
   await input.syncYaw();renderer.swing();const t=target(),args=t&&(t.category==='enemy'||t.category==='player')?{target_id:t.id}:{};
   const r=await act(name==='ward'?'cast':'attack',args);if(r?.ok)NeonSound.cue(name==='ward'?'cast':'hit');return;
 }
 if(name==='scan')return act('scan');
}
input.onAction=name=>action(name).catch(e=>announce(e.message));$('useButton').onclick=()=>action('use').catch(e=>announce(e.message));$('strikeButton').onclick=()=>action('strike').catch(e=>announce(e.message));
$('wardButton').onclick=()=>action('ward').catch(e=>announce(e.message));$('scanButton').onclick=()=>act('scan');$('restButton').onclick=()=>act('rest',{},true);$('dressingButton').onclick=()=>act('use_medkit',{},true);
$('newCharacter').onclick=()=>showCreator();$('reshapeButton').onclick=()=>showCreator(api.state.player);
function downloadJSON(name,obj){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),500)}
$('exportAppearance').onclick=()=>{const p=api.state?.player;if(p)downloadJSON('neon-veil-appearance.json',{schema:'neon-veil/appearance/1',appearance:p.appearance})};
$('soundButton').onclick=async()=>{try{const on=await NeonSound.toggle();$('soundButton').textContent=on?'Sound on':'Sound off';$('soundButton').setAttribute('aria-pressed',String(on));$('soundButton').title=on?'Mute music and ambience':'Enable music and ambience'}catch(e){announce(e.message)}};
$('motionSetting').onchange=e=>{prefs.reduced=e.target.checked;savePrefs()};$('volumeSetting').oninput=e=>{prefs.volume=+e.target.value;savePrefs()};$('sensitivitySetting').oninput=e=>{prefs.sensitivity=+e.target.value;savePrefs()};
function keyButtons(){const host=$('keyBindings');host.replaceChildren();for(const key of Object.keys(NEON_DEFAULT_KEYS)){const l=document.createElement('span'),b=document.createElement('button');l.textContent=key[0].toUpperCase()+key.slice(1);b.textContent=prefs.keys[key]===' '?'Space':prefs.keys[key].toUpperCase();b.setAttribute('aria-label','Remap '+key);b.onclick=()=>{b.textContent='Press key';const listener=e=>{document.removeEventListener('keydown',listener,true);if(e.key==='Tab'||e.key==='Escape'){b.textContent=prefs.keys[key]===' '?'Space':prefs.keys[key].toUpperCase();return}e.preventDefault();const k=e.key.toLowerCase();if(k.length!==1||e.ctrlKey||e.metaKey||e.altKey||k==='\t'){keyButtons();return}for(const [a,v]of Object.entries(prefs.keys))if(v===k&&a!==key){$('helpStatus').textContent='That key is already assigned.';keyButtons();return}prefs.keys[key]=k;savePrefs();keyButtons();$('helpStatus').textContent='Saved '+key+' key.'};document.addEventListener('keydown',listener,true)};host.append(l,b)}}
keyButtons();$('resetKeys').onclick=()=>{prefs.keys={...NEON_DEFAULT_KEYS};savePrefs();keyButtons()};
// Preserve live DOM/focus when unrelated world events change. Lists are projections,
// not an excuse to replace every interactive node on each network snapshot.
const listFingerprints=new Map();
function updateList(id,data,draw){
 const fingerprint=JSON.stringify(data);if(listFingerprints.get(id)===fingerprint)return;
 const host=$(id);host.replaceChildren();draw(host);listFingerprints.set(id,fingerprint);
}
function renderKit(){
 const S=api.state;if(!S)return;const p=S.player;
 $('kitName').textContent=p?.name||'No living character selected';
 $('kitStats').textContent=p?`${p.alive?'Alive':'Remembered'} · level ${p.level} · ${p.cred} cred · ${p.xp} experience · ${Math.round(p.focus)} focus · heat ${p.heat}`:'Create someone to enter the continuum.';
 updateList('abilityButtons',p?.abilities||[],host=>{for(const id of p?.abilities||[]){if(['strike','interact','scan','rest'].includes(id))continue;const b=document.createElement('button');b.textContent=id[0].toUpperCase()+id.slice(1);b.onclick=()=>act('ability',{ability_id:id},true);host.append(b)}});
 updateList('inventoryList',S.inventory,inv=>{
  for(const i of S.inventory){const li=document.createElement('li'),span=document.createElement('span'),small=document.createElement('small');span.textContent=i.name+(i.equipped?' · equipped':'');span.className='inventory-name';small.textContent='In your custody';li.append(span,small);const controls=document.createElement('div');controls.className='item-controls';for(const op of (i.slot?['equip']:['food','medkit'].includes(i.kind)?['consume']:[])){const b=document.createElement('button');b.textContent=op==='equip'?'Equip':'Use';b.disabled=op==='equip'&&!!i.equipped;b.onclick=()=>act(op,{item_id:i.id,version:i.version},true);controls.append(b)}li.append(controls);inv.append(li)}
  if(!S.inventory.length){const li=document.createElement('li');li.textContent='No carried items.';inv.append(li)}
 });
 const nearby=p?.alive?S.items.filter(i=>i.x!=null&&Math.hypot(i.x-p.x,i.y-p.y)<=2.3):[];
 updateList('nearbyLoot',nearby,loot=>{for(const i of nearby){const b=document.createElement('button');b.textContent='Recover '+i.name;b.onclick=()=>act('loot',{item_id:i.id,version:i.version},true);loot.append(b)}});
 updateList('characterList',[p?.id,...S.account.characters.map(c=>[c.id,c.name,c.alive])],chars=>{
  for(const c of S.account.characters){const row=document.createElement('div'),text=document.createElement('p'),small=document.createElement('small'),button=document.createElement('button');row.className='character-row';text.textContent=c.name;small.textContent=c.alive?' · living':' · remembered';text.append(small);button.textContent=c.alive?(c.id===p?.id?'Here now':'Continue'):'Use appearance';button.disabled=c.alive&&c.id===p?.id;button.onclick=async()=>{if(c.alive){await act('select',{character_id:c.id});await api.refresh(true)}else showCreator(c)};row.append(text,button);chars.append(row)}
 });
 const hours=S.account.active_seconds/3600;$('slotStatus').textContent=`${S.account.slots} living slot${S.account.slots===1?'':'s'} · ${hours.toFixed(2)} active hours. Second slot requires more than 24 hours. Offline time is not credited.`;
 $('newCharacter').disabled=S.account.characters.filter(c=>c.alive).length>=S.account.slots;
 updateList('worldNews',[(S.reports||[]).map(r=>[r.id,r.age_seconds]),S.events.slice(0,4).map(e=>e.seq)],news=>{for(const r of S.reports||[]){const li=document.createElement('li');li.textContent=r.text;li.dataset.reportId=r.id;news.append(li)}for(const e of S.events.slice(0,4)){const li=document.createElement('li');li.textContent=eventText(e);news.append(li)}if(!(S.reports||[]).length){const li=document.createElement('li');li.textContent='No recent local reports. Talk to Moth or a nearby shopkeeper; the city keeps its own time.';news.append(li)}});
}
function eventText(e){const p=e.payload||{};switch(e.kind){case 'WEATHER_CHANGED':return `Weather shifts to ${p.weather}.`;case 'GRID_WARNING':case 'GRID_OVERLOADED':case 'REFRIGERATION_EXPOSURE':case 'GRID_BACKUP_CONNECTED':return p.message;case 'ITEMS_RECLAIMED':return `A recovery crew collected ${p.count} abandoned item${p.count===1?'':'s'}.`;case 'CHARACTER_DIED':return 'Someone fell in the district. Their recovery deadline is running.';case 'RELAY_COPIED':return 'A rain-relay signal was copied.';case 'JOB_COMPLETED':return 'A relay job was completed. Moth’s network moves again.';case 'OFFLINE_ROUTINE':return 'An absent resident returned to shelter and routine recovery.';case 'ENEMY_FELL':return p.boss?'The Custodian has fallen. The district records the loss.':'A sentinel fell outside town.';case 'RESTED':return 'A resident recovered in shelter.';case 'CUSTODY_TRANSFERRED':return 'A world item changed custody.';default:return e.kind.toLowerCase().replaceAll('_',' ')}}
function renderDeath(S){const p=S.player;if(!p||p.alive)return;const body=S.corpses.find(b=>b.character_id===p.id);$('deathTitle').textContent=p.name+' is remembered.';$('deathMessage').textContent=body?`Their possessions remain where they fell. ${body.eligible?'Your current character can recover them.':'Only a living alternate already present at death can recover your own belongings.'} ${body.cause==='pvp'?'Other accounts cannot take anything from a PvP death.':''}`:'The recovery window has ended. Remaining possessions were reclaimed by the world.';$('deathTimer').textContent=body?formatTime(remaining(body))+' remaining':'Recovery complete';updateList('deathChoices',S.account.characters.filter(c=>c.alive).map(c=>[c.id,c.name]),choices=>{for(const c of S.account.characters.filter(c=>c.alive)){const b=document.createElement('button');b.textContent='Continue as '+c.name;b.onclick=async()=>{const r=await api.intent('select',{character_id:c.id},null);if(!r.ok){announce(r.message);return}closeOthers();await api.refresh(true);$('worldCanvas').focus()};choices.append(b)}});$('reshapeButton').disabled=S.account.characters.filter(c=>c.alive).length>=S.account.slots;if(deathShown!==p.id){deathShown=p.id;closeOthers();openDialog('death')}}
api.addEventListener('state',e=>{
 const S=e.detail,p=S.player;$('playerName').textContent=p?.name||'Someone new in Rainmarket';$('health').max=p?.max_hp||24;$('health').value=p?.hp||0;$('healthText').textContent=p?`${Math.ceil(p.hp)} / ${p.max_hp}`:'—';$('heatText').textContent=p?`HEAT ${p.heat}`:'';
 const a=S.world.atmosphere;$('weatherLabel').textContent=a.weather.toUpperCase()+' · '+window.NeonPower.label(S.world,p);const reg=S.world.regions?.find(r=>p&&p.x>=r.x1&&p.x<r.x2&&p.y>=r.y1&&p.y<r.y2);$('zoneLabel').textContent=p&&p.x>=1&&p.x<12&&p.y>=1&&p.y<21?'LANTERN QUARTER · TOWN PEACE':(reg?.name||'OPEN REACH').toUpperCase()+' · STAY ALERT';
 const goal=S.goals?.find(g=>g.state==='active'&&g.tracked);$('objective').textContent=!p?'Create a person. The city is already here.':!p.alive?'A new life can begin.':goal?goal.name+' · G to manage':'Explore freely · G for optional goals';
 if(!creatorOffered&&!p){creatorOffered=true;showCreator()}
 if(p?.alive&&deathShown){deathShown=null;if($('death').open)$('death').close()}
 renderDeath(S);if($('fieldKit').open)renderKit()
 $('offlineBanner').hidden=true;
});
api.addEventListener('connection',()=>{$('offlineBanner').hidden=api.online;if(!api.online)input.clear()});
setInterval(()=>{const t=target();$('targetCaption').textContent=t?(t.category==='enemy'||t.category==='player'?t.name:`${t.name} · E / Interact`):'';const a=((input.yaw%(Math.PI*2))+Math.PI*2)%(Math.PI*2);$('compass').textContent=['E','SE','S','SW','W','NW','N','NE'][Math.round(a/(Math.PI/4))%8]},140);
api.start().catch(e=>{$('offlineBanner').hidden=false;$('offlineBanner').textContent='Start the included local server, then open its address. '+e.message;announce('This build needs START_NEON_VEIL.bat. Opening index.html alone does not create a server.')});
// Read-only diagnostics for tests, never a client authority over stored objects.
window.NeonApp=Object.freeze({version:'0.30.0',get snapshot(){return api.state},get frames(){return renderer.frames},get sound(){return {enabled:NeonSound.enabled,state:NeonSound.context?.state,notes:NeonSound.notes}},get input(){return {yaw:input.yaw}}});
})().catch(e=>{const box=document.getElementById('offlineBanner');if(box){box.hidden=false;box.textContent='Unable to start: '+e.message}console.error(e)});
