'use strict';
(()=>{
const $=id=>document.getElementById(id),text=(tag,value,cls)=>{const e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e};
class Progression{
 constructor(catalog,api,hooks){this.catalog=catalog;this.api=api;this.hooks=hooks;this.shopId=null;this.stamps=new Map();
  $('goalsButton').onclick=$('kitGoalsButton').onclick=()=>this.open('goalsPanel');$('skillsButton').onclick=()=>this.open('skillsPanel');$('atlasButton').onclick=()=>this.open('atlasPanel');
  $('workButton').onclick=()=>this.perform('work',{shop_id:this.shopId});
  api.addEventListener('state',()=>this.refresh());
 }
 open(id){for(const d of document.querySelectorAll('dialog[open]'))d.close();this.hooks.open(id);this.refresh(true)}
 button(label,fn,key){const b=text('button',label);b.type='button';b.onclick=fn;if(key)b.dataset.focusKey=key;return b}
 async perform(op,args){const r=await this.hooks.act(op,args,true);this.refresh();return r}
 update(id,data,draw,force=false){const stamp=JSON.stringify(data);if(!force&&this.stamps.get(id)===stamp)return;const host=$(id),focus=host.contains(document.activeElement)?document.activeElement.dataset.focusKey:null;host.replaceChildren();draw(host);this.stamps.set(id,stamp);if(focus)host.querySelector(`[data-focus-key="${CSS.escape(focus)}"]`)?.focus({preventScroll:true})}
 shop(id){this.shopId=id;this.open('shopPanel')}
 refresh(force=false){const S=this.api.state;if(!S)return;
  if($('goalsPanel').open)this.goals(S,force);if($('skillsPanel').open)this.skills(S,force);if($('shopPanel').open)this.market(S,force);if($('atlasPanel').open)this.atlas(S);
 }
 goals(S,force){this.update('goalsList',S.goals,host=>{for(const g of S.goals||[]){const card=text('section','', 'goal-card');card.append(text('span',g.state.toUpperCase()+(g.tracked?' · TRACKING':''),'goal-state'),text('h3',g.name),text('p',g.description));const steps=Object.entries(g.required).map(([k,n])=>`${k.replaceAll('_',' ')} ${g.progress?.[k]||0}/${n}`).join(' · ');card.append(text('p',steps));if(g.id==='first_steps'&&S.player){const cl=this.catalog.classes.find(x=>x.id===S.player.base_class),job=this.catalog.jobs.find(x=>x.id===S.player.job_role);card.append(text('p',`${cl.name}: ${cl.description} Occupation: ${job.name}. Use Field kit for your abilities; visit a shop for work.`))}
   const row=text('div','','panel-actions');if(g.state!=='complete'){
    const add=(label,action)=>row.append(this.button(label,()=>this.perform('goal',{goal_id:g.id,action}),g.id+'-'+action));
    if(g.state==='active'){add(g.tracked?'Stop tracking':'Track',g.tracked?'untrack':'track');add('Pause','pause');add('Abandon','abandon')}
    else add(g.state==='offered'?'Follow this goal':'Resume',g.state==='offered'?'start':'resume');
   }card.append(row);host.append(card)}},force)}
 skills(S,force){const p=S.player;if(!p){$('skillSummary').textContent='Create a character first.';return}
  $('skillSummary').textContent=`${p.name} · Level ${p.level} · ${p.xp}/${p.next_level_xp} XP · ${p.skill_points} unspent point${p.skill_points===1?'':'s'}. Each rank costs one point. Appearance is not power.`;
  this.update('secondaryChoices',[p.level,p.base_class,p.secondary_class],host=>{if(p.secondary_class){host.append(text('h3',p.combo_name),text('p','Your main class is retained. The secondary discipline and combo tree add choices, not an identity reset.'));return}
   if(p.level<=50){host.append(text('p',`A second, different class opens at level 51. Your primary remains ${this.catalog.classes.find(x=>x.id===p.base_class).name}.`));return}
   host.append(text('h3','Choose your secondary discipline'),text('p','Choose once. Your main class and earned skills stay. This opens its base branch and a pair-specific combo branch.'));
   const label=text('label','Secondary class'),select=document.createElement('select');select.id='secondarySelect';select.append(new Option('Read and choose a different class',''));for(const c of this.catalog.classes)if(c.id!==p.base_class)select.append(new Option(c.name+' — '+c.ability,c.id));label.append(select);const desc=text('p','Select an option to read what it does.'),choose=this.button('Add this secondary class',()=>this.perform('secondary',{class_id:select.value}),'secondary-commit');choose.disabled=true;select.onchange=()=>{desc.textContent=this.catalog.classes.find(c=>c.id===select.value)?.description||'Choose a listed class.';choose.disabled=!select.value};host.append(label,desc,choose)
  },force);
  this.update('skillTrees',[p.skills,p.level,p.secondary_class,p.skill_points],host=>{const groups={};for(const n of S.skill_tree||[]){const key=n.tree+':'+n.owner;(groups[key]||(groups[key]=[])).push(n)}
   for(const [key,nodes]of Object.entries(groups)){const d=document.createElement('details');d.className='skill-group';d.open=key.startsWith('base:'+p.base_class)||key.startsWith('combo:');const [tree,owner]=key.split(':');const name=tree==='job'?this.catalog.jobs.find(x=>x.id===owner)?.name:tree==='combo'?p.combo_name:this.catalog.classes.find(x=>x.id===owner)?.name;d.append(text('summary',(tree==='combo'?'Combination':tree==='job'?'Occupation':'Class')+' · '+name));const grid=text('div','','skill-grid');for(const n of nodes){const card=text('section','','skill-card');card.append(text('h4',n.name+` · ${n.rank}/${n.max_rank}`),text('p',n.description),text('small',`Level ${n.level}+ · 1 point per rank`+(n.requires.length?' · Requires '+n.requires.map(([id,k])=>`${this.catalog.nodes.find(x=>x.id===id)?.name||id} ${k}`).join(', '):'')));const b=this.button(n.rank>=n.max_rank?'Complete':n.available?'Learn next rank':'Not yet available',()=>this.perform('learn',{node_id:n.id}),n.id);b.disabled=!n.available;card.append(b);grid.append(card)}d.append(grid);host.append(d)}
  },force)
 }
 market(S,force){const v=S.shops?.find(x=>x.id===this.shopId),p=S.player;if(!v||!p){$('shopStatus').textContent='This shop is unavailable.';return}$('shopTitle').textContent=v.name;const near=Math.hypot(v.x-p.x,v.y-p.y)<=2.3,open=v.service?.open!==false;$('shopStatus').textContent=`Your cred: ${p.cred} · Shop funds: ${v.treasury}. ${v.service?.note||''} ${near?'You are at the counter.':'Return to this shop to trade.'}`;$('workButton').disabled=!near||!open||v.treasury<18;
  this.update('shopOffers',[v.offers,p.cred,p.id,near,open],host=>{for(const g of v.offers){const card=text('section','','offer-card');card.append(text('h4',g.name),text('p',g.description),text('p',`${g.price} cred · ${g.stock}/${g.capacity} in stock`));const b=this.button('Buy · '+g.price+' cred',()=>this.perform('buy',{shop_id:v.id,sku:g.sku,version:g.version,quoted_price:g.price}),g.sku);b.disabled=!near||!open||!g.stock||p.cred<g.price;card.append(b);host.append(card)}},force);
  this.update('shopSell',[S.inventory,v.treasury,near,open],host=>{for(const i of S.inventory){const g=this.catalog.goods.find(x=>x.id===i.sku);if(!g&&i.kind!=='salvage')continue;const price=Math.floor((g?.price||15)*.35),card=text('section','','offer-card');card.append(text('h4',i.name+(i.equipped?' · equipped':'')),text('p',`Transfer custody to the shop for ${price} cred. Buy/sell prices do not create a profit loop.`));const b=this.button('Sell · '+price+' cred',()=>this.perform('sell',{shop_id:v.id,item_id:i.id,version:i.version}),'sell-'+i.id);b.disabled=!near||!open||v.treasury<price;card.append(b);host.append(card)}if(!host.children.length)host.append(text('p','No resellable goods. Starter supplies cannot be farmed through new characters.'))},force)
 }
 atlas(S){const w=S.world,cv=$('atlasCanvas'),c=cv.getContext('2d'),sx=cv.width/w.width,sy=cv.height/w.height;c.fillStyle='#0c1920';c.fillRect(0,0,cv.width,cv.height);for(let y=0;y<w.height;y++)for(let x=0;x<w.width;x++){c.fillStyle=w.grid[y][x]==='#'?'#5c737b':'#142b30';c.fillRect(x*sx,y*sy,sx+.1,sy+.1)}for(const f of w.features){c.fillStyle=f.kind==='shop'?'#ffcf8e':f.kind==='landmark'?'#9cdabd':'#78aece';c.fillRect(f.x*sx-2,f.y*sy-2,4,4)}if(S.player){const p=S.player;c.fillStyle='#ffffff';c.beginPath();c.arc(p.x*sx,p.y*sy,4,0,Math.PI*2);c.fill()}
  $('atlasText').textContent=S.player?`You are at ${S.player.x.toFixed(1)}, ${S.player.y.toFixed(1)}. Gold markers: shops. Green: places to discover. All regions are open; marked buildings have walk-through entrances.`:'Create a person to enter.';
  this.update('atlasRegions',w.seed,host=>{for(const reg of w.regions){const p=text('p',`${reg.name}: ${reg.x1}–${reg.x2} east, ${reg.y1}–${reg.y2} south.`);host.append(p)}})
 }
}
window.NeonProgressionClass=Progression;
})();
