'use strict';
(()=>{
const DEFAULTS={forward:'w',left:'a',back:'s',right:'d',use:'e',strike:' ',ward:'q',scan:'f',kit:'i',goals:'g',skills:'k'};
function vector(f,s){const n=Math.max(1,Math.hypot(f,s));return {forward:f/n,strafe:s/n}}
window.NeonMovementVector=vector;
class Input{
 constructor(canvas,api){this.canvas=canvas;this.api=api;this.keys=new Set();this.touch=new Map();this.usedTouches=new Set();this.yaw=0;this.sensitivity=1;this.playerId=null;this.motionAck=null;this.pending=false;this.dirtyYaw=false;this.map={...DEFAULTS};this.onAction=()=>{};this.turnDir=0;this.lastSent=0;
  window.addEventListener('keydown',e=>this.key(e,true));window.addEventListener('keyup',e=>this.key(e,false));window.addEventListener('blur',()=>this.clear());document.addEventListener('visibilitychange',()=>{if(document.hidden)this.clear()});
  api.addEventListener('state',e=>{const p=e.detail.player;if(p&&p.id!==this.playerId){this.playerId=p.id;this.yaw=p.yaw;this.motionAck=null;this.clear()}if(!p?.alive)this.clear()});
  let drag=null;
  canvas.addEventListener('pointerdown',e=>{if(document.querySelector('dialog[open]'))return;canvas.focus({preventScroll:true});if(e.button!==0&&e.pointerType==='mouse')return;drag={id:e.pointerId,x:e.clientX,y:e.clientY,distance:0,type:e.pointerType};canvas.setPointerCapture(e.pointerId)});
  canvas.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;const dx=e.clientX-drag.x;drag.distance+=Math.abs(dx)+Math.abs(e.clientY-drag.y);this.yaw+=dx*.005*this.sensitivity;this.dirtyYaw=true;drag.x=e.clientX;drag.y=e.clientY});
  canvas.addEventListener('pointerup',e=>{if(drag?.id===e.pointerId){if(drag.distance<5&&drag.type==='mouse')this.onAction('strike');drag=null}});
  canvas.addEventListener('pointercancel',()=>{drag=null});
  canvas.addEventListener('contextmenu',e=>{e.preventDefault();this.onAction('use')});
  for(const b of document.querySelectorAll('[data-move],[data-look]')){
   const val=b.dataset.move||'look_'+b.dataset.look;
   b.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();b.setPointerCapture(e.pointerId);this.touch.set(e.pointerId,val);this.usedTouches.delete(e.pointerId);b.classList.add('is-held')});
   const release=(e,cancel=false)=>{const held=this.touch.get(e.pointerId),used=this.usedTouches.has(e.pointerId);this.touch.delete(e.pointerId);this.usedTouches.delete(e.pointerId);b.classList.remove('is-held');if(held&&!used&&!cancel)this.nudge(held).catch(()=>this.clear())};b.addEventListener('pointerup',e=>release(e));b.addEventListener('pointercancel',e=>release(e,true));b.addEventListener('lostpointercapture',e=>release(e,true));
   // Keyboard activation gives the same control without a drag/hold requirement.
   b.addEventListener('click',e=>{if(e.detail===0)this.nudge(val).catch(()=>this.clear())})
  }
  setInterval(()=>this.tick(),100);
 }
 enabled(){return this.api.online&&this.api.state?.player?.alive&&!document.hidden&&!document.querySelector('dialog[open]')}
 clear(){this.keys.clear();this.touch.clear();this.usedTouches.clear();document.querySelectorAll('.is-held').forEach(b=>b.classList.remove('is-held'))}
 key(e,down){
  const k=e.key.toLowerCase();if(!down){this.keys.delete(k);return}
  if(e.key==='Tab'||e.key==='Escape'||e.ctrlKey||e.altKey||e.metaKey)return;
  if(!this.enabled()||e.target.closest('input,textarea,select,button,a,summary'))return;
  const action=Object.keys(this.map).find(a=>this.map[a]===k);
  if(['forward','back','left','right'].includes(action)||['arrowleft','arrowright','arrowup','arrowdown'].includes(k)){e.preventDefault();this.keys.add(k);return}
  if(action&&!e.repeat){e.preventDefault();this.onAction(action)}
 }
 held(action){return this.keys.has(this.map[action])||[...this.touch.values()].includes(action)}
 async nudge(value){
  if(!this.enabled())return;
  if(value.startsWith('look_')){this.yaw+=(value==='look_left'?-1:1)*.24;this.dirtyYaw=true;return}
  const fw=value==='forward'?1:value==='back'?-1:0,st=value==='right'?1:value==='left'?-1:0;
  const r=await this.api.intent('move',{...vector(fw,st),yaw:this.yaw});if(r.ok)this.motionAck={...r.result,revision:r.revision};await this.api.refresh();
 }
 async syncYaw(){const r=await this.api.intent('turn',{yaw:this.yaw});this.dirtyYaw=false;return r}
 async tick(){
  if(!this.enabled()){this.clear();return}if(this.pending)return;
  const left=this.keys.has('arrowleft')||[...this.touch.values()].includes('look_left'),right=this.keys.has('arrowright')||[...this.touch.values()].includes('look_right');
  if(left||right){this.yaw+=(right?1:-1)*.13*this.sensitivity;this.dirtyYaw=true}
  const fw=Number(this.held('forward')||this.keys.has('arrowup'))-Number(this.held('back')||this.keys.has('arrowdown')),st=Number(this.held('right'))-Number(this.held('left'));
  if(!fw&&!st&&!this.dirtyYaw)return;
  for(const id of this.touch.keys())this.usedTouches.add(id);
  this.pending=true;
  try{const r=await this.api.intent(fw||st?'move':'turn',fw||st?{...vector(fw,st),yaw:this.yaw}:{yaw:this.yaw});this.dirtyYaw=false;if(r.ok&&(fw||st))this.motionAck={...r.result,revision:r.revision};if(!r.ok&&r.code==='CHARACTER_DEAD')this.clear()}
  catch(_){this.api.online=false;this.clear();this.api.dispatchEvent(new Event('connection'))}
  finally{this.pending=false}
 }
}
window.NeonInputClass=Input;window.NEON_DEFAULT_KEYS=Object.freeze(DEFAULTS);
})();
