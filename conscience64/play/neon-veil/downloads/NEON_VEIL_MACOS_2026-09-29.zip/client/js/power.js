/* Read-only projection of accepted grid state. No clocks, requests or mutations. */
"use strict";
(()=>{
 const local=(world,x,y)=>{const b=world?.power_grid?.region;return !!b&&x>=b.x1&&x<b.x2&&y>=b.y1&&y<b.y2};
 const poweredAt=(world,x,y)=>{
   if(!world?.power_grid)return world?.atmosphere?.power!==false;
   return !local(world,x,y)||world.power_grid.phase!=="OUTAGE";
 };
 const fixtureKind=(world,o)=>{
   if(o.id==="grid-terminal")return "transformer-"+String(world?.power_grid?.phase||"QUIET").toLowerCase();
   if(o.kind==="lamp")return poweredAt(world,o.x,o.y)?"lamp":"lamp-off";
   if(o.kind==="shop"&&o.id==="forge"&&world?.power_grid?.phase==="OUTAGE")return "shop-closed";
   return o.kind;
 };
 const hazardLabel=(world,id)=>world?.power_grid?.isolated_hazards?.includes(id)?"CONDUIT ISOLATED":"LIVE CONDUIT";
 const label=(world,p)=>{
   if(!world?.power_grid)return world?.atmosphere?.power===false?"BACKUP POWER":"GRID LIVE";
   if(!p||!local(world,p.x,p.y))return "GRID LIVE";
   return {QUIET:"GRID LIVE",WARNING:"FEEDER STRAIN",OUTAGE:"MAIN FEEDER TRIPPED",BACKUP:"ALTERNATE FEEDER"}[world.power_grid.phase]||"GRID STATUS UNKNOWN";
 };
 window.NeonPower=Object.freeze({local,poweredAt,fixtureKind,hazardLabel,label});
})();
