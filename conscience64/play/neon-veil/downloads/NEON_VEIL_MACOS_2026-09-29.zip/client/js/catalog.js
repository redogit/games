'use strict';
// Shared server/client vocabulary. Server reads the same versioned file.
window.NeonCatalogReady=fetch('data/catalog.json').then(r=>{if(!r.ok)throw Error('Game catalog unavailable');return r.json()}).then(c=>{if(c.schema!=='neon-veil/catalog/0.30')throw Error('Unsupported game catalog');window.NeonCatalog=Object.freeze(c);return c});
