'use strict';
(()=>{
const $=id=>document.getElementById(id),A=window.NeonAppearance;
const STEPS=['Species','Base class','Modern occupation','Starting interest','Customize','Review'];
const FIELDS=['species','base_class','job_role','start_path'];
class Creator{
 constructor(catalog,api,hooks){this.catalog=catalog;this.api=api;this.hooks=hooks;this.step=0;this.choices={};this.ap=A.defaults();this.template=null;this.buildControls();this.bind()}
 groups(){return [this.catalog.species,this.catalog.classes,this.catalog.jobs,this.catalog.paths]}
 chosen(group){return this.groups()[group].find(x=>x.id===this.choices[FIELDS[group]])}
 buildControls(){
  const host=$('shapeControls');host.replaceChildren();for(const key of A.shapeKeys){const label=document.createElement('label'),txt=document.createElement('span'),input=document.createElement('input'),out=document.createElement('output');txt.textContent=key.replace(/([A-Z])/g,' $1');input.type='range';input.min='.6';input.max='1.5';input.step='.01';input.dataset.shape=key;input.setAttribute('aria-label',txt.textContent);input.oninput=()=>{this.ap.shape[key]=+input.value;out.textContent=(+input.value).toFixed(2);this.preview()};label.append(txt,input,out);host.append(label)}
 }
 bind(){
  $('creatorNext').onclick=()=>{if(this.validate()){this.step=Math.min(5,this.step+1);this.render()}};
  $('creatorBack').onclick=()=>{this.step=Math.max(0,this.step-1);this.render()};
  $('creatorForm').onsubmit=async e=>{e.preventDefault();if(this.step!==5){$('creatorNext').click();return}if(!this.validate())return;const btn=$('enterButton');btn.disabled=true;try{let args={...this.choices,name:$('nameInput').value,appearance:this.ap};if(this.template)args.template_id=this.template;const r=await this.api.intent('create',args,null);if(!r.ok)throw Error(r.message||r.code);await this.api.refresh(true);if($('guideOptIn').checked){await this.api.intent('goal',{goal_id:'first_steps',action:'start'});await this.api.refresh(true)}$('creator').close();document.title='NEON//VEIL · Open world';$('worldCanvas').focus();this.hooks.announce('Welcome. Explore freely, or open Goals for a guide to your chosen practice.')}catch(err){$('creatorError').textContent=err.message}finally{btn.disabled=false}};
  for(const key of ['skin','hair','eyes','coat','accent'])$(key+'Color').oninput=e=>{this.ap[key]=e.target.value;this.preview()};
  $('hairStyleInput').onchange=e=>{this.ap.hair_style=e.target.value;this.preview()};$('pronounsInput').oninput=e=>{this.ap.pronouns=e.target.value;this.cache()};
  $('buildInput').onchange=e=>{const p={neutral:{},lean:{waist:.8,chest:.9,hips:.9,armThickness:.85,legThickness:.85},broad:{shoulders:1.25,chest:1.22,hips:1.1,armThickness:1.2},soft:{waist:1.15,hips:1.2,chest:1.08,legThickness:1.12},compact:{height:.8,arms:.85,legs:.85},tall:{height:1.22,arms:1.14,legs:1.15}};this.ap.shape={...A.defaults().shape,...p[e.target.value]};this.syncAppearance()};
  $('resetAppearance').onclick=()=>{this.ap=A.defaults();this.template=null;this.applySeed();this.syncAppearance()};
  $('appearanceImport').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>1024*1024)throw Error('Appearance files must be at most 1 MB.');this.ap=A.importTemplate(JSON.parse(await f.text()));this.template=null;this.syncAppearance();$('creatorError').textContent='Only appearance imported. Your species/class/job selections, identity and progression were not replaced.'}catch(err){$('creatorError').textContent=err.message}e.target.value=''};
  $('templateSelect').onchange=e=>{const c=this.api.state?.account.characters.find(c=>c.id===e.target.value);this.template=c?.id||null;if(c){this.ap=structuredClone(c.appearance);this.syncAppearance()}};
 }
 cache(){try{localStorage.setItem('neon-veil/appearance-draft/1',JSON.stringify({appearance:this.ap}))}catch(_){}}
 applySeed(group=null){const species=this.chosen(0),cl=this.chosen(1);if(species&&(group===0||group===null))this.ap.skin=species.skin;if(cl&&(group===1||group===null))this.ap.accent=cl.color}
 preview(){A.draw($('portrait').getContext('2d'),this.ap,320,420,this.choices);$('previewDescription').textContent=[this.chosen(0)?.name,this.chosen(1)?.name,this.chosen(2)?.name].filter(Boolean).join(' · ')||'Preview a species to begin. Customization follows your choices.';this.cache()}
 syncAppearance(){for(const key of ['skin','hair','eyes','coat','accent'])$(key+'Color').value=this.ap[key];$('pronounsInput').value=this.ap.pronouns||'';$('hairStyleInput').value=this.ap.hair_style;for(const r of $('shapeControls').querySelectorAll('input')){r.value=this.ap.shape[r.dataset.shape];r.parentElement.querySelector('output').textContent=Number(r.value).toFixed(2)}this.preview()}
 open(template=null){for(const d of document.querySelectorAll('dialog[open]'))d.close();this.hooks.clear();this.step=0;this.choices={};this.template=template?.id||null;this.ap=template?structuredClone(template.appearance):A.defaults();if(!template)try{const saved=JSON.parse(localStorage.getItem('neon-veil/appearance-draft/1')||'null');if(saved)this.ap=A.importTemplate(saved)}catch(_){}$('nameInput').value='';$('guideOptIn').checked=false;const chars=this.api.state?.account.characters||[];$('templatePicker').hidden=!chars.length;$('templateSelect').replaceChildren(new Option('No previous appearance',''));for(const c of chars)$('templateSelect').append(new Option(c.name+(c.alive?'':' · remembered'),c.id));$('templateSelect').value=this.template||'';this.syncAppearance();this.render();this.hooks.open('creator')}
 validate(){
  $('creatorError').textContent='';if(this.step<4&&!this.choices[FIELDS[this.step]]){$('creatorError').textContent='Read the options and choose one before continuing.';return false}
  if(this.step>=4){if(!FIELDS.every(f=>this.choices[f]))return false;const name=$('nameInput').value.trim();if(!name||name.length>32){$('creatorError').textContent='Give your character a name, 1–32 characters.';$('nameInput').focus();return false}}
  return true;
 }
 render(){
  $('creatorError').textContent='';$('creatorTitle').textContent=STEPS[this.step]+` · ${this.step+1} of 6`;document.title=`${this.step+1}/6 ${STEPS[this.step]} · NEON//VEIL`;
  $('stepDescription').textContent=["Each original species changes the visible body, not your freedom to choose a class. Read its traits before selecting.","Historical roles reimagined for a modern cyber-fantasy city. Learn what your starting ability does before choosing.","Your present-day occupation adds attire and a separate incremental skill branch. It never replaces your base class.","This is an interest, not a storyline lock. No mission is required to enter buildings or explore.","Now make the selected person your own: name, presentation, colors and proportions. Appearance never imports inventory or power.","Review the choices. The optional guide teaches your selected mechanics; leave it off to wander."][this.step];
  $('choiceStage').hidden=this.step>=4;$('customizeStage').hidden=this.step!==4;$('reviewStage').hidden=this.step!==5;
  $('creatorBack').disabled=this.step===0;$('creatorNext').hidden=this.step===5;$('enterButton').hidden=this.step!==5;$('creatorNext').disabled=this.step<4&&!this.choices[FIELDS[this.step]];$('stepCount').textContent=`Step ${this.step+1} of 6`;
  const nav=$('creationSteps');nav.replaceChildren();STEPS.forEach((name,i)=>{const b=document.createElement('button');b.type='button';b.textContent=`${i+1} ${name}`;b.disabled=i>this.step;if(i===this.step)b.setAttribute('aria-current','step');b.onclick=()=>{this.step=i;this.render()};nav.append(b)});
  if(this.step<4){$('choiceLegend').textContent='Choose '+STEPS[this.step].toLowerCase();const grid=$('choiceGrid');grid.replaceChildren();const group=this.step;for(const row of this.groups()[group]){const label=document.createElement('label'),radio=document.createElement('input'),strong=document.createElement('strong'),small=document.createElement('small'),p=document.createElement('p');label.className='choice-card';radio.type='radio';radio.name=FIELDS[group];radio.value=row.id;radio.checked=this.choices[FIELDS[group]]===row.id;strong.textContent=row.name;small.textContent=row.lineage||row.tagline||'No permanent restriction';p.textContent=row.description;p.id='explain-'+FIELDS[group]+'-'+row.id;radio.setAttribute('aria-describedby',p.id);radio.onchange=()=>{this.choices[FIELDS[group]]=row.id;this.applySeed(group);this.preview();$('creatorNext').disabled=false};label.append(radio,strong,small,p);grid.append(label)}}
  if(this.step===4)this.syncAppearance();
  if(this.step===5){const out=$('reviewChoices');out.replaceChildren();for(const [k,v] of [['Name',$('nameInput').value],['Species',this.chosen(0).name],['Base class',this.chosen(1).name],['Modern job',this.chosen(2).name],['Interest',this.chosen(3).name]]){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=v;out.append(dt,dd)}$('practiceBrief').textContent=`Your first practice: ${this.chosen(1).description} Your ${this.chosen(2).name.toLowerCase()} work and skill branch are available independently of Moth’s request.`}
  this.preview();$('creatorTitle').focus({preventScroll:true});$('creator').scrollTop=0;
 }
}
window.NeonCreatorClass=Creator;
})();
