'use strict';
(()=>{
class API extends EventTarget{
 constructor(){super();this.csrf='';this.state=null;this.online=false;this.pending=false;this.inFlight=null;this.timer=null}
 async request(path,body){
  const options={credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'}};
  if(body!==undefined){options.method='POST';options.body=JSON.stringify(body);options.headers['X-NV-CSRF']=this.csrf}
  const response=await fetch(path,options);const data=await response.json();
  if(!response.ok)throw Error(data.message||`Request ${response.status}`);
  return data;
 }
 async start(){const s=await this.request('/api/session');this.csrf=s.csrf;await this.refresh();this.timer=setInterval(()=>this.refresh(),450);this.heartbeat=setInterval(()=>this.request('/api/heartbeat',{focused:!document.hidden}).catch(()=>{}),5000)}
 refresh(fresh=false){
  // Polls share a read. A command's refresh(true) waits out any pre-command
  // snapshot and then starts/joins a later read, so UI receipts never use it.
  if(this.inFlight)return fresh?this.inFlight.then(()=>this.refresh(false)):this.inFlight;
  this.pending=true;
  this.inFlight=(async()=>{
   try{
    const next=await this.request('/api/state'+(this.state?.world?.geometry_id?'?geometry='+encodeURIComponent(this.state.world.geometry_id):''));
    if(!next.world.grid&&this.state?.world?.geometry_id===next.world.geometry_id)next.world={...this.state.world,...next.world};
    if(!next.world.grid)throw Error('World geometry unavailable. Reconnect before moving.');
    this.state=next;const was=this.online;this.online=true;
    this.dispatchEvent(new CustomEvent('state',{detail:this.state}));if(!was)this.dispatchEvent(new Event('connection'));
   }catch(e){if(this.online){this.online=false;this.dispatchEvent(new Event('connection'))}}
   finally{this.pending=false;this.inFlight=null}
  })();
  return this.inFlight;
 }
 async intent(op,args={},actor=this.state?.player?.id){
  const id=globalThis.crypto?.randomUUID?.()||`input-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const body={v:1,id,op,actor:actor||null,args};let last;
  for(let attempt=0;attempt<2;attempt++){
   try{const r=await this.request('/api/intent',body);return r}
   catch(e){last=e;if(attempt===0)await new Promise(r=>setTimeout(r,250))}
  }
  throw last;
 }
}
window.NeonAPI=new API();
})();
