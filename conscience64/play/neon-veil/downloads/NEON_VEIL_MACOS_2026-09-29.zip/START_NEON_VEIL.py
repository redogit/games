#!/usr/bin/env python3
"""One NEON//VEIL startup controller for all supported host platforms.

No installer, game fork, shell-evaluated command, public deployment or hidden
background service. Python 3.10+ is a prerequisite, not bundled in this file.
Run --check --json for read-only diagnostics. Run --no-open on a headless host.
"""
import sys

# Keep the bootstrap parseable on older Python 3 so failure is understandable.
if __name__ == '__main__' and sys.version_info < (3, 10):
    sys.stderr.write('NEON//VEIL needs Python 3.10 or newer. Try the included '
                     '.sh or .bat shortcut to select an installed Python 3.\n')
    raise SystemExit(2)

import argparse
import contextlib
import importlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import socket
import subprocess
import threading

ROOT = Path(__file__).resolve().parent
VERSION = 'neon-veil/portable-startup/2'


class StartupError(RuntimeError):
    """An actionable startup failure, before gameplay starts."""


def detect_host(sys_platform=None, system=None, machine=None, environ=None):
    """Prefer mobile/userland facts over the shared Darwin/Linux kernel name."""
    plat = sys.platform if sys_platform is None else sys_platform
    system = platform.system() if system is None else system
    machine = platform.machine() if machine is None else machine
    env = os.environ if environ is None else environ
    if plat == 'ios' or system.lower() in ('ios', 'ipados') or machine.startswith(('iPhone', 'iPad')):
        return 'ios'
    termux = bool(env.get('TERMUX_VERSION') or env.get('TERMUX_APP_PID')
                  or env.get('TERMUX__PREFIX') or env.get('TERMUX_APP__DATA_DIR')
                  or 'com.termux' in env.get('PREFIX', ''))
    if plat.startswith('linux') or plat == 'android' or system == 'Android':
        if termux:
            return 'android-termux'
        if plat == 'android' or system == 'Android':
            return 'android'
        return 'linux'
    if plat == 'win32':
        return 'windows'
    if plat == 'darwin':
        return 'macos'
    return 'unsupported'


def loader_route(root, host):
    """One data registry, never dynamic execution of a named path from the browser."""
    registry = json.loads((Path(root) / 'client/startup/loaders.json').read_text(encoding='utf-8'))
    if registry.get('schema') != 'neon-veil/startup-routes/v1':
        raise StartupError('Unsupported startup loader registry; restore the complete package.')
    key = registry['host_routes'].get(host, 'unknown')
    route = registry['routes'][key]
    return {'id': key, 'label': route['label'], 'mode': route['mode'],
            'shortcut': route['shortcut'], 'host_entry': registry['host_entry'],
            'browser_entry': registry['browser_entry']}


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', default=os.environ.get('PORT', '8080'),
                        help='Explicit port, 1024..65535; default PORT or 8080. Never silently changed.')
    parser.add_argument('--data', help='SQLite file; default is the existing package/data/world.sqlite3.')
    parser.add_argument('--lan', action='store_true', help='Explicit trusted-LAN testing only.')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--open', dest='open', action='store_true', help='Open browser (default).')
    group.add_argument('--no-open', dest='open', action='store_false', help='Print the address, no browser launch.')
    parser.set_defaults(open=True)
    parser.add_argument('--check', action='store_true', help='Read-only preflight; no server, save, lock or socket.')
    parser.add_argument('--json', action='store_true', help='Machine-readable preflight (requires --check).')
    args = parser.parse_args(argv)
    try:
        args.port = int(args.port)
    except (TypeError, ValueError):
        parser.error('PORT/--port must be an integer between 1024 and 65535.')
    if not 1024 <= args.port <= 65535:
        parser.error('Choose --port between 1024 and 65535.')
    if args.json and not args.check:
        parser.error('--json is for --check; it does not start a server.')
    return args


def resolve_data(root, requested):
    # An explicit relative argument follows the caller's working directory;
    # the default never does. No silent save migration or platform-specific fork.
    return (Path(requested).expanduser() if requested else
            Path(root) / 'data' / 'world.sqlite3').resolve()


def android_shared_path(path):
    text = str(path.resolve()).replace('\\', '/')
    return any(text == prefix or text.startswith(prefix + '/')
               for prefix in ('/sdcard', '/storage', '/mnt/media_rw'))


def validate_install(root):
    """Presence/content checks catch omissions that a partial hash list cannot."""
    root = Path(root).resolve()
    errors = []
    required = ('server.py', 'nvserver/service.py', 'client/index.html',
                'client/data/catalog.json', 'client/assets/manifest.json',
                'START_LINUX.sh', 'START_ANDROID.sh', 'START_NEON_VEIL.html', 'START_IPHONE.html',
                'client/START_NEON_VEIL.html', 'client/START_IPHONE.html',
                'client/startup/loader.js', 'client/startup/boot.js', 'client/startup/registry.js',
                'client/startup/loaders.json', 'client/startup/loader.css')
    for rel in required:
        p = (root / rel).resolve()
        if not p.is_file() or not p.is_relative_to(root):
            errors.append('Missing or out-of-package runtime file: ' + rel)
    if errors:
        return errors
    try:
        catalog = json.loads((root / 'client/data/catalog.json').read_text(encoding='utf-8'))
        if not all(catalog.get(k) for k in ('classes', 'species', 'goods')):
            errors.append('Runtime catalog is incomplete: client/data/catalog.json')
        client = root / 'client'
        html = (client / 'index.html').read_text(encoding='utf-8')
        for ref in re.findall(r'(?:src|href)="([^"#]+)"', html):
            if ref.startswith('data:'):
                continue
            target = (client / ref).resolve()
            if '://' in ref or not target.is_relative_to(client) or not target.is_file():
                errors.append('Missing or nonlocal HTML dependency: ' + ref)
        # Root file guides and hosted pages must both retain all local dependencies.
        for base in (root, client):
            for name in ('START_NEON_VEIL.html', 'START_IPHONE.html'):
                text = (base / name).read_text(encoding='utf-8')
                for ref in re.findall(r'(?:src|href)="([^"#]+)"', text):
                    target = (base / ref).resolve()
                    if '://' in ref or not target.is_relative_to(root) or not target.is_file():
                        errors.append('Missing or nonlocal loader dependency: ' + name + ': ' + ref)
        loader_route(root, 'linux')
        manifest = json.loads((client / 'assets/manifest.json').read_text(encoding='utf-8'))
        for key, asset in manifest['assets'].items():
            p = (client / 'assets' / asset['src']).resolve()
            if not p.is_relative_to(client / 'assets') or not p.is_file():
                errors.append('Missing or nonlocal asset: ' + key)
    except (OSError, ValueError, KeyError, TypeError, AttributeError, StartupError) as exc:
        errors.append('Unreadable runtime content: ' + str(exc))
    return errors


def diagnose(root, args, host=None):
    host = host or detect_host()
    errors, warnings = [], []
    supported = host in ('windows', 'linux', 'macos', 'android-termux')
    if not supported:
        if host == 'ios':
            errors.append('iPhone/iPad: this package is a browser client, not an iOS server app. '
                          'Start a host with --lan on your trusted network, then open its START_IPHONE.html address in Safari.')
        elif host == 'android':
            errors.append('Android hosting in this package requires Python inside Termux. '
                          'A stock Android Python embedding is not this supported host environment.')
        else:
            errors.append('Unsupported server host. Use Windows, Linux, macOS or Android/Termux; '
                          'other devices can join a running host in their browser.')
    runtime = {'python': platform.python_version(), 'executable': sys.executable,
               'machine': platform.machine(), 'minimum_python': '3.10', 'sqlite': None}
    if sys.version_info < (3, 10):
        errors.append('Python 3.10 or newer is required; use the platform shortcut or a newer interpreter.')
    else:
        try:
            import sqlite3
            runtime['sqlite'] = sqlite3.sqlite_version
            if sqlite3.sqlite_version_info < (3, 24, 0):
                errors.append('This Python needs SQLite 3.24+ for the existing server UPSERT operations.')
            # Test capabilities without touching the user's database.
            with contextlib.closing(sqlite3.connect(':memory:')) as db:
                db.execute('SELECT 1').fetchone()
            importlib.import_module('http.server')
            importlib.import_module('ssl')
            importlib.import_module('msvcrt' if os.name == 'nt' else 'fcntl')
        except (ImportError, OSError, RuntimeError) as exc:
            errors.append('The installed Python is missing a server capability: ' + str(exc))
        errors.extend(validate_install(root))
    data = resolve_data(root, args.data)
    if host == 'android-termux':
        warnings.append('Android may suspend/kill Termux; keep it running. Startup does not change battery settings.')
        if android_shared_path(data):
            errors.append('Use Termux private HOME for the saved world, not Android shared storage. '
                          'Move the extracted folder into HOME or explicitly choose --data there; no save was moved.')
    if data.exists() and not data.is_file():
        errors.append('The --data path names a directory, not a SQLite file: ' + str(data))
    parent = data.parent
    while not parent.exists() and parent != parent.parent:
        parent = parent.parent
    if not parent.is_dir() or not os.access(parent, os.W_OK | os.X_OK):
        errors.append('Save directory is not writable: ' + str(parent) + '. Extract into a writable folder or use --data.')
    if data.is_file() and not os.access(data, os.W_OK):
        errors.append('Existing save is read-only: ' + str(data))
    if args.lan:
        warnings.append('Trusted LAN only. Do not port-forward this development server. Host firewall policy is unchanged.')
    if host == 'linux' and not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):
        warnings.append('No desktop display detected. The address will be printed; automatic browser opening is skipped.')
    route = None
    try:
        route = loader_route(root, host)
    except (OSError, ValueError, KeyError, TypeError, StartupError) as exc:
        errors.append('Startup loader registry unavailable: ' + str(exc))
    return {'schema': VERSION, 'ok': not errors, 'host': host, 'loader': route,
            'host_mode': 'server' if supported else 'browser-client-only',
            'runtime': runtime, 'binding': '0.0.0.0' if args.lan else '127.0.0.1',
            'port': args.port, 'save_path': str(data),
            'browser_requested': args.open, 'errors': errors, 'warnings': warnings,
            'check_scope': 'Read-only prerequisites. Does not certify platform behavior, writable filesystem locking or a free port.'}


def browser_commands(host, url, environ=None, which=None):
    env = os.environ if environ is None else environ
    which = shutil.which if which is None else which
    candidates = []
    if host == 'android-termux':
        candidates = [('termux-open-url',), ('termux-open',)]
    elif host == 'macos':
        candidates = [('open',)]
    elif host == 'linux' and (env.get('DISPLAY') or env.get('WAYLAND_DISPLAY')):
        candidates = [('xdg-open',), ('gio', 'open')]
    return [[which(c[0]), *c[1:], url] for c in candidates if which(c[0])]


def open_url(host, url):
    """Browser dispatch is best-effort, with bounded wait and no shell expansion."""
    if host == 'windows':
        try:
            os.startfile(url)
            return True
        except (AttributeError, OSError):
            return False
    for command in browser_commands(host, url):
        try:
            result = subprocess.run(command, shell=False, stdin=subprocess.DEVNULL,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    timeout=5)
            if result.returncode == 0:
                return True
        except (OSError, subprocess.TimeoutExpired):
            continue
    return False


class DatabaseLease:
    """OS advisory lock for launchers using this same resolved DB path.

    Lock file is intentionally retained: removing it permits inode races.
    Kernel lock release, not a stale PID file or timeout, grants the next start.
    Legacy direct `server.py` invocations cannot be policed by this launcher.
    """
    def __init__(self, data):
        self.path = Path(str(Path(data).resolve()) + '.launch.lock')
        self.fd = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
        self.fd = os.open(str(self.path), flags, 0o600)
        try:
            if os.name == 'nt':
                import msvcrt
                os.lseek(self.fd, 0, os.SEEK_SET)
                msvcrt.locking(self.fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            os.close(self.fd)
            self.fd = None
            raise StartupError('This save is already locked by another launcher, or the filesystem '
                               'does not support safe locking. Stop the other host or use a local save directory.') from exc
        try:
            os.ftruncate(self.fd, 0)
            os.write(self.fd, ('pid=' + str(os.getpid()) + '\n').encode('ascii'))
            os.fsync(self.fd)
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *args):
        if self.fd is not None:
            try:
                if os.name == 'nt':
                    import msvcrt
                    os.lseek(self.fd, 0, os.SEEK_SET)
                    msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.fd, fcntl.LOCK_UN)
            finally:
                os.close(self.fd)
                self.fd = None


def _interrupt(signum, frame):
    raise KeyboardInterrupt


def run_host(root, args, report):
    """Use existing game classes; no alternate engine, game data or authority."""
    root = Path(root).resolve()
    sys.path.insert(0, str(root))
    from server import Server
    from nvserver.service import GameService
    url = 'http://127.0.0.1:' + str(args.port) + '/'
    # Bind before creating/migrating a database. Occupied port never starts a
    # new world or silently moves to a different browser-account origin.
    try:
        server = Server((report['binding'], args.port), None, static=root / 'client', lan=args.lan)
    except OSError as exc:
        raise StartupError('Cannot bind port ' + str(args.port) + ': ' + str(exc) +
                           '. Stop the other host or explicitly choose --port. No save was opened.') from exc
    service = None
    ticker = None
    opener = None
    old_signals = {}
    try:
        with DatabaseLease(Path(report['save_path'])):
            service = GameService(Path(report['save_path']))
            server.service = service
            ticker = threading.Thread(target=server.tick, name='neon-world-ticker', daemon=True)
            ticker.start()
            for sig in (signal.SIGINT, signal.SIGTERM):
                old_signals[sig] = signal.signal(sig, _interrupt)
            print('NEON//VEIL | ' + report['host'] + ' | Python ' + report['runtime']['python'], flush=True)
            print('Open: ' + url, flush=True)
            print('Universal browser entry: ' + url + 'START_NEON_VEIL.html', flush=True)
            print('iPhone entry: use this host private IPv4 and port in Safari, then /START_IPHONE.html (not phone localhost).', flush=True)
            print('Save: ' + report['save_path'], flush=True)
            print('Keep this terminal running. Ctrl+C stops the host; world deadlines catch up on restart.', flush=True)
            if args.lan:
                print('TRUSTED LAN ONLY: other devices use http://<this-host-private-IP>:' + str(args.port) +
                      '/ (not their own localhost). Do not port-forward. Cross-device account login is not implemented.', flush=True)
            if args.open:
                def browse():
                    if not server.closed.is_set() and not open_url(report['host'], url):
                        print('Browser was not opened automatically. Open this address manually: ' + url, flush=True)
                opener = threading.Timer(.4, browse)
                opener.daemon = True
                opener.start()
            try:
                server.serve_forever(poll_interval=.2)
            except KeyboardInterrupt:
                print('\nStopping NEON//VEIL.', flush=True)
            finally:
                if opener:
                    opener.cancel()
                server.closed.set()
                server.server_close()
                ticker.join(3)
                service.close()
                service = None
    finally:
        server.closed.set()
        server.server_close()
        if ticker:
            ticker.join(3)
        if service:
            service.close()
        for sig, old in old_signals.items():
            signal.signal(sig, old)
    return 0


def main(argv=None):
    args = parse_args(argv)
    try:
        report = diagnose(ROOT, args)
        if args.json:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        else:
            for warning in report['warnings']:
                print('Note: ' + warning, flush=True)
            for error in report['errors']:
                print('Startup: ' + error, file=sys.stderr, flush=True)
            if args.check:
                print(('Ready' if report['ok'] else 'Not ready') + ': ' + report['host'] +
                      ' | Python ' + report['runtime']['python'] + ' | ' + report['save_path'])
        if args.check or not report['ok']:
            return 0 if report['ok'] else 2
        return run_host(ROOT, args, report)
    except (StartupError, OSError, ValueError) as exc:
        print('Startup: ' + str(exc), file=sys.stderr, flush=True)
        return 1
    except KeyboardInterrupt:
        print('\nStartup cancelled.', file=sys.stderr, flush=True)
        return 130


if __name__ == '__main__':
    raise SystemExit(main())
