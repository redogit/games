#!/bin/sh
# Finder convenience only; all platform logic is in the shared Python controller.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
exec sh "$ROOT/START_NEON_VEIL.sh" "$@"
