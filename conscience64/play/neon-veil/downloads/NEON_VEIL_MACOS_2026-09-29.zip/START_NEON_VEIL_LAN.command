#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
exec sh "$ROOT/START_NEON_VEIL_LAN.sh" "$@"
