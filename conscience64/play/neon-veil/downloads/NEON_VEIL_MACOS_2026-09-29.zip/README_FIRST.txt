NEON//VEIL — Public Preview — 2026-09-29

This is a local-first preview. The Python server owns the world state. GitHub Pages
only distributes the packages and provides a launcher hub; it is not the game server.

Safety boundary: trusted local network only. Do not port-forward this development server.
Back up the entire data directory before moving an existing save between versions.

MAC SOLO (APPLE SILICON OR INTEL)
1. Install Python 3.10 or newer.
2. Extract this ZIP completely.
3. Open START_NEON_VEIL.command. If macOS blocks it, open Terminal in this folder and run: sh START_NEON_VEIL.sh
4. Keep the terminal open while playing.

MAC HOST FOR ANOTHER DEVICE
Run START_NEON_VEIL_LAN.command, or: sh START_NEON_VEIL.sh --lan
Then use the printed LAN address on the other device or the central Play page.
