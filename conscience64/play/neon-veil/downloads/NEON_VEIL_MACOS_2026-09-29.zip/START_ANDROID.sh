#!/bin/sh
# Invoke with sh inside Termux; never hard-code an Android interpreter path.
# The shared controller checks the actual environment and save location.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
exec sh "$ROOT/START_NEON_VEIL.sh" "$@"
