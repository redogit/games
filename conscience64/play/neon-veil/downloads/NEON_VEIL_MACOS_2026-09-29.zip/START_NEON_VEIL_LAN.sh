#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
printf '%s\n' 'This explicitly enables TRUSTED LAN testing; do not port-forward this development server.'
exec sh "$ROOT/START_NEON_VEIL.sh" --lan "$@"
