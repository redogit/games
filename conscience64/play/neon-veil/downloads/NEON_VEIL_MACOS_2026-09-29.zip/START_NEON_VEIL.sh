#!/bin/sh
# One POSIX bootstrap for Linux, macOS and Android/Termux. No game logic here.
# On Termux invoke `sh START_NEON_VEIL.sh` to avoid host-specific shebang paths.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ -n "${NEON_PYTHON:-}" ]; then
    if ! "$NEON_PYTHON" -c 'import sys; sys.exit(sys.version_info < (3,10))' >/dev/null 2>&1; then
        printf '%s\n' 'NEON_PYTHON must name one installed Python 3.10+ executable (not a command with arguments).' >&2
        exit 2
    fi
    exec "$NEON_PYTHON" -B -u "$ROOT/START_NEON_VEIL.py" "$@"
fi
for PYTHON in python3 python; do
    if command -v "$PYTHON" >/dev/null 2>&1 && "$PYTHON" -c 'import sys; sys.exit(sys.version_info < (3,10))' >/dev/null 2>&1; then
        exec "$PYTHON" -B -u "$ROOT/START_NEON_VEIL.py" "$@"
    fi
done
printf '%s\n' 'Python 3.10+ is required. Install it using your OS package source; in Termux use: pkg install python' 'Or set NEON_PYTHON to the full path of your installed Python executable. Nothing was installed or changed.' >&2
exit 2
